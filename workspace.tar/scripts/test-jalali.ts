/* تست صحت تبدیل تاریخ جلالی */
import { toJalali, toGregorian, jalaliMonthLength, isLeapJalali } from "../src/lib/jalali";

function check(iso: string, expected: string) {
  const [gy, gm, gd] = iso.split("-").map(Number);
  const j = toJalali(new Date(gy, gm - 1, gd));
  const got = `${j.jy}/${String(j.jm).padStart(2, "0")}/${String(j.jd).padStart(2, "0")}`;
  const ok = got === expected;
  console.log(ok ? "PASS" : "FAIL", iso, "→", got, ok ? "" : `(expected ${expected})`);
}

function rt(jy: number, jm: number, jd: number) {
  const g = toGregorian(jy, jm, jd);
  const j = toJalali(g);
  return j.jy === jy && j.jm === jm && j.jd === jd;
}

check("2026-09-05", "1405/06/14");
check("2026-09-06", "1405/06/15");
check("2026-03-21", "1405/01/01");
check("2025-03-21", "1404/01/01");
check("2024-03-20", "1403/01/01");
check("2026-02-19", "1404/11/30");
check("2025-06-15", "1404/03/25");

let fails = 0;
for (let y = 1390; y <= 1410; y++) {
  for (let m = 1; m <= 12; m++) {
    const len = jalaliMonthLength(y, m);
    for (const d of [1, Math.min(15, len), len]) {
      if (!rt(y, m, d)) {
        fails++;
        console.log("RT FAIL", y, m, d);
      }
    }
  }
}
console.log(fails === 0 ? "ROUNDTRIP ALL PASS (1390-1410)" : `ROUNDTRIP FAILURES: ${fails}`);
console.log("Leap 1403:", isLeapJalali(1403), "| Leap 1404:", isLeapJalali(1404), "| Leap 1405:", isLeapJalali(1405));
console.log("MonthLen 1405/6:", jalaliMonthLength(1405, 6), "| 1405/12:", jalaliMonthLength(1405, 12));
