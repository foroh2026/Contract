/* ═══════════════════════════════════════════════════════════
   مدل داده سامانه جامع مدیریت قرارداد
   ═══════════════════════════════════════════════════════════ */

export type ContractStatus =
  | "active"      // فعال
  | "near-end"    // نزدیک پایان
  | "delayed"     // دارای تأخیر
  | "suspended"   // متوقف
  | "terminated"  // خاتمه‌یافته
  | "completed";  // تکمیل‌شده

export interface Employer {
  id: string;
  code: string;
  name: string;
  shortName: string;
  type: "دولتی" | "نیمه‌دولتی" | "خصوصی";
  nationalId: string;
  economicCode: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
}

export interface Contract {
  id: string;
  code: string;              // CTR-1404-001
  title: string;
  subject: string;
  employerId: string;
  creditSource: string;      // محل اعتبار
  startDate: string;         // ISO
  endDate: string;           // ISO
  amountRial: number;
  amountForeign?: number;
  currency?: string;
  exchangeRate?: number;
  prepaymentPercent: number;
  status: ContractStatus;
  lastStatusDate: string;
  description?: string;
  createdAt: string;
}

export type ItemType = "خرید" | "ساخت" | "مونتاژ" | "تأمین" | "خدمات فنی";
export type ItemStatus = "شروع‌نشده" | "در حال اجرا" | "تکمیل‌شده" | "متوقف";

/** قلم پیوست فنی */
export interface TechnicalItem {
  id: string;
  code: string;              // K-001
  title: string;
  description: string;
  type: ItemType;
  unit: string;              // عدد / دستگاه / ست / کیلوگرم / متر
  quantity: number;
  weightPercent: number;     // وزن در محاسبه پیشرفت
  amount: number;            // مبلغ ریالی
  planPercent: number;       // پیشرفت برنامه‌ای فعلی
  progress: number;          // پیشرفت واقعی فعلی
  startDate: string;
  endDate: string;
  status: ItemStatus;
  chapterId: string;
  groupId: string;
}

export interface TechnicalGroup {
  id: string;
  title: string;
  chapterId: string;
  itemIds: string[];
}

export interface TechnicalChapter {
  id: string;
  title: string;
  groupIds: string[];
}

/** پیوست فنی هر قرارداد */
export interface TechnicalAppendix {
  id: string;
  contractId: string;
  version: string;           // نسخه ۰۳
  revisionDate: string;
  chapters: TechnicalChapter[];
  groups: TechnicalGroup[];
  items: TechnicalItem[];
}

/** سابقه ثبت پیشرفت هر قلم */
export interface ProgressLog {
  id: string;
  itemId: string;
  contractId: string;
  date: string;
  previous: number;
  current: number;
  description: string;
  user: string;
}

export type PurchaseType = "خرید" | "ساخت";
export type PurchaseStatus = "ثبت‌شده" | "در حال تأمین" | "تحویل‌شده" | "لغو شده";

export interface Purchase {
  id: string;
  code: string;              // PRC-1405-001
  contractId: string;
  itemId?: string;           // اتصال به قلم پیوست فنی
  type: PurchaseType;
  description: string;
  supplier: string;
  date: string;
  unitPrice: number;
  quantity: number;
  unit: string;
  status: PurchaseStatus;
}

export type StatementStatus = "پیش‌نویس" | "در انتظار تأیید" | "تأیید شده" | "پرداخت شده";

export interface Statement {
  id: string;
  code: string;              // SV-001
  contractId: string;
  number: number;
  date: string;
  description: string;
  grossAmount: number;       // مبلغ ناخالص
  vatPercent: number;        // ارزش افزوده
  finalAmount: number;       // نهایی با ارزش افزوده
  status: StatementStatus;
}

export type PaymentMethod = "حواله بانکی" | "چک" | "انتقال بین‌بانکی" | "تنخواه";

export interface Payment {
  id: string;
  code: string;              // PAY-1405-001
  contractId: string;
  statementId?: string;
  amount: number;
  date: string;
  method: PaymentMethod;
  reference: string;         // شماره پیگیری/چک
  description?: string;
}

export interface Amendment {
  id: string;
  code: string;              // الحاقیه ۰۱
  contractId: string;
  date: string;
  description: string;
  amountChange: number;      // + افزایش / − کاهش
  durationChangeDays: number;
  status: "تأیید شده" | "در حال بررسی" | "پیش‌نویس";
  fileName?: string;
}

export type DocKind =
  | "قرارداد اصلی" | "الحاقیه" | "پیوست فنی" | "صورتجلسه"
  | "لیست اقلام" | "گزارش فنی" | "مکاتبات" | "سایر";

export interface DocumentFile {
  id: string;
  name: string;
  kind: DocKind;
  sizeKb: number;
  version: number;
  date: string;
  uploader: string;
  contractId?: string;
  fileType: "pdf" | "xlsx" | "docx" | "dwg" | "img";
}

export interface Notification {
  id: string;
  kind: "warning" | "danger" | "success" | "info";
  title: string;
  description: string;
  date: string;
  read: boolean;
  link?: string;
}

export type UserRole = "مدیر سیستم" | "مدیر قرارداد" | "کارشناس قرارداد" | "مالی" | "خرید" | "ناظر";

export interface User {
  id: string;
  username: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  active: boolean;
  lastLogin: string;
  email: string;
}

export type ActivityKind =
  | "contract" | "appendix" | "progress" | "statement"
  | "payment" | "purchase" | "document" | "amendment";

export interface Activity {
  id: string;
  contractId?: string;
  kind: ActivityKind;
  title: string;
  description: string;
  date: string;
  user: string;
}

/** نتیجه محاسبه سلامت قرارداد */
export interface HealthScore {
  score: number;       // 0..100
  level: "خوب" | "متوسط" | "بحرانی";
  factors: { label: string; score: number; weight: number }[];
}

/* ─────────── وضعیت‌ها: برچسب ─────────── */

export const CONTRACT_STATUS_LABEL: Record<ContractStatus, string> = {
  active: "فعال",
  "near-end": "نزدیک پایان",
  delayed: "دارای تأخیر",
  suspended: "متوقف",
  terminated: "خاتمه‌یافته",
  completed: "تکمیل‌شده",
};

export const STATEMENT_STATUS_LABEL: Record<StatementStatus, string> = {
  "پیش‌نویس": "پیش‌نویس",
  "در انتظار تأیید": "در انتظار تأیید",
  "تأیید شده": "تأیید شده",
  "پرداخت شده": "پرداخت شده",
};

export const PURCHASE_STATUS_LABEL: Record<PurchaseStatus, string> = {
  "ثبت‌شده": "ثبت‌شده",
  "در حال تأمین": "در حال تأمین",
  "تحویل‌شده": "تحویل‌شده",
  "لغو شده": "لغو شده",
};
