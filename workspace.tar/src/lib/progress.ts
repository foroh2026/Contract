import type { Contract, TechnicalAppendix, TechnicalItem } from "@/types";
import { diffDays, todayISO } from "@/lib/jalali";

/* ═══════════════════════════════════════════════════════════
   محاسبات پیشرفت وزن‌دار قرارداد بر اساس پیوست فنی

   پیشرفت کل = Σ (وزن هر قلم × درصد پیشرفت همان قلم)
   ═══════════════════════════════════════════════════════════ */

/** پیشرفت وزن‌دار کل از اقلام */
export function weightedProgress(items: TechnicalItem[]): number {
  if (!items.length) return 0;
  const sum = items.reduce((acc, it) => acc + it.weightPercent * it.progress, 0);
  return Math.round((sum / 100) * 10) / 10;
}

/** پیشرفت برنامه‌ای وزن‌دار */
export function weightedPlan(items: TechnicalItem[]): number {
  if (!items.length) return 0;
  const sum = items.reduce((acc, it) => acc + it.weightPercent * it.planPercent, 0);
  return Math.round((sum / 100) * 10) / 10;
}

/** پیشرفت وزن‌دار یک گروه/فصل */
export function groupProgress(items: TechnicalItem[]): number {
  return weightedProgress(items);
}

/** پیشرفت برنامه‌ای قرارداد بر اساس زمان‌بندی */
export function plannedProgress(contract: Contract): number {
  if (contract.status === "completed") return 100;
  if (contract.status === "terminated") return 0;
  const start = new Date(contract.startDate);
  const end = new Date(contract.endDate);
  const now = new Date();
  const total = end.getTime() - start.getTime();
  if (total <= 0) return 100;
  const elapsed = now.getTime() - start.getTime();
  return Math.max(0, Math.min(100, Math.round((elapsed / total) * 100)));
}

/** انحراف پیشرفت (واقعی − برنامه‌ای) */
export function progressDeviation(actual: number, planned: number): number {
  return Math.round((actual - planned) * 10) / 10;
}

/** خلاصه پیشرفت قرارداد */
export interface ProgressSummary {
  actual: number;
  planned: number;
  deviation: number;
  completedItems: number;
  totalItems: number;
  inProgressItems: number;
  stoppedItems: number;
}

export function contractProgressSummary(
  contract: Contract,
  appendix: TechnicalAppendix
): ProgressSummary {
  const actual = weightedProgress(appendix.items);
  const plannedBase = weightedPlan(appendix.items);
  const plannedTime = plannedProgress(contract);
  // برنامه‌ای = میانگین وزنی برنامه اقلام و زمان‌بندی کلی
  const planned = contract.status === "completed" ? 100 : Math.round(((plannedBase + plannedTime) / 2) * 10) / 10;
  return {
    actual,
    planned,
    deviation: progressDeviation(actual, planned),
    completedItems: appendix.items.filter((i) => i.progress >= 100).length,
    totalItems: appendix.items.length,
    inProgressItems: appendix.items.filter((i) => i.progress > 0 && i.progress < 100).length,
    stoppedItems: appendix.items.filter((i) => i.status === "متوقف").length,
  };
}

/** روزهای باقی‌مانده قرارداد */
export function remainingDays(contract: Contract): number {
  return diffDays(todayISO(), contract.endDate.slice(0, 10));
}
