/* ═══════════════════════════════════════════════════════════
   موتور تقویم شمسی (جلالی) — بدون هیچ وابستگی خارجی
   تبدیل دقیق میلادی ↔ جلالی بر اساس الگوریتم استاندارد
   ═══════════════════════════════════════════════════════════ */

export interface JDate {
  jy: number;
  jm: number; // 1..12
  jd: number; // 1..31
}

const div = (a: number, b: number) => Math.trunc(a / b);
const mod = (a: number, b: number) => a - Math.trunc(a / b) * b;

const BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
  2192, 2262, 2324, 2394, 2456, 3178,
];

function jalCal(jy: number): { leap: number; gy: number; march: number } {
  const bl = BREAKS.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = BREAKS[0];
  let jm = 0;
  let jump = 0;
  if (jy < jp || jy >= BREAKS[bl - 1]) throw new Error("سال جلالی نامعتبر: " + jy);
  for (let i = 1; i < bl; i++) {
    jm = BREAKS[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

function g2d(gy: number, gm: number, gd: number): number {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number): { gy: number; gm: number; gd: number } {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

/** میلادی → جلالی */
export function toJalali(date: Date): JDate {
  const jdn = g2d(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return d2j(jdn);
}

function d2j(jdn: number): JDate {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 };
}

/** جلالی → میلادی (شیء Date با زمان صفر) */
export function toGregorian(jy: number, jm: number, jd: number): Date {
  const r = jalCal(jy);
  const jdn = g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
  const g = d2g(jdn);
  return new Date(g.gy, g.gm - 1, g.gd);
}

export function isLeapJalali(jy: number): boolean {
  return jalCal(jy).leap === 0;
}

export function jalaliMonthLength(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalali(jy) ? 30 : 29;
}

/** شماره روز هفته جلالی: 0 = شنبه ... 6 = جمعه */
export function jalaliWeekday(date: Date): number {
  return (date.getDay() + 1) % 7;
}

export const JALALI_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

export const JALALI_WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
export const JALALI_WEEKDAYS_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

/* ─────────── تبدیل ارقام ─────────── */

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toFaDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function toEnDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}

/* ─────────── قالب‌بندی تاریخ ─────────── */

export type JalaliFormat = "numeric" | "short" | "long";

/** ۱۴۰۵/۰۶/۱۴ | ۱۴ شهریور ۱۴۰۵ */
export function formatJalali(
  date: Date | string | number,
  format: JalaliFormat = "numeric"
): string {
  if (!date) return "—";
  const d = new Date(date);
  if (isNaN(d.getTime())) return "—";
  const { jy, jm, jd } = toJalali(d);
  if (format === "numeric") {
    const mm = String(jm).padStart(2, "0");
    const dd = String(jd).padStart(2, "0");
    return toFaDigits(`${jy}/${mm}/${dd}`);
  }
  if (format === "short") {
    return toFaDigits(`${jd} ${JALALI_MONTHS[jm - 1].slice(0, 3)} ${jy}`);
  }
  return toFaDigits(`${jd} ${JALALI_MONTHS[jm - 1]} ${jy}`);
}

export function formatJalaliFull(date: Date | string): string {
  if (!date) return "—";
  const d = new Date(date);
  if (isNaN(d.getTime())) return "—";
  const { jy, jm, jd } = toJalali(d);
  const wd = JALALI_WEEKDAYS[jalaliWeekday(d)];
  return toFaDigits(`${wd} ${jd} ${JALALI_MONTHS[jm - 1]} ${jy}`);
}

/** امروز */
export function todayJalali(): JDate {
  return toJalali(new Date());
}

export function todayISO(): string {
  return toISO(new Date());
}

export function toISO(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export function fromISO(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

/** تبدیل رشته تاریخ جلالی «۱۴۰۵/۰۶/۱۴» به ISO میلادی (برای ذخیره‌سازی) */
export function jalaliStringToISO(s: string): string {
  const en = toEnDigits(s).trim();
  const m = en.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (!m) return "";
  return toISO(toGregorian(Number(m[1]), Number(m[2]), Number(m[3])));
}

/** تبدیل ISO میلادی به رشته جلالی برای نمایش در فرم */
export function isoToJalaliString(iso?: string | null): string {
  if (!iso) return "";
  const d = fromISO(iso.slice(0, 10));
  if (isNaN(d.getTime())) return "";
  const { jy, jm, jd } = toJalali(d);
  return toFaDigits(`${jy}/${String(jm).padStart(2, "0")}/${String(jd).padStart(2, "0")}`);
}

/* ─────────── محاسبات زمانی ─────────── */

export function diffDays(a: Date | string, b: Date | string): number {
  const da = typeof a === "string" ? fromISO(a.slice(0, 10)) : a;
  const db = typeof b === "string" ? fromISO(b.slice(0, 10)) : b;
  const a0 = new Date(da.getFullYear(), da.getMonth(), da.getDate());
  const b0 = new Date(db.getFullYear(), db.getMonth(), db.getDate());
  return Math.round((b0.getTime() - a0.getTime()) / 86400000);
}

export function addDays(date: Date | string, days: number): Date {
  const d = typeof date === "string" ? fromISO(date.slice(0, 10)) : new Date(date);
  const nd = new Date(d);
  nd.setDate(nd.getDate() + days);
  return nd;
}

/** توضیح نسبی زمان: «۳ روز پیش» */
export function timeAgo(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const days = Math.floor((Date.now() - d.getTime()) / 86400000);
  if (days <= 0) {
    const hours = Math.floor((Date.now() - d.getTime()) / 3600000);
    if (hours <= 0) return "چند دقیقه پیش";
    return toFaDigits(hours) + " ساعت پیش";
  }
  if (days === 1) return "دیروز";
  if (days < 30) return toFaDigits(days) + " روز پیش";
  const months = Math.floor(days / 30);
  if (months < 12) return toFaDigits(months) + " ماه پیش";
  return toFaDigits(Math.floor(months / 12)) + " سال پیش";
}

/** روزهای باقی‌مانده تا تاریخ (مثبت) یا سپری‌شده (منفی) */
export function daysUntil(iso: string): number {
  return diffDays(new Date(), iso.slice(0, 10));
}
