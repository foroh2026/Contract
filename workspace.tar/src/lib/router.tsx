"use client";

/* ═══════════════════════════════════════════════════════════
   روتر داخلی SPA — مبتنی بر Hash (useSyncExternalStore)
   مسیرها مثل /dashboard و /contracts/:id/progress
   ═══════════════════════════════════════════════════════════ */

import { createContext, useContext, useCallback, useSyncExternalStore } from "react";

function readHash(): string {
  if (typeof window === "undefined") return "/dashboard";
  const h = window.location.hash.replace(/^#/, "");
  return h || "/dashboard";
}

function subscribe(cb: () => void) {
  window.addEventListener("hashchange", cb);
  return () => window.removeEventListener("hashchange", cb);
}

const RouteContext = createContext<{ path: string; navigate: (p: string) => void }>({
  path: "/dashboard",
  navigate: () => {},
});

export function RouterProvider({ children }: { children: React.ReactNode }) {
  const path = useSyncExternalStore(subscribe, readHash, () => "/dashboard");

  const navigate = useCallback((p: string) => {
    if (p.startsWith("/")) {
      window.location.hash = p;
    }
  }, []);

  return (
    <RouteContext.Provider value={{ path, navigate }}>
      {children}
    </RouteContext.Provider>
  );
}

export function useRouter() {
  return useContext(RouteContext);
}

export interface ParsedRoute {
  segments: string[];
  query: URLSearchParams;
}

export function parseRoute(path: string): ParsedRoute {
  const [base, qs] = path.split("?");
  return { segments: base.split("/").filter(Boolean), query: new URLSearchParams(qs || "") };
}
