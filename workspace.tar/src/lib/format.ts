import { toFaDigits } from "./jalali";

/* ═══════════════════════════════════════════════════════════
   قالب‌بندی اعداد، مبلغ و درصد — فارسی
   ═══════════════════════════════════════════════════════════ */

const FA_THOUSANDS = "٬";
const FA_DECIMAL = "٫";

/** عدد با جداکننده هزارگان فارسی: 1234567 → ۱٬۲۳۴٬۵۶۷ */
export function formatNumber(n: number | undefined | null, digits = 0): string {
  if (n === undefined || n === null || isNaN(n)) return "—";
  const parts = Math.abs(n).toFixed(digits).split(".");
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, FA_THOUSANDS);
  const s = parts.join(FA_DECIMAL);
  return (n < 0 ? "−" : "") + toFaDigits(s);
}

/** مبلغ ریالی: ۱۲٬۵۰۰٬۰۰۰٬۰۰۰ ریال */
export function formatRial(n: number | undefined | null): string {
  if (n === undefined || n === null) return "—";
  return formatNumber(n) + " ریال";
}

/** مبلغ فشرده برای KPI: ۱۲٫۵ میلیارد ریال */
export function formatRialCompact(n: number | undefined | null): string {
  if (n === undefined || n === null || isNaN(n)) return "—";
  const abs = Math.abs(n);
  if (abs >= 1_000_000_000_000) return formatNumber(n / 1_000_000_000_000, 1) + " هزار میلیارد ریال";
  if (abs >= 1_000_000_000) return formatNumber(n / 1_000_000_000, 1) + " میلیارد ریال";
  if (abs >= 1_000_000) return formatNumber(n / 1_000_000, 1) + " میلیون ریال";
  if (abs >= 1_000) return formatNumber(n / 1_000, 0) + " هزار ریال";
  return formatNumber(n) + " ریال";
}

/** مبلغ ارزی: ۵۰٬۰۰۰ دلار */
export function formatForeign(n: number | undefined | null, currency = "دلار"): string {
  if (n === undefined || n === null) return "—";
  return formatNumber(n) + " " + currency;
}

/** درصد: 61.5 → ۶۱٫۵٪ */
export function formatPercent(n: number | undefined | null, digits = 1): string {
  if (n === undefined || n === null || isNaN(n)) return "—";
  return formatNumber(n, digits) + "٪";
}

/** درصد صحیح (بدون اعشار در صورت امکان) */
export function formatPercentInt(n: number | undefined | null): string {
  if (n === undefined || n === null || isNaN(n)) return "—";
  return formatNumber(Math.round(n), 0) + "٪";
}

/** عدد با علامت: -6.5 → ‎−۶٫۵ */
export function formatSigned(n: number, digits = 1): string {
  if (isNaN(n)) return "—";
  return (n > 0 ? "+" : "") + formatNumber(n, digits);
}

/** درصد با علامت */
export function formatSignedPercent(n: number, digits = 1): string {
  if (isNaN(n)) return "—";
  return (n > 0 ? "+" : "") + formatPercent(n, digits);
}

/** تبدیل ورودی فارسی فرم به عدد لاتین (برای ذخیره‌سازی) */
export function parseFaNumber(s: string): number {
  const en = s
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/[٬,]/g, "")
    .replace(/[٫]/g, ".")
    .trim();
  const n = Number(en);
  return isNaN(n) ? 0 : n;
}

/** حجم فایل خوانا */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return toFaDigits(bytes) + " بایت";
  if (bytes < 1024 * 1024) return toFaDigits((bytes / 1024).toFixed(0)) + " کیلوبایت";
  return toFaDigits((bytes / (1024 * 1024)).toFixed(1)) + " مگابایت";
}
