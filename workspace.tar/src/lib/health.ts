import type { Contract, HealthScore, Payment, Purchase, Statement } from "@/types";
import { remainingDays } from "./progress";

/* ═══════════════════════════════════════════════════════════
   سیستم وضعیت سلامت قرارداد (Contract Health Score)
   عوامل: پیشرفت، تأخیر، مطالبات، پرداخت، زمان، خرید
   ═══════════════════════════════════════════════════════════ */

export function computeHealthScore(input: {
  contract: Contract;
  actual: number;
  planned: number;
  statements: Statement[];
  payments: Payment[];
  purchases: Purchase[];
}): HealthScore {
  const { contract, actual, planned, statements, payments, purchases } = input;

  // ۱) انحراف پیشرفت (وزن ۳۰)
  const dev = planned - actual;
  const progressScore = Math.max(0, Math.min(100, Math.round(100 - Math.max(0, dev) * 7)));

  // ۲) زمان باقی‌مانده نسبت به کار باقی‌مانده (وزن ۲۰)
  const days = remainingDays(contract);
  const workRemaining = 100 - actual;
  let timeScore = 100;
  if (contract.status === "completed") timeScore = 100;
  else if (days <= 0) timeScore = Math.max(0, 40 + days);
  else {
    const dailyRate = workRemaining / days;
    timeScore = Math.max(0, Math.min(100, Math.round(110 - dailyRate * 3.2)));
  }

  // ۳) وضعیت مطالبات (وزن ۲۰)
  const stFinal = statements.reduce((a, s) => a + s.finalAmount, 0);
  const paid = payments.reduce((a, p) => a + p.amount, 0);
  const outstanding = Math.max(0, stFinal - paid);
  const ratio = stFinal > 0 ? outstanding / stFinal : 0;
  const receivableScore = Math.max(0, Math.min(100, Math.round(100 - ratio * 120)));

  // ۴) وضعیت خرید و تأمین (وزن ۱۵)
  let supplyScore = 85;
  if (purchases.length > 0) {
    const delivered = purchases.filter((p) => p.status === "تحویل‌شده").length;
    const canceled = purchases.filter((p) => p.status === "لغو شده").length;
    supplyScore = Math.round((delivered / purchases.length) * 100) - canceled * 10;
    supplyScore = Math.max(0, Math.min(100, supplyScore));
  }

  // ۵) صورت‌وضعیت‌های در انتظار (وزن ۱۵)
  const pending = statements.filter((s) => s.status === "در انتظار تأیید" || s.status === "پیش‌نویس").length;
  const statementScore = Math.max(0, 100 - pending * 18);

  const factors = [
    { label: "انحراف پیشرفت از برنامه", score: progressScore, weight: 30 },
    { label: "زمان باقی‌مانده قرارداد", score: timeScore, weight: 20 },
    { label: "وضعیت مطالبات و پرداخت", score: receivableScore, weight: 20 },
    { label: "وضعیت خرید و تأمین", score: supplyScore, weight: 15 },
    { label: "صورت‌وضعیت‌های در انتظار", score: statementScore, weight: 15 },
  ];

  const score = Math.max(0, Math.min(100,
    Math.round(factors.reduce((a, f) => a + f.score * f.weight, 0) / 100)
  ));

  const level: HealthScore["level"] = score >= 70 ? "خوب" : score >= 45 ? "متوسط" : "بحرانی";
  return { score, level, factors };
}
