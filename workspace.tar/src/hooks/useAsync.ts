"use client";

import { useEffect, useState, useCallback, useSyncExternalStore } from "react";

/* هوک دریافت داده از لایه سرویس (async) با مدیریت حالت‌ها */

export interface AsyncState<T> {
  data: T | undefined;
  loading: boolean;
  error: string | null;
  reload: () => void;
}

interface AsyncInternal<T> {
  data: T | undefined;
  loading: boolean;
  error: string | null;
  tick: number;
}

export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []): AsyncState<T> {
  const [state, setState] = useState<AsyncInternal<T>>({ data: undefined, loading: true, error: null, tick: 0 });

  useEffect(() => {
    let alive = true;
    // شروع مجدد بارگذاری (غیرهمگام تا از setState همگام در بدنه اثر پرهیز شود)
    Promise.resolve().then(() => {
      if (alive) setState((s) => ({ ...s, loading: true, error: null }));
    });
    fn()
      .then((d) => {
        if (alive) setState((s) => ({ ...s, data: d, loading: false, error: null }));
      })
      .catch((e) => {
        if (alive) setState((s) => ({ ...s, loading: false, error: e?.message || "خطا در دریافت اطلاعات" }));
      });
    return () => {
      alive = false;
    };
  }, [...deps, state.tick]);

  const reload = useCallback(() => setState((s) => ({ ...s, tick: s.tick + 1 })), []);
  return { data: state.data, loading: state.loading, error: state.error, reload };
}

/* هوک media query بدون setState در اثر */
export function useMediaQuery(query: string): boolean {
  return useSyncExternalStore(
    (cb) => {
      const mq = window.matchMedia(query);
      mq.addEventListener("change", cb);
      return () => mq.removeEventListener("change", cb);
    },
    () => window.matchMedia(query).matches,
    () => false
  );
}

/* هوک تشخیص mount — سازگار با SSR */
const emptySubscribe = () => () => {};
export function useMounted(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}
