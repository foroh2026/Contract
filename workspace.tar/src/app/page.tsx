"use client";

import { AppShell } from "@/components/layout/app-shell";
import { useRouter, parseRoute } from "@/lib/router";
import { DashboardView } from "@/components/views/dashboard-view";
import { ContractsListView } from "@/components/views/contracts-list-view";
import { ContractFormView } from "@/components/views/contract-form-view";
import { ContractDetailView } from "@/components/views/contract-detail-view";
import { EmployersView } from "@/components/views/employers-view";
import { PurchasesView } from "@/components/views/purchases-view";
import { ProgressView } from "@/components/views/progress-view";
import { StatementsView, PaymentsView, ReceivablesView } from "@/components/views/statements-view";
import { AppendicesView } from "@/components/views/appendices-view";
import { DocumentsView } from "@/components/views/documents-view";
import { ReportsView } from "@/components/views/reports-view";
import { NotificationsView } from "@/components/views/notifications-view";
import { UsersView, RolesView } from "@/components/views/users-view";
import { SettingsView } from "@/components/views/settings-view";
import { NotFoundView } from "@/components/views/not-found-view";

/* ═══════ نقطه ورود برنامه — ناوبری SPA مبتنی بر Hash ═══════ */

export default function Home() {
  const { path } = useRouter();
  const { segments } = parseRoute(path);
  const root = segments[0] || "dashboard";

  // تعویض نما بر اساس مسیر داخلی — محاسبه سبک و بدون کش اضافه
  const view = (() => {
    // قراردادها
    if (root === "contracts") {
      if (segments.length === 1) return <ContractsListView />;
      if (segments[1] === "new") return <ContractFormView mode="create" />;
      if (segments[2] === "edit") return <ContractFormView mode="edit" contractId={segments[1]} />;
      return <ContractDetailView contractId={segments[1]} section={segments[2] || "overview"} />;
    }
    switch (root) {
      case "dashboard": return <DashboardView />;
      case "employers": return <EmployersView />;
      case "appendices": return <AppendicesView />;
      case "purchases": return <PurchasesView />;
      case "progress": return <ProgressView />;
      case "statements": return <StatementsView />;
      case "payments": return <PaymentsView />;
      case "receivables": return <ReceivablesView />;
      case "documents": return <DocumentsView />;
      case "reports": return <ReportsView />;
      case "notifications": return <NotificationsView />;
      case "users": return <UsersView />;
      case "roles": return <RolesView />;
      case "settings": return <SettingsView />;
      default: return <NotFoundView />;
    }
  })();

  return <AppShell>{view}</AppShell>;
}
