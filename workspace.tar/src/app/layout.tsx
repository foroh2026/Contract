import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "@/components/layout/app-shell";

export const metadata: Metadata = {
  title: "سامانه جامع مدیریت قراردادها | تأمین تجهیزات صنعتی",
  description:
    "سامانه سازمانی مدیریت چرخه کامل قراردادها، پیوست فنی، خرید و ساخت، پیشرفت فیزیکی، صورت‌وضعیت و دریافتی‌ها",
  icons: { icon: "/favicon.svg" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#eef1f4" },
    { media: "(prefers-color-scheme: dark)", color: "#12181d" },
  ],
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground font-sans">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
