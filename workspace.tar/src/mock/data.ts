import type {
  Activity, Amendment, Contract, ContractStatus, DocumentFile, Employer,
  ItemStatus, Notification, Payment, ProgressLog, Purchase, PurchaseStatus,
  Statement, StatementStatus, TechnicalAppendix, TechnicalGroup, TechnicalChapter,
  TechnicalItem, User, ItemType,
} from "@/types";
import { addDays, diffDays, toGregorian, toISO } from "@/lib/jalali";
import {
  CHAPTER_TEMPLATES, CONTACT_PERSONS, CONTRACT_TITLES, CREDIT_SOURCES,
  EMPLOYERS, ITEM_POOL, SUPPLIERS, USERS_POOL,
  mulberry32, pick, randFloat, randInt, type Rng,
} from "./pools";

/* ═══════════════════════════════════════════════════════════
   تولید مجموعه داده Mock — ۲۰ قرارداد، ۱۰ کارفرما، ۱۰۰+ قلم
   ═══════════════════════════════════════════════════════════ */

const rng: Rng = mulberry32(1405);
const today = new Date();
const TODAY_ISO = toISO(today);

const iso = (jy: number, jm: number, jd: number) => toISO(toGregorian(jy, jm, jd));

/* ─────────── کارفرمایان ─────────── */

export const employers: Employer[] = EMPLOYERS.map((e, i) => ({
  id: `emp-${String(i + 1).padStart(2, "0")}`,
  code: `EMP-${String(i + 1).padStart(3, "0")}`,
  name: e.name,
  shortName: e.shortName,
  type: e.type,
  nationalId: `10${randInt(rng, 10000000, 99999999)}`,
  economicCode: `411${randInt(rng, 1000000, 9999999)}`,
  contactPerson: pick(rng, CONTACT_PERSONS),
  phone: `021-${randInt(rng, 33000000, 88999999)}`,
  email: `info@emp${i + 1}.ir`,
  address: `${e.city}، خیابان صنعت، پلاک ${randInt(rng, 10, 250)}`,
}));

/* ─────────── قراردادها ─────────── */

interface ContractSpec {
  jy: 1403 | 1404 | 1405;
  status: ContractStatus;
  durMonths: number;
  amountB: [number, number]; // میلیارد ریال
}

const SPECS: ContractSpec[] = [
  { jy: 1403, status: "active", durMonths: 30, amountB: [420, 780] },
  { jy: 1403, status: "active", durMonths: 28, amountB: [300, 560] },
  { jy: 1403, status: "active", durMonths: 26, amountB: [250, 500] },
  { jy: 1403, status: "completed", durMonths: 18, amountB: [180, 340] },
  { jy: 1403, status: "terminated", durMonths: 16, amountB: [120, 260] },
  { jy: 1404, status: "active", durMonths: 24, amountB: [380, 690] },
  { jy: 1404, status: "active", durMonths: 22, amountB: [260, 520] },
  { jy: 1404, status: "active", durMonths: 20, amountB: [200, 430] },
  { jy: 1404, status: "active", durMonths: 18, amountB: [170, 380] },
  { jy: 1404, status: "suspended", durMonths: 20, amountB: [150, 330] },
  { jy: 1404, status: "completed", durMonths: 14, amountB: [140, 300] },
  { jy: 1404, status: "near-end", durMonths: 15, amountB: [220, 460] },
  { jy: 1404, status: "delayed", durMonths: 17, amountB: [190, 420] },
  { jy: 1405, status: "active", durMonths: 14, amountB: [160, 360] },
  { jy: 1405, status: "active", durMonths: 12, amountB: [130, 320] },
  { jy: 1405, status: "near-end", durMonths: 10, amountB: [110, 280] },
  { jy: 1405, status: "active", durMonths: 11, amountB: [120, 300] },
  { jy: 1405, status: "delayed", durMonths: 12, amountB: [140, 340] },
  { jy: 1405, status: "suspended", durMonths: 9, amountB: [90, 240] },
  { jy: 1405, status: "near-end", durMonths: 8, amountB: [80, 220] },
];

const employerOrder = [0, 2, 4, 6, 1, 3, 5, 7, 8, 9, 2, 0, 6, 3, 1, 4, 7, 5, 9, 8];

function contractEnd(startIso: string, months: number): Date {
  const d = new Date(startIso);
  d.setMonth(d.getMonth() + months);
  return d;
}

export const contracts: Contract[] = SPECS.map((spec, i) => {
  const n = i + 1;
  const titleObj = CONTRACT_TITLES[i % CONTRACT_TITLES.length];
  const startIso = iso(spec.jy, randInt(rng, 1, spec.jy === 1405 ? 5 : 12), randInt(rng, 1, 28));
  let end: Date = contractEnd(startIso, spec.durMonths);
  let endIso = toISO(end);
  let status = spec.status;

  if (status === "near-end") {
    end = addDays(today, randInt(rng, 15, 45));
    endIso = toISO(end);
  } else if (status === "delayed") {
    if (rng() > 0.45) {
      end = addDays(today, randInt(rng, 8, 35));
    } else {
      end = addDays(today, -randInt(rng, 15, 80));
    }
    endIso = toISO(end);
  } else if (status === "completed") {
    end = addDays(new Date(startIso), spec.durMonths * 30);
    endIso = toISO(end);
  }

  const employer = employers[employerOrder[i]];

  return {
    id: `c-${String(n).padStart(2, "0")}`,
    code: `CTR-${spec.jy}-${String(n).padStart(3, "0")}`,
    title: titleObj.title,
    subject: titleObj.subject,
    employerId: employer.id,
    creditSource: pick(rng, CREDIT_SOURCES),
    startDate: startIso,
    endDate: endIso,
    amountRial: 0, // بعد از ساخت اقلام محاسبه می‌شود
    prepaymentPercent: pick(rng, [10, 15, 20, 20, 25]),
    status,
    lastStatusDate: TODAY_ISO,
    description:
      "این قرارداد در چارچوب برنامه تأمین تجهیزات سازمان منعقد گردیده و اقلام، وزن‌ها و برنامه زمانی آن بر اساس پیوست فنی شماره یک تعیین شده است.",
    createdAt: startIso,
  };
});

/* ─────────── پیوست فنی و اقلام ─────────── */

export const appendices: TechnicalAppendix[] = [];
const allItems: TechnicalItem[] = [];
const progressLogs: ProgressLog[] = [];

const LOG_DESCRIPTIONS = [
  "تأمین مواد اولیه کامل شد",
  "مونتاژ اولیه انجام شد",
  "ماشین‌کاری و بازرسی ابعادی تأیید شد",
  "بازرسی کیفی QC با موفقیت انجام شد",
  "آزمون عملکرد مطابق پروتکل فنی قبول شد",
  "تحویل موقت به انبار پروژه",
  "نصب و راه‌اندازی در سایت کارفرما",
  "تکمیل مونتاژ نهایی و بسته‌بندی",
  "صورت‌جلسه تحویل با کارفرما امضا شد",
];

contracts.forEach((contract, ci) => {
  const spec = SPECS[ci];
  const appendixId = `ta-${contract.id}`;
  const chapters: TechnicalChapter[] = [];
  const groups: TechnicalGroup[] = [];
  const items: TechnicalItem[] = [];

  const chapterCount = contract.status === "completed" ? 4 : randInt(rng, 3, 4);
  const usedTemplates = CHAPTER_TEMPLATES.slice(0, chapterCount);
  let itemNo = 0;
  let itemIdx = randInt(rng, 0, 10);
  const rawWeights: number[] = [];

  usedTemplates.forEach((tpl, chi) => {
    const chapterId = `ch-${ci}-${chi}`;
    const groupCount = tpl.groups.length;
    const groupIds: string[] = [];

    tpl.groups.forEach((gTitle, gi) => {
      const groupId = `gr-${ci}-${chi}-${gi}`;
      const itemCount = randInt(rng, 3, 5);
      const itemIds: string[] = [];

      for (let k = 0; k < itemCount; k++) {
        const tpl2 = ITEM_POOL[(itemIdx + k * 7) % ITEM_POOL.length];
        const quantity = randInt(rng, tpl2.qMin, tpl2.qMax);
        const unitPrice = randFloat(rng, tpl2.unitPriceMin, tpl2.unitPriceMax, 0);
        itemNo++;
        const itemId = `it-${ci}-${itemNo}`;
        const duration = spec.durMonths * 30;
        const itemStartOffset = randInt(rng, 0, Math.max(10, duration - 90));
        const itemStartDate = addDays(contract.startDate, itemStartOffset);
        const itemEndDate = addDays(itemStartDate, randInt(rng, 45, 150));
        const sIso = toISO(itemStartDate);
        const eIso = toISO(itemEndDate);

        // پیشرفت برنامه‌ای بر اساس زمان
        let plan = 0;
        if (contract.status === "completed") plan = 100;
        else plan = Math.round((diffDays(sIso, TODAY_ISO) / Math.max(1, diffDays(sIso, eIso))) * 100);
        plan = Math.max(0, Math.min(100, plan));

        let progress = plan;
        if (contract.status === "completed" || contract.status === "terminated") progress = plan === 100 ? 100 : Math.min(plan + 10, 100);
        if (contract.status === "completed") progress = 100;
        else if (contract.status === "delayed") progress = Math.max(0, plan - randInt(rng, 8, 22));
        else if (contract.status === "suspended") progress = Math.max(0, plan - randInt(rng, 20, 40));
        else if (contract.status === "near-end") progress = Math.min(plan + randInt(rng, -3, 3), 98);
        else if (contract.status === "active") progress = Math.max(0, Math.min(100, plan + randInt(rng, -8, 12)));
        if (diffDays(sIso, TODAY_ISO) <= 0) progress = 0;
        progress = Math.min(progress, 100);

        let st: ItemStatus = "شروع‌نشده";
        if (progress >= 100) st = "تکمیل‌شده";
        else if (progress > 0) st = contract.status === "suspended" ? "متوقف" : "در حال اجرا";

        const weight = randFloat(rng, 3, 18, 0);
        rawWeights.push(weight);

        items.push({
          id: itemId,
          code: `K-${String(itemNo).padStart(3, "0")}`,
          title: tpl2.title,
          description: tpl2.desc,
          type: tpl2.type as ItemType,
          unit: tpl2.unit,
          quantity,
          weightPercent: weight, // بعداً نرمال می‌شود
          amount: Math.round(quantity * unitPrice / 1e6) * 1e6,
          planPercent: plan,
          progress,
          startDate: sIso,
          endDate: eIso,
          status: st,
          chapterId,
          groupId,
        });
        itemIds.push(itemId);
      }
      itemIdx += 3;
      groups.push({ id: groupId, title: gTitle, chapterId, itemIds });
      groupIds.push(groupId);
    });
    chapters.push({ id: chapterId, title: tpl.title, groupIds });
  });

  // نرمال‌سازی وزن‌ها به ۱۰۰٪
  const wSum = rawWeights.reduce((a, b) => a + b, 0);
  items.forEach((it) => {
    it.weightPercent = Math.round((it.weightPercent / wSum) * 1000) / 10;
  });

  appendices.push({
    id: appendixId,
    contractId: contract.id,
    version: `0${randInt(rng, 1, 3)}`,
    revisionDate: toISO(addDays(contract.startDate, randInt(rng, 10, 25))),
    chapters,
    groups,
    items,
  });
  allItems.push(...items);

  // مبلغ قرارداد = جمع اقلام + ۱۲٪ سرباری
  const itemsSum = items.reduce((a, it) => a + it.amount, 0);
  contract.amountRial = Math.round((itemsSum * 1.12) / 1e6) * 1e6;

  // قرارداد ارزی برای برخی
  if (rng() > 0.72) {
    contract.currency = "دلار";
    contract.exchangeRate = randInt(rng, 60000, 95000) * 1000;
    contract.amountForeign = Math.round((contract.amountRial / (contract.exchangeRate || 1)) / 1000) * 1000;
  }

  // سابقه پیشرفت اقلام
  items.forEach((it) => {
    if (it.progress <= 0) return;
    const steps = randInt(rng, 2, 5);
    let prev = 0;
    for (let s = 1; s <= steps; s++) {
      const target = Math.round((it.progress * s) / steps);
      const logDate = addDays(it.startDate, Math.round((diffDays(it.startDate, TODAY_ISO) * s) / (steps + 0.5)));
      if (target === prev || diffDays(TODAY_ISO, toISO(logDate)) < 0) {
        prev = target;
        continue;
      }
      progressLogs.push({
        id: `pl-${ci}-${it.code}-${s}`,
        itemId: it.id,
        contractId: contract.id,
        date: toISO(logDate),
        previous: prev,
        current: target,
        description: pick(rng, LOG_DESCRIPTIONS),
        user: pick(rng, USERS_POOL).firstName + " " + pick(rng, USERS_POOL).lastName,
      });
      prev = target;
    }
  });
});

export const technicalItems = allItems;
export const logs: ProgressLog[] = progressLogs;

/* ─────────── خرید و ساخت ─────────── */

export const purchases: Purchase[] = [];
const PURCHASE_STATUS: PurchaseStatus[] = ["ثبت‌شده", "در حال تأمین", "تحویل‌شده", "تحویل‌شده", "تحویل‌شده"];
let prcNo = 0;

contracts.forEach((contract, ci) => {
  const appendix = appendices[ci];
  const count = randInt(rng, 2, 3);
  for (let p = 0; p < count; p++) {
    if (purchases.length >= 52) break;
    const it = pick(rng, appendix.items);
    prcNo++;
    const d = addDays(contract.startDate, randInt(rng, 10, Math.max(20, diffDays(contract.startDate, TODAY_ISO) - 5)));
    purchases.push({
      id: `prc-${prcNo}`,
      code: `PRC-${randInt(rng, 1404, 1405)}-${String(prcNo).padStart(3, "0")}`,
      contractId: contract.id,
      itemId: it.id,
      type: it.type === "ساخت" || it.type === "مونتاژ" ? "ساخت" : "خرید",
      description: `تأمین ${it.title} مطابق مشخصات فنی قلم ${it.code}`,
      supplier: it.type === "ساخت" ? "کارگاه ساخت داخلی – واحد فابریکاسیون" : pick(rng, SUPPLIERS),
      date: toISO(d),
      unitPrice: Math.round((it.amount / Math.max(1, it.quantity)) / 1e6) * 1e6,
      quantity: Math.max(1, Math.round(it.quantity * randFloat(rng, 0.3, 1, 1))),
      unit: it.unit,
      status: contract.status === "completed" ? "تحویل‌شده" : pick(rng, PURCHASE_STATUS),
    });
  }
});

/* ─────────── صورت‌وضعیت‌ها ─────────── */

export const statements: Statement[] = [];
let svTotal = 0;

contracts.forEach((contract, ci) => {
  const count = contract.status === "completed" ? randInt(rng, 3, 5) : randInt(rng, 1, 4);
  let cum = 0;
  for (let s = 0; s < count; s++) {
    if (statements.length >= 41) break;
    svTotal++;
    const fraction = randFloat(rng, 0.08, 0.22, 2);
    const gross = Math.round((contract.amountRial * fraction) / 1e6) * 1e6;
    cum += gross;
    if (cum > contract.amountRial * 0.95) break;
    const d = addDays(contract.startDate, Math.round(((diffDays(contract.startDate, TODAY_ISO)) * (s + 1)) / (count + 1)) + randInt(rng, 0, 15));
    let status: StatementStatus = "تأیید شده";
    const age = diffDays(toISO(d), TODAY_ISO);
    if (age < 12) status = pick(rng, ["پیش‌نویس", "در انتظار تأیید"] as StatementStatus[]);
    else if (age < 35) status = "در انتظار تأیید";
    else if (contract.status === "suspended") status = "در انتظار تأیید";
    else status = pick(rng, ["پرداخت شده", "پرداخت شده", "تأیید شده"] as StatementStatus[]);
    statements.push({
      id: `sv-${svTotal}`,
      code: `SV-${String(svTotal).padStart(3, "0")}`,
      contractId: contract.id,
      number: s + 1,
      date: toISO(d),
      description: `صورت‌وضعیت شماره ${s + 1} قرارداد ${contract.code} شامل اقلام تحویل‌شده طبق پیوست فنی`,
      grossAmount: gross,
      vatPercent: 10,
      finalAmount: Math.round(gross * 1.1),
      status,
    });
  }
});

/* ─────────── دریافتی‌ها ─────────── */

export const payments: Payment[] = [];
let payNo = 0;

// پیش‌پرداخت‌ها
contracts.forEach((contract, ci) => {
  if (ci % 3 !== 0 || payments.length >= 8) return;
  payNo++;
  const d = addDays(contract.startDate, randInt(rng, 5, 20));
  payments.push({
    id: `pay-${payNo}`,
    code: `PAY-${randInt(rng, 1404, 1405)}-${String(payNo).padStart(3, "0")}`,
    contractId: contract.id,
    amount: Math.round((contract.amountRial * contract.prepaymentPercent) / 100 / 1e6) * 1e6,
    date: toISO(d),
    method: "حواله بانکی",
    reference: `HV-${randInt(rng, 100000, 999999)}`,
    description: "پیش‌پرداخت قرارداد مطابق شرح شرایط",
  });
});

// پرداخت صورت‌وضعیت‌ها
statements.forEach((st) => {
  if (st.status !== "پرداخت شده") return;
  const parts = randInt(rng, 1, 3);
  let remaining = st.finalAmount;
  for (let p = 0; p < parts; p++) {
    if (payments.length >= 62) break;
    const isLast = p === parts - 1;
    const amount = isLast ? remaining : Math.round((st.finalAmount * randFloat(rng, 0.25, 0.55, 2)) / 1e6) * 1e6;
    remaining -= amount;
    if (amount <= 0) break;
    payNo++;
    payments.push({
      id: `pay-${payNo}`,
      code: `PAY-${randInt(rng, 1404, 1405)}-${String(payNo).padStart(3, "0")}`,
      contractId: st.contractId,
      statementId: st.id,
      amount,
      date: toISO(addDays(st.date, randInt(rng, 10, 45))),
      method: pick(rng, ["حواله بانکی", "چک", "انتقال بین‌بانکی"] as const),
      reference: isLast ? `HV-${randInt(rng, 100000, 999999)}` : `CH-${randInt(rng, 1000000, 9999999)}`,
      description: `پرداخت ${st.code} – ${parts > 1 ? `قسط ${p + 1} از ${parts}` : "تسویه کامل"}`,
    });
  }
});

/* ─────────── الحاقیه‌ها ─────────── */

export const amendments: Amendment[] = [];
const AMD_DESCS = [
  "افزایش تعداد اقلام پیوست فنی به درخواست کارفرما",
  "تمدید مدت قرارداد به دلیل تغییرات طراحی",
  "افزایش قیمت با احتساب مصوبات شورای رقابت",
  "تغییر مشخصات فنی برخی اقلام و اصلاح نقشه‌ها",
  "افزودن فصل جدید به پیوست فنی قرارداد",
  "کاهش بخشی از اقلام به دلیل تغییر برنامه تولید کارفرما",
];
contracts.forEach((contract, ci) => {
  if (ci % 3 !== 1) return;
  const count = randInt(rng, 1, 2);
  for (let a = 0; a < count; a++) {
    const inc = rng() > 0.3;
    amendments.push({
      id: `amd-${ci}-${a}`,
      code: `الحاقیه ${toFaNum(a + 1)}`,
      contractId: contract.id,
      date: toISO(addDays(contract.startDate, randInt(rng, 60, 200))),
      description: pick(rng, AMD_DESCS),
      amountChange: inc
        ? Math.round((contract.amountRial * randFloat(rng, 0.03, 0.15, 2)) / 1e6) * 1e6
        : -Math.round((contract.amountRial * randFloat(rng, 0.02, 0.08, 2)) / 1e6) * 1e6,
      durationChangeDays: pick(rng, [0, 15, 30, 30, 45, 60, -20]),
      status: pick(rng, ["تأیید شده", "تأیید شده", "در حال بررسی"] as const),
      fileName: `الحاقیه ${String(a + 1).padStart(2, "0")}.pdf`,
    });
  }
});

function toFaNum(n: number): string {
  return String(n).replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
}

/* ─────────── اسناد ─────────── */

export const documents: DocumentFile[] = [];
contracts.forEach((contract, ci) => {
  const year = contract.code.split("-")[1];
  documents.push(
    {
      id: `doc-${ci}-1`, name: `قرارداد اصلی ${contract.code}.pdf`, kind: "قرارداد اصلی",
      sizeKb: randInt(rng, 800, 4200), version: 1, date: contract.startDate,
      uploader: "مریم حسینی", contractId: contract.id, fileType: "pdf",
    },
    {
      id: `doc-${ci}-2`, name: `پیوست فنی - نسخه ۰${appendices[ci].version}.pdf`, kind: "پیوست فنی",
      sizeKb: randInt(rng, 1200, 6800), version: Number(appendices[ci].version),
      date: toISO(addDays(contract.startDate, randInt(rng, 8, 30))),
      uploader: pick(rng, USERS_POOL).firstName + " " + pick(rng, USERS_POOL).lastName,
      contractId: contract.id, fileType: "pdf",
    },
    {
      id: `doc-${ci}-3`, name: `لیست اقلام ${contract.code}.xlsx`, kind: "لیست اقلام",
      sizeKb: randInt(rng, 120, 900), version: 1,
      date: toISO(addDays(contract.startDate, randInt(rng, 10, 35))),
      uploader: pick(rng, USERS_POOL).firstName + " " + pick(rng, USERS_POOL).lastName,
      contractId: contract.id, fileType: "xlsx",
    }
  );
  const cAmendments = amendments.filter((a) => a.contractId === contract.id);
  cAmendments.forEach((a, ai) => {
    documents.push({
      id: `doc-${ci}-a${ai}`, name: `${a.code} ${contract.code}.pdf`, kind: "الحاقیه",
      sizeKb: randInt(rng, 300, 1800), version: ai + 1, date: a.date,
      uploader: "مریم حسینی", contractId: contract.id, fileType: "pdf",
    });
  });
  if (statements.filter((s) => s.contractId === contract.id).length > 0) {
    documents.push({
      id: `doc-${ci}-4`, name: `صورتجلسه تحویل ${contract.code}.pdf`, kind: "صورتجلسه",
      sizeKb: randInt(rng, 200, 1400), version: 1,
      date: toISO(addDays(contract.startDate, randInt(rng, 90, 250))),
      uploader: pick(rng, USERS_POOL).firstName + " " + pick(rng, USERS_POOL).lastName,
      contractId: contract.id, fileType: "pdf",
    });
  }
  if (ci % 4 === 0) {
    documents.push({
      id: `doc-${ci}-5`, name: `نقشه فنی مونتاژ ${year}.dwg`, kind: "گزارش فنی",
      sizeKb: randInt(rng, 2400, 9800), version: 2,
      date: toISO(addDays(contract.startDate, randInt(rng, 20, 60))),
      uploader: pick(rng, USERS_POOL).firstName + " " + pick(rng, USERS_POOL).lastName,
      contractId: contract.id, fileType: "dwg",
    });
  }
});
// اسناد عمومی
documents.push(
  { id: "doc-gen-1", name: "آیین‌نامه تدوین قراردادها.pdf", kind: "سایر", sizeKb: 2200, version: 1, date: iso(1403, 2, 10), uploader: "رضا کریمی", fileType: "pdf" },
  { id: "doc-gen-2", name: "فرم استاندارد صورت‌وضعیت.xlsx", kind: "سایر", sizeKb: 340, version: 2, date: iso(1403, 5, 2), uploader: "زهرا موسوی", fileType: "xlsx" },
  { id: "doc-gen-3", name: "دستورالعمل بازرسی کیفی اقلام.pdf", kind: "سایر", sizeKb: 1650, version: 1, date: iso(1404, 1, 25), uploader: "علی اکبرزاده", fileType: "pdf" }
);

/* ─────────── کاربران ─────────── */

export const users: User[] = USERS_POOL.map((u, i) => ({
  id: `u-${String(i + 1).padStart(3, "0")}`,
  username: u.username,
  firstName: u.firstName,
  lastName: u.lastName,
  role: u.role,
  active: rng() > 0.12,
  lastLogin: toISO(addDays(today, -randInt(rng, 0, 20))) + "T0" + randInt(rng, 8, 17) + ":30:00",
  email: u.email,
}));

/* ─────────── فعالیت‌ها ─────────── */

export const activities: Activity[] = [];
{
  const push = (a: Omit<Activity, "id">) =>
    activities.push({ id: `act-${activities.length + 1}`, ...a });

  contracts.slice(0, 14).forEach((c, i) => {
    push({ contractId: c.id, kind: "contract", title: `قرارداد ${c.code} ایجاد شد`, description: c.title, date: c.startDate, user: "مریم حسینی" });
    push({ contractId: c.id, kind: "appendix", title: `پیوست فنی ثبت شد`, description: `ساختار اقلام و وزن‌های قرارداد ${c.code} تعریف گردید`, date: toISO(addDays(c.startDate, 12)), user: "علی اکبرزاده" });
  });
  purchases.slice(0, 22).forEach((p) => {
    push({ contractId: p.contractId, kind: "purchase", title: `${p.type === "خرید" ? "خرید" : "سفارش ساخت"} ${p.code} ثبت شد`, description: `${p.description} — ${p.supplier}`, date: p.date, user: "حسین قنبری" });
  });
  statements.slice(0, 18).forEach((s) => {
    push({ contractId: s.contractId, kind: "statement", title: `صورت‌وضعیت ${s.code} ثبت شد`, description: s.description, date: s.date, user: "زهرا موسوی" });
  });
  payments.slice(0, 20).forEach((p) => {
    push({ contractId: p.contractId, kind: "payment", title: `دریافت ${p.code} ثبت شد`, description: p.description || "دریافت وجه از کارفرما", date: p.date, user: "زهرا موسوی" });
  });
  amendments.forEach((a) => {
    push({ contractId: a.contractId, kind: "amendment", title: `${a.code} ایجاد شد`, description: a.description, date: a.date, user: "مریم حسینی" });
  });
  activities.sort((x, y) => (x.date < y.date ? 1 : -1));
}

/* ─────────── اعلان‌ها ─────────── */

export const notifications: Notification[] = [
  { id: "n-1", kind: "warning", title: "قرارداد نزدیک به پایان", description: "قرارداد CTR-1404-012 تا کمتر از یک ماه دیگر پایان می‌یابد؛ اقدام به تمدید یا خاتمه کنید.", date: toISO(addDays(today, -1)), read: false, link: "contracts/c-12" },
  { id: "n-2", kind: "danger", title: "صورت‌وضعیت پرداخت‌نشده", description: "صورت‌وضعیت SV-021 تأیید شده اما تاکنون هیچ دریافتی برای آن ثبت نشده است.", date: toISO(addDays(today, -2)), read: false, link: "statements" },
  { id: "n-3", kind: "danger", title: "انحراف پیشرفت از برنامه", description: "پیشرفت واقعی قرارداد CTR-1405-018 حدود ۱۲٪ از برنامه عقب است.", date: toISO(addDays(today, -2)), read: false, link: "contracts/c-18/progress" },
  { id: "n-4", kind: "success", title: "دریافت جدید ثبت شد", description: "مبلغ پیش‌پرداخت قرارداد CTR-1405-014 با موفقیت ثبت شد.", date: toISO(addDays(today, -3)), read: true, link: "payments" },
  { id: "n-5", kind: "info", title: "پیوست فنی نسخه جدید", description: "پیوست فنی نسخه ۰۳ برای قرارداد CTR-1404-006 بارگذاری شد.", date: toISO(addDays(today, -4)), read: true, link: "contracts/c-06/technical-appendix" },
  { id: "n-6", kind: "warning", title: "الحاقیه در انتظار تأیید", description: "الحاقیه شماره ۲ قرارداد CTR-1404-007 در وضعیت «در حال بررسی» است.", date: toISO(addDays(today, -5)), read: true, link: "contracts/c-07/amendments" },
  { id: "n-7", kind: "danger", title: "قرارداد دارای تأخیر", description: "قرارداد CTR-1404-013 بیش از زمان‌بندی برنامه‌ای عقب است و نیازمند اقدام اصلاحی است.", date: toISO(addDays(today, -6)), read: false, link: "contracts/c-13/progress" },
  { id: "n-8", kind: "success", title: "سند جدید بارگذاری شد", description: "صورتجلسه تحویل قرارداد CTR-1403-004 آپلود شد.", date: toISO(addDays(today, -7)), read: true, link: "documents" },
  { id: "n-9", kind: "info", title: "خرید تحویل شد", description: "سفارش خرید PRC-1405-018 با موفقیت به انبار پروژه تحویل داده شد.", date: toISO(addDays(today, -8)), read: true, link: "purchases" },
  { id: "n-10", kind: "warning", title: "اقلام متوقف‌شده", description: "برخی اقلام پیوست فنی قرارداد CTR-1404-010 در وضعیت «متوقف» قرار دارند.", date: toISO(addDays(today, -9)), read: true, link: "contracts/c-10/technical-appendix" },
  { id: "n-11", kind: "info", title: "گزارش ماهانه آماده است", description: "گزارش مالی مرداد ۱۴۰۵ تولید شد و قابل دریافت است.", date: toISO(addDays(today, -11)), read: true, link: "reports" },
  { id: "n-12", kind: "success", title: "تسویه کامل صورت‌وضعیت", description: "صورت‌وضعیت SV-008 به‌طور کامل تسویه شد.", date: toISO(addDays(today, -13)), read: true, link: "statements" },
];
