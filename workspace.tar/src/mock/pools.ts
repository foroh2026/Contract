/* ═══════════════════════════════════════════════════════════
   مولدهای داده Mock — واقع‌گرایانه، قطعی (Deterministic)
   ═══════════════════════════════════════════════════════════ */

/** مولد اعداد شبه‌تصادفی قطعی */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type Rng = () => number;

export const pick = <T>(rng: Rng, arr: T[]): T => arr[Math.floor(rng() * arr.length)];

export const randInt = (rng: Rng, min: number, max: number): number =>
  Math.floor(rng() * (max - min + 1)) + min;

export const randFloat = (rng: Rng, min: number, max: number, digits = 1): number => {
  const v = rng() * (max - min) + min;
  const p = Math.pow(10, digits);
  return Math.round(v * p) / p;
};

/* ─────────── کارفرمایان ─────────── */

export const EMPLOYERS = [
  { name: "شرکت صنایع خودرو سازی ایران", shortName: "ایران خودرو", type: "دولتی" as const, city: "تهران" },
  { name: "گروه صنعتی ایران ماشین‌سازی", shortName: "ایران ماشین‌سازی", type: "خصوصی" as const, city: "تبریز" },
  { name: "شرکت ملی صنایع مس ایران", shortName: "ملی مس", type: "دولتی" as const, city: "تهران" },
  { name: "سازمان صنایع هوایی کشور", shortName: "صنایع هوایی", type: "دولتی" as const, city: "تهران" },
  { name: "گروه صنعتی پارس متالورژی", shortName: "پارس متالورژی", type: "خصوصی" as const, city: "اصفهان" },
  { name: "شرکت مهندسی و ساخت تجهیزات نفت", shortName: "اوتک", type: "نیمه‌دولتی" as const, city: "تهران" },
  { name: "صنایع فولاد مبارکه اصفهان", shortName: "فولاد مبارکه", type: "دولتی" as const, city: "اصفهان" },
  { name: "شرکت صنایع تجهیزات دفاعی پیشرو", shortName: "تجهیزات دفاعی پیشرو", type: "دولتی" as const, city: "تهران" },
  { name: "شرکت ماشین‌سازی تبریز", shortName: "ماشین‌سازی تبریز", type: "خصوصی" as const, city: "تبریز" },
  { name: "شرکت توسعه صنایع سنگ‌شکن", shortName: "صنایع سنگ‌شکن", type: "خصوصی" as const, city: "کرمان" },
];

export const CONTACT_PERSONS = [
  "مهندس علیرضا محمودی", "مهندس فرشاد رستمی", "مهندس مهدی کاظمی‌پور",
  "مهندس سعید نیک‌پور", "مهندس حمیدرضا صادقی", "مهندس بهنام عزیزی",
  "مهندس کامران فرهادی", "مهندس مصطفی جباری",
];

/* ─────────── قراردادها ─────────── */

export const CONTRACT_TITLES: { title: string; subject: string }[] = [
  { title: "تأمین قطعات موتور و سیستم انتقال قدرت ناوگان سنگین", subject: "خرید قطعات موتور، گیربکس و دیفرانسیل ناوگان کامیون" },
  { title: "ساخت و تحویل گیربکس صنعتی مدل GH-500", subject: "طراحی و ساخت گیربکس صنعتی مطابق نقشه فنی کارفرما" },
  { title: "خرید و تأمین تجهیزات هیدرولیک خط تولید", subject: "تأمین سیلندر، پمپ و شیرآلات هیدرولیک خط مونتاژ" },
  { title: "تأمین قطعات یدکی موتورهای دیزل خانواده EF7", subject: "خرید قطعات مصرفی و یدکی موتور ملی" },
  { title: "ساخت بدنه و شاسی تجهیزات جابه‌جایی مواد", subject: "فابریکاسیون و رنگ‌آمیزی سازه‌های فلزی" },
  { title: "تأمین سیستم برق و کنترل تابلوهای صنعتی", subject: "ساخت تابلو برق PLC و اسنبیز خطوط تولید" },
  { title: "خرید بلبرینگ و قطعات انتقال حرارت", subject: "تأمین یاتاقان و مبدل حرارتی تجهیزات کارخانه" },
  { title: "ساخت قطعات مکانیکی دقیق ابزارسازی", subject: "ماشین‌کاری قطعات دقیق مطابق نقشه CAD" },
  { title: "تأمین و مونتاژ سیستم تعلیق پنوماتیکی", subject: "خرید و نصب سیستم تعلیق تجهیزات متحرک" },
  { title: "بازسازی و بهینه‌سازی موتورهای دیزل صنعتی", subject: "اورهال موتورهای دیزل کارگاهی و آزمون فنی" },
  { title: "تأمین قطعات خودرو سواری خانواده پژو", subject: "خرید قطعات پرس، شاسی و بدنه" },
  { title: "ساخت مخازن تحت فشار و لوله‌کشی صنعتی", subject: "ساخت مخزن، تست هیدرواستاتیک و نصب" },
  { title: "تأمین تجهیزات پنوماتیک کارگاه مونتاژ", subject: "خرید کمپرسور، آکچواتور و تجهیزات باد" },
  { title: "خرید و ساخت ابزار و فیکسچرهای مونتاژ", subject: "طراحی و ساخت جیگ و فیکسچر خط تولید" },
  { title: "تأمین قطعات سیستم سوخت‌رسانی و انژکتور", subject: "خرید پمپ بنزین، انژکتور و ریل سوخت" },
  { title: "ساخت نوار نقاله و سیستم‌های انتقال مواد", subject: "ساخت و نصب کانوایر خط بسته‌بندی" },
  { title: "تأمین قطعات یدکی ماشین‌آلات راه‌سازی", subject: "خرید قطعات لودر، بیل مکانیکی و غلتک" },
  { title: "پروژه تأمین تجهیزات تخصصی صنایع دفاعی", subject: "تأمین قطعات و مجموعه‌های مکانیکی مطابق مشخصات فنی" },
  { title: "تأمین و نصب تجهیزات آزمون و اندازه‌گیری", subject: "خرید دستگاه‌های مترولوژی و کالیبراسیون" },
  { title: "ساخت قطعات ریخته‌گری و فورج قطعات خودرو", subject: "تأمین قطعات ریختگی و آهنگری مطابق نقشه" },
];

export const CREDIT_SOURCES = [
  "بودجه عمومی", "بودجه عمرانی", "اعتبارات اختصاصی طرح", "منابع داخلی شرکت",
  "فصل تأمین کالا", "اعتبارات پروژه‌های ملی", "بودجه تحقیق و توسعه",
];

/* ─────────── اقلام پیوست فنی ─────────── */

export interface ItemTemplate {
  title: string; desc: string; type: string; unit: string;
  qMin: number; qMax: number; unitPriceMin: number; unitPriceMax: number;
}

export const ITEM_POOL: ItemTemplate[] = [
  { title: "موتور کامل دیزل EF7", desc: "موتور دیزل چهار سیلندر توربو شارژ مطابق استاندارد یورو ۴", type: "خرید", unit: "دستگاه", qMin: 2, qMax: 12, unitPriceMin: 8e9, unitPriceMax: 15e9 },
  { title: "میل‌لنگ فورج‌شده", desc: "میل‌لنگ آهنگری‌شده با عملیات حرارتی و سنگ‌زنی دقیق", type: "خرید", unit: "عدد", qMin: 10, qMax: 60, unitPriceMin: 2.5e8, unitPriceMax: 6e8 },
  { title: "سرسیلندر آلومینیومی", desc: "سرسیلندر ۱۶ سوپاپ با نشیمن سوپاپ تقویت‌شده", type: "خرید", unit: "عدد", qMin: 8, qMax: 40, unitPriceMin: 1.8e8, unitPriceMax: 4e8 },
  { title: "پمپ روغن فشار قوی", desc: "پمپ روغن دنده‌ای با فشار کاری ۵ بار", type: "خرید", unit: "عدد", qMin: 15, qMax: 80, unitPriceMin: 4e7, unitPriceMax: 9e7 },
  { title: "فیلتر روغن صنعتی", desc: "فیلتر روغن اسپین-آن مطابق مشخصات OEM", type: "خرید", unit: "عدد", qMin: 50, qMax: 300, unitPriceMin: 8e6, unitPriceMax: 2e7 },
  { title: "فیلتر هوای موتور", desc: "فیلتر هوای پنلی با کاغذ سلولوز رزین‌اندود", type: "خرید", unit: "عدد", qMin: 50, qMax: 250, unitPriceMin: 6e6, unitPriceMax: 1.5e7 },
  { title: "انژکتور سوخت رایلی", desc: "انژکتور Common Rail با نازل پیزوالکتریک", type: "خرید", unit: "عدد", qMin: 20, qMax: 120, unitPriceMin: 1.2e8, unitPriceMax: 2.8e8 },
  { title: "توربوشارژر GT-30", desc: "توربوشارژر با چرخ کامپوزیت و یاتاقان روغنی", type: "خرید", unit: "دستگاه", qMin: 5, qMax: 30, unitPriceMin: 9e8, unitPriceMax: 1.6e9 },
  { title: "گیربکس ۵ سرعته دستی", desc: "گیربکس دستی ۵ سرعته با نسبت‌های استاندارد کارخانه", type: "ساخت", unit: "دستگاه", qMin: 4, qMax: 25, unitPriceMin: 4.5e9, unitPriceMax: 9e9 },
  { title: "دیسک و صفحه کلاچ", desc: "کلاچ خشک تک‌صفحه‌ای با فنر مارپیچ", type: "خرید", unit: "ست", qMin: 20, qMax: 100, unitPriceMin: 1.5e8, unitPriceMax: 3.5e8 },
  { title: "فلایویل دوتوده", desc: "فلایویل چدنی بالانس‌شده دینامیکی", type: "ساخت", unit: "عدد", qMin: 15, qMax: 60, unitPriceMin: 2e8, unitPriceMax: 5e8 },
  { title: "شفت گاردان انتقال قدرت", desc: "شفت کاردان با کوپلینگ فلزی و بالانس ISO G6.3", type: "ساخت", unit: "عدد", qMin: 10, qMax: 40, unitPriceMin: 3e8, unitPriceMax: 7e8 },
  { title: "دیفرانسیل کامل عقب", desc: "دیفرانسیل با نسبت ۴/۱ و قفل دیفرانسیل", type: "ساخت", unit: "دستگاه", qMin: 4, qMax: 20, unitPriceMin: 3.8e9, unitPriceMax: 8e9 },
  { title: "جعبه فرمان هیدرولیک", desc: "جعبه فرمان با کمک هیدرولیک و شیر کنترل", type: "خرید", unit: "عدد", qMin: 10, qMax: 50, unitPriceMin: 6e8, unitPriceMax: 1.2e9 },
  { title: "سیلندر هیدرولیک دوطرفه", desc: "سیلندر با کورس ۸۰۰ میلی‌متر و فشار ۲۱۰ بار", type: "خرید", unit: "دستگاه", qMin: 8, qMax: 35, unitPriceMin: 5e8, unitPriceMax: 1.1e9 },
  { title: "پمپ هیدرولیک دنده‌ای", desc: "پمپ دنده‌ای با دبی ۶۰ لیتر بر دقیقه", type: "خرید", unit: "دستگاه", qMin: 10, qMax: 45, unitPriceMin: 3.2e8, unitPriceMax: 7e8 },
  { title: "شیر کنترل جهت‌دار هیدرولیک", desc: "شیر ۴/۳ با عملگر سلونوئید ۲۴ ولت", type: "خرید", unit: "عدد", qMin: 20, qMax: 90, unitPriceMin: 8e7, unitPriceMax: 2e8 },
  { title: "تابلو برق صنعتی PLC", desc: "تابلو کنترل با PLC، HMI و رله‌های کمکی مطابق استاندارد IEC", type: "ساخت", unit: "دستگاه", qMin: 2, qMax: 10, unitPriceMin: 6e9, unitPriceMax: 14e9 },
  { title: "اینورتر صنعتی ۵۵ کیلووات", desc: "درایو فرکانس متغیر با فیلتر EMC و پروتکل Modbus", type: "خرید", unit: "دستگاه", qMin: 3, qMax: 15, unitPriceMin: 8e8, unitPriceMax: 1.8e9 },
  { title: "موتور برق آسنکرون سه‌فاز", desc: "موتور القایی ۹۰ کیلووات کلاس عایق F و IP55", type: "خرید", unit: "دستگاه", qMin: 4, qMax: 20, unitPriceMin: 6.5e8, unitPriceMax: 1.4e9 },
  { title: "سنسور دما و فشار PT100", desc: "ترانسمیتر دما/فشار با خروجی ۴ تا ۲۰ میلی‌آمپر", type: "خرید", unit: "عدد", qMin: 30, qMax: 150, unitPriceMin: 3e7, unitPriceMax: 8e7 },
  { title: "ECU موتور با نقشه اختصاصی", desc: "واحد کنترل الکترونیکی موتور با کالیبراسیون اختصاصی", type: "خرید", unit: "دستگاه", qMin: 5, qMax: 25, unitPriceMin: 1.5e9, unitPriceMax: 3e9 },
  { title: "شاسی جوشی تجهیزات", desc: "سازه جوشی فولاد ST37 با گانتریز و رنگ اپوکسی", type: "ساخت", unit: "دستگاه", qMin: 3, qMax: 15, unitPriceMin: 2.2e9, unitPriceMax: 5e9 },
  { title: "کابین اپراتور ROPS", desc: "کابین ایمن با شیشه ایمنی، سیستم تهویه و صندلی ارگونومیک", type: "ساخت", unit: "دستگاه", qMin: 2, qMax: 12, unitPriceMin: 2.8e9, unitPriceMax: 6e9 },
  { title: "بلبرینگ سوزنی صنعتی", desc: "یاتاقان سوزنی تحمل بار سنگین مطابق ISO 15", type: "خرید", unit: "عدد", qMin: 80, qMax: 400, unitPriceMin: 1.2e7, unitPriceMax: 4e7 },
  { title: "چرخ‌دنده محوری ماژول ۴", desc: "چرخ‌دنده سیلندری شیار مستقیم با سخت‌کاری القایی", type: "ساخت", unit: "عدد", qMin: 40, qMax: 200, unitPriceMin: 5e7, unitPriceMax: 1.5e8 },
  { title: "ورق گالوانیزه ۲ میلی‌متر", desc: "ورق گالوانیزه گرم مطابق استاندارد EN 10346", type: "خرید", unit: "کیلوگرم", qMin: 2000, qMax: 12000, unitPriceMin: 4.5e5, unitPriceMax: 7e5 },
  { title: "پروفیل فولادی قوطی ۸۰×۴۰", desc: "پروفیل قوطی با ضخامت ۳ میلی‌متر و کیفیت ST52", type: "خرید", unit: "کیلوگرم", qMin: 3000, qMax: 15000, unitPriceMin: 3.8e5, unitPriceMax: 6e5 },
  { title: "کمپرسور پیستونی ۱۰ بار", desc: "کمپرسور هوا با مخزن ۵۰۰ لیتری و خشک‌کن", type: "خرید", unit: "دستگاه", qMin: 2, qMax: 8, unitPriceMin: 2.5e9, unitPriceMax: 6e9 },
  { title: "دیسک ترمز خنک‌شونده", desc: "دیسک ترمز ونتاریته چدنی با پوشش ضدخوردگی", type: "خرید", unit: "عدد", qMin: 30, qMax: 150, unitPriceMin: 8e7, unitPriceMax: 2.2e8 },
  { title: "کمک فنر گازوئیل سنگین", desc: "کمک فنر دو لوله با روغن ویسکوزیته مخصوص", type: "خرید", unit: "عدد", qMin: 40, qMax: 200, unitPriceMin: 6e7, unitPriceMax: 1.6e8 },
  { title: "سیستم تعلیق پنوماتیک کامل", desc: "بسته کیسه بادی، کمپرسور و سیستم کنترل سطح", type: "تأمین", unit: "ست", qMin: 4, qMax: 18, unitPriceMin: 1.8e9, unitPriceMax: 4e9 },
  { title: "زنجیر انتقال قدرت سه‌ردیفه", desc: "زنجیر رولری استاندارد ANSI 80 با پین‌های تقویتی", type: "خرید", unit: "متر", qMin: 100, qMax: 600, unitPriceMin: 8e6, unitPriceMax: 2e7 },
  { title: "تسمه تایم دنده‌ای", desc: "تسمه دندانه‌ای با آجار کورد آرامید", type: "خرید", unit: "عدد", qMin: 60, qMax: 300, unitPriceMin: 1.5e7, unitPriceMax: 4e7 },
  { title: "رادیاتور آب موتور سنگین", desc: "رادیاتور آلومینیومی با هسته جوش‌سخت و فن هیدرولیک", type: "خرید", unit: "دستگاه", qMin: 6, qMax: 30, unitPriceMin: 4.5e8, unitPriceMax: 9e8 },
  { title: "مبدل حرارتی صفحه‌ای", desc: "مبدل پلیت با سطح ۲۰ متر مربع فولاد زنگ‌نزن", type: "خرید", unit: "دستگاه", qMin: 2, qMax: 10, unitPriceMin: 1.2e9, unitPriceMax: 3e9 },
  { title: "جیگ و فیکسچر مونتاژ", desc: "ابزار نگهدارنده مونتاژ با هاردستاپ و پین مکانیکی", type: "ساخت", unit: "دستگاه", qMin: 4, qMax: 16, unitPriceMin: 7e8, unitPriceMax: 1.8e9 },
  { title: "نوار نقاله مدولار صنعتی", desc: "کانوایر با تسمه مدولار و موتورگیربکس سیکلوئید", type: "ساخت", unit: "متر", qMin: 40, qMax: 200, unitPriceMin: 2.2e8, unitPriceMax: 5e8 },
  { title: "دستگاه آزمون فشار هیدرواستاتیک", desc: "میز تست فشار تا ۴۰۰ بار با ثبت داده", type: "خرید", unit: "دستگاه", qMin: 1, qMax: 4, unitPriceMin: 1.2e10, unitPriceMax: 2.5e10 },
  { title: "خدمات اورهال و راه‌اندازی", desc: "اورهال کامل، آزمون عملکرد و آموزش اپراتور", type: "خدمات فنی", unit: "فقره", qMin: 2, qMax: 10, unitPriceMin: 5e8, unitPriceMax: 1.5e9 },
];

export const CHAPTER_TEMPLATES = [
  {
    title: "سیستم موتور و پیشرانه",
    groups: ["موتور کامل و متعلقات", "قطعات داخلی موتور", "سیستم سوخت‌رسانی و خنک‌کاری"],
  },
  {
    title: "سیستم انتقال قدرت",
    groups: ["گیربکس و کلاچ", "شفت و دیفرانسیل"],
  },
  {
    title: "سیستم برق و کنترل",
    groups: ["تابلو و تجهیزات برق قدرت", "سنسورها و سیستم کنترل"],
  },
  {
    title: "بدنه، سازه و تجهیزات جانبی",
    groups: ["سازه‌های فلزی", "تجهیزات تعلیق و ترمز"],
  },
];

/* ─────────── تأمین‌کنندگان ─────────── */

export const SUPPLIERS = [
  "شرکت فولاد فامکو", "پارس هیدرولیک صنعت", "آریا موتورپلاست",
  "تجهیز صنعتی بهران", "کویر زنجان قطعه", "مکانیک صنعت اصفهان",
  "بلبرینگ ایران (BERK)", "پویا باتری صنعت", "هیدرولیک تبریز",
  "آذرآب صنعت کاشان", "قطعات ماشین کاوه", "کمپرسورسازی تهران",
  "فولاد آلیاژی یزد", "پیشگامان اتوماسیون پارس",
];

/* ─────────── کاربران ─────────── */

export const USERS_POOL = [
  { firstName: "رضا", lastName: "کریمی", username: "r.karimi", role: "مدیر سیستم" as const, email: "r.karimi@example.ir" },
  { firstName: "مریم", lastName: "حسینی", username: "m.hosseini", role: "مدیر قرارداد" as const, email: "m.hosseini@example.ir" },
  { firstName: "علی", lastName: "اکبرزاده", username: "a.akbarzadeh", role: "کارشناس قرارداد" as const, email: "a.akbarzadeh@example.ir" },
  { firstName: "زهرا", lastName: "موسوی", username: "z.mousavi", role: "مالی" as const, email: "z.mousavi@example.ir" },
  { firstName: "حسین", lastName: "قنبری", username: "h.ghanbari", role: "خرید" as const, email: "h.ghanbari@example.ir" },
  { firstName: "فاطمه", lastName: "نجفی", username: "f.najafi", role: "کارشناس قرارداد" as const, email: "f.najafi@example.ir" },
  { firstName: "امیر", lastName: "شریفی", username: "a.sharifi", role: "ناظر" as const, email: "a.sharifi@example.ir" },
  { firstName: "سمانه", lastName: "رحیمی", username: "s.rahimi", role: "مالی" as const, email: "s.rahimi@example.ir" },
];

export const CURRENT_USER = {
  id: "u-001",
  username: "r.karimi",
  firstName: "رضا",
  lastName: "کریمی",
  fullName: "رضا کریمی",
  role: "مدیر سیستم" as const,
};
