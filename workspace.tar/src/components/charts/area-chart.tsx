"use client";

import { useMemo, useState } from "react";
import { formatNumber } from "@/lib/format";

/* ═══════ نمودار سطحی (Area) — SVG اختصاصی RTL ═══════ */

export interface AreaPoint {
  label: string;
  value: number;
}

export function AreaChart({
  data,
  height = 220,
  formatValue = (v: number) => formatNumber(v),
}: {
  data: AreaPoint[];
  height?: number;
  formatValue?: (v: number) => string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 640;
  const H = height;
  const pad = { top: 18, bottom: 26, start: 12, end: 12 };
  const max = Math.max(...data.map((d) => d.value), 1) * 1.15;
  const innerW = W - pad.start - pad.end;
  const innerH = H - pad.top - pad.bottom;

  // RTL: اولین دسته از راست شروع می‌شود
  const x = (i: number) => pad.start + innerW - (i / Math.max(1, data.length - 1)) * innerW;
  const y = (v: number) => pad.top + innerH - (v / max) * innerH;

  const line = useMemo(() => {
    return data.map((d, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(d.value).toFixed(1)}`).join(" ");
  }, [data, max, H]);

  const area = `${line} L${x(data.length - 1).toFixed(1)},${pad.top + innerH} L${x(0).toFixed(1)},${pad.top + innerH} Z`;

  return (
    <div className="relative w-full" dir="ltr">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height }} onMouseLeave={() => setHover(null)}>
        <defs>
          <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.6 0.1 195)" stopOpacity="0.35" />
            <stop offset="100%" stopColor="oklch(0.6 0.1 195)" stopOpacity="0.02" />
          </linearGradient>
          <linearGradient id="areaLine" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="oklch(0.72 0.105 185)" />
            <stop offset="100%" stopColor="oklch(0.55 0.12 200)" />
          </linearGradient>
        </defs>

        {/* خطوط راهنما */}
        {[0, 0.25, 0.5, 0.75, 1].map((t) => (
          <line
            key={t}
            x1={pad.start}
            x2={W - pad.end}
            y1={pad.top + innerH * t}
            y2={pad.top + innerH * t}
            stroke="currentColor"
            className="text-border"
            strokeDasharray="3 5"
            strokeWidth="1"
          />
        ))}

        <path d={area} fill="url(#areaFill)" />
        <path d={line} fill="none" stroke="url(#areaLine)" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />

        {/* نقاط و برچسب‌ها */}
        {data.map((d, i) => (
          <g key={i}>
            <rect
              x={x(i) - innerW / (data.length * 2)}
              y={pad.top}
              width={innerW / data.length}
              height={innerH}
              fill="transparent"
              onMouseEnter={() => setHover(i)}
            />
            {hover === i && (
              <>
                <line x1={x(i)} x2={x(i)} y1={pad.top} y2={pad.top + innerH} stroke="currentColor" className="text-primary/40" strokeWidth="1.5" />
                <circle cx={x(i)} cy={y(d.value)} r="5" fill="oklch(0.72 0.105 185)" stroke="white" strokeWidth="2" />
              </>
            )}
            {(i % Math.ceil(data.length / 6) === 0 || hover === i) && (
              <text x={x(i)} y={H - 8} textAnchor="middle" className="fill-current text-muted-foreground" fontSize="10.5" style={{ direction: "rtl" }}>
                {d.label}
              </text>
            )}
          </g>
        ))}
      </svg>
      {hover !== null && data[hover] && (
        <div
          className="pointer-events-none absolute -translate-x-1/2 rounded-lg border border-border bg-popover px-2.5 py-1.5 text-center e2"
          style={{ left: `${(x(hover) / W) * 100}%`, top: 0 }}
        >
          <div className="text-[10px] text-muted-foreground whitespace-nowrap">{data[hover].label}</div>
          <div className="nums text-[12px] font-bold text-primary whitespace-nowrap">{formatValue(data[hover].value)}</div>
        </div>
      )}
    </div>
  );
}
