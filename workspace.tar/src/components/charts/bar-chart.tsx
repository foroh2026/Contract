"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { formatPercentInt } from "@/lib/format";

/* ═══════ نمودار میله‌ای گروهی — برنامه‌ای در مقابل واقعی ═══════ */

export interface GroupedBar {
  label: string;
  plan: number;
  actual: number;
}

export function GroupedBarChart({
  data,
  height = 240,
  suffix = "٪",
}: {
  data: GroupedBar[];
  height?: number;
  suffix?: string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 640;
  const H = height;
  const pad = { top: 16, bottom: 30, start: 12, end: 12 };
  const innerW = W - pad.start - pad.end;
  const innerH = H - pad.top - pad.bottom;
  const slot = innerW / data.length;
  const barW = Math.min(16, slot / 3.2);

  const y = (v: number) => pad.top + innerH - (Math.min(100, v) / 100) * innerH;

  return (
    <div className="relative w-full" dir="ltr">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height }} onMouseLeave={() => setHover(null)}>
        <defs>
          <linearGradient id="barPlan" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.7 0.1 235)" />
            <stop offset="100%" stopColor="oklch(0.62 0.09 240)" />
          </linearGradient>
          <linearGradient id="barActual" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.72 0.105 185)" />
            <stop offset="100%" stopColor="oklch(0.5 0.09 205)" />
          </linearGradient>
        </defs>

        {[0, 25, 50, 75, 100].map((t) => (
          <g key={t}>
            <line x1={pad.start} x2={W - pad.end} y1={y(t)} y2={y(t)} stroke="currentColor" className="text-border" strokeDasharray="3 5" />
            <text x={W - pad.end + 2} y={y(t) + 3} fontSize="9.5" className="fill-current text-muted-foreground">
              {t}
            </text>
          </g>
        ))}

        {data.map((d, i) => {
          // RTL: گروه اول از راست
          const cx = W - pad.end - slot * i - slot / 2;
          const isH = hover === i;
          return (
            <g key={i} onMouseEnter={() => setHover(i)}>
              <rect x={cx - slot / 2} y={pad.top} width={slot} height={innerH} fill={isH ? "currentColor" : "transparent"} className="text-secondary/60" />
              <rect
                x={cx - barW - 2}
                y={y(d.plan)}
                width={barW}
                height={pad.top + innerH - y(d.plan)}
                rx="3"
                fill="url(#barPlan)"
                opacity={hover === null || isH ? 1 : 0.45}
                style={{ filter: "drop-shadow(0 2px 3px oklch(0.5 0.1 235/0.3))" }}
              />
              <rect
                x={cx + 2}
                y={y(d.actual)}
                width={barW}
                height={pad.top + innerH - y(d.actual)}
                rx="3"
                fill="url(#barActual)"
                opacity={hover === null || isH ? 1 : 0.45}
                style={{ filter: "drop-shadow(0 2px 3px oklch(0.5 0.09 195/0.35))" }}
              />
              <text x={cx} y={H - 9} textAnchor="middle" fontSize="9.5" className="fill-current text-muted-foreground">
                {d.label}
              </text>
            </g>
          );
        })}
      </svg>
      {hover !== null && data[hover] && (
        <div
          className="pointer-events-none absolute -translate-x-1/2 rounded-lg border border-border bg-popover px-2.5 py-1.5 e2"
          style={{ left: `${((W - pad.end - slot * hover - slot / 2) / W) * 100}%`, top: 0 }}
        >
          <div className="text-[10px] text-muted-foreground text-center whitespace-nowrap">{data[hover].label}</div>
          <div className="flex gap-3 mt-0.5 whitespace-nowrap">
            <span className="text-[11px] flex items-center gap-1">
              <span className="w-2 h-2 rounded-sm bg-[oklch(0.65_0.1_237)]" />
              برنامه: <b className="nums">{formatPercentInt(data[hover].plan)}</b>
            </span>
            <span className="text-[11px] flex items-center gap-1">
              <span className="w-2 h-2 rounded-sm bg-[oklch(0.62_0.1_195)]" />
              واقعی: <b className="nums">{formatPercentInt(data[hover].actual)}{suffix}</b>
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════ لیگند نمودار ═══════ */

export function ChartLegend({
  items,
  className,
}: {
  items: { label: string; color: string }[];
  className?: string;
}) {
  return (
    <div className={cn("flex items-center gap-4 flex-wrap", className)}>
      {items.map((it) => (
        <span key={it.label} className="flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
          <span className="w-2.5 h-2.5 rounded-[3px]" style={{ background: it.color }} />
          {it.label}
        </span>
      ))}
    </div>
  );
}
