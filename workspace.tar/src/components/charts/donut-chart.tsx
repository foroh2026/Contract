"use client";

import { useState } from "react";
import { toFaDigits, formatJalali } from "@/lib/jalali";

/* ═══════ نمودار دونات — قراردادها بر اساس وضعیت ═══════ */

export interface DonutSlice {
  label: string;
  value: number;
  color: string;
}

export function DonutChart({
  data,
  size = 190,
  thickness = 26,
  centerLabel,
  centerValue,
}: {
  data: DonutSlice[];
  size?: number;
  thickness?: number;
  centerLabel?: string;
  centerValue?: string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const total = data.reduce((a, d) => a + d.value, 0) || 1;
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;

  const arcs = data.map((d, i) => ({
    ...d,
    frac: d.value / total,
    offset: data.slice(0, i).reduce((a, x) => a + x.value, 0) / total,
  }));

  return (
    <div className="flex items-center gap-5 flex-wrap justify-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          {arcs.map((a, i) => (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke={a.color}
              strokeWidth={hover === i ? thickness + 5 : thickness}
              strokeDasharray={`${Math.max(0, a.frac * c - 2.5)} ${c}`}
              strokeDashoffset={-a.offset * c}
              strokeLinecap="butt"
              className="transition-all duration-300 cursor-pointer"
              style={{ filter: hover === i ? "drop-shadow(0 0 6px oklch(0.6 0.1 200/0.5))" : "drop-shadow(0 2px 3px oklch(0 0 0/0.2))" }}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
          ))}
        </svg>
        <div className="absolute inset-0 grid place-items-center text-center">
          {hover !== null ? (
            <div>
              <div className="nums text-2xl font-extrabold" style={{ color: arcs[hover].color }}>
                {toFaDigits(arcs[hover].value)}
              </div>
              <div className="text-[10.5px] text-muted-foreground mt-0.5">{arcs[hover].label}</div>
            </div>
          ) : (
            <div>
              <div className="nums text-2xl font-extrabold">{centerValue ?? toFaDigits(total)}</div>
              <div className="text-[10.5px] text-muted-foreground mt-0.5">{centerLabel ?? "کل قراردادها"}</div>
            </div>
          )}
        </div>
      </div>

      <ul className="space-y-2">
        {arcs.map((a, i) => (
          <li
            key={i}
            className="flex items-center gap-2.5 text-[13px] cursor-pointer"
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
          >
            <span className="w-3 h-3 rounded-[4px] e1" style={{ background: a.color }} />
            <span className="min-w-24">{a.label}</span>
            <span className="nums font-bold">{toFaDigits(a.value)}</span>
            <span className="nums text-muted-foreground text-[11px]">
              ({toFaDigits(Math.round(a.frac * 100))}٪)
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ═══════ گیج نیم‌دایره — امتیاز سلامت ═══════ */

export function HealthGauge({
  score,
  size = 170,
  label = "وضعیت قرارداد",
}: {
  score: number;
  size?: number;
  label?: string;
}) {
  const color = score >= 70 ? "oklch(0.62 0.14 158)" : score >= 45 ? "oklch(0.72 0.14 78)" : "oklch(0.58 0.2 27)";
  const r = size / 2 - 14;
  const cx = size / 2;
  const cy = size / 2;
  const arcLen = Math.PI * r;
  const frac = Math.max(0, Math.min(100, score)) / 100;
  const level = score >= 70 ? "وضعیت مناسب" : score >= 45 ? "نیازمند توجه" : "بحرانی";
  const levelColor = score >= 70 ? "text-emerald-500" : score >= 45 ? "text-amber-500" : "text-red-500";

  return (
    <div className="flex flex-col items-center" style={{ width: size }}>
      <svg width={size} height={size / 2 + 16}>
        <defs>
          <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="oklch(0.58 0.2 27)" />
            <stop offset="50%" stopColor="oklch(0.72 0.14 78)" />
            <stop offset="100%" stopColor="oklch(0.62 0.14 158)" />
          </linearGradient>
        </defs>
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          fill="none"
          stroke="currentColor"
          className="text-secondary"
          strokeWidth="13"
          strokeLinecap="round"
        />
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          fill="none"
          stroke={color}
          strokeWidth="13"
          strokeLinecap="round"
          strokeDasharray={`${frac * arcLen} ${arcLen}`}
          style={{ filter: "drop-shadow(0 2px 5px oklch(0 0 0/0.25))", transition: "stroke-dasharray 1s ease-out" }}
        />
        {/* عقربه */}
        <line
          x1={cx}
          y1={cy}
          x2={cx - r * Math.cos(frac * Math.PI)}
          y2={cy - r * Math.sin(frac * Math.PI)}
          stroke={color}
          strokeWidth="3"
          strokeLinecap="round"
          style={{ transition: "all 1s ease-out" }}
        />
        <circle cx={cx} cy={cy} r="5.5" fill={color} stroke="white" strokeWidth="1.5" />
        <text x={cx} y={cy - 14} textAnchor="middle" fontSize="21" fontWeight="800" fill={color} className="nums">
          {toFaDigits(score)}
        </text>
      </svg>
      <p className="text-[12px] font-semibold -mt-1.5">{label}</p>
      <span className={`text-[11px] font-bold mt-0.5 ${levelColor}`}>{level}</span>
    </div>
  );
}
