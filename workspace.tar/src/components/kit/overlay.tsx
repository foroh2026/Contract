"use client";

import { useEffect } from "react";
import { createPortal } from "react-dom";
import { X, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "./button";

/* ═══════ مودال و دیالوگ تأیید ═══════ */

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: "sm" | "md" | "lg" | "xl";
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  const widths = { sm: "max-w-md", md: "max-w-xl", lg: "max-w-3xl", xl: "max-w-5xl" };

  return createPortal(
    <div className="fixed inset-0 z-[100] grid place-items-center p-4" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/45 backdrop-blur-[2px] anim-fade-in" onClick={onClose} />
      <div
        className={cn(
          "relative w-full rounded-2xl border border-border bg-popover text-popover-foreground e4 anim-scale-in",
          "max-h-[88vh] flex flex-col",
          widths[size]
        )}
      >
        <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-border">
          <h2 className="font-bold text-[0.95rem]">{title}</h2>
          <button
            onClick={onClose}
            aria-label="بستن"
            className="grid place-items-center w-8 h-8 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="px-5 py-4 overflow-y-auto">{children}</div>
        {footer && <div className="px-5 py-3.5 border-t border-border bg-secondary/40 rounded-b-2xl">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title = "تأیید عملیات",
  message,
  confirmLabel = "تأیید",
  danger = true,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      size="sm"
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            انصراف
          </Button>
          <Button
            variant={danger ? "danger" : "primary"}
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            {confirmLabel}
          </Button>
        </div>
      }
    >
      <div className="flex items-start gap-3">
        <span
          className={cn(
            "grid place-items-center w-10 h-10 rounded-full shrink-0",
            danger ? "bg-destructive/12 text-destructive" : "bg-primary/12 text-primary"
          )}
        >
          <AlertTriangle className="w-5 h-5" />
        </span>
        <p className="text-sm leading-7 text-foreground/90 pt-1.5">{message}</p>
      </div>
    </Modal>
  );
}

/* ═══════ منوی کشویی ساده ═══════ */

export function Dropdown({
  trigger,
  children,
  align = "start",
  className,
  open,
  onOpenChange,
}: {
  trigger: React.ReactNode;
  children: React.ReactNode;
  align?: "start" | "end";
  className?: string;
  open?: boolean;
  onOpenChange?: (v: boolean) => void;
}) {
  const [isOpen, setIsOpen] = useControlled(open, onOpenChange);
  const ref = useClickOutside(() => setIsOpen(false), isOpen);

  return (
    <div className="relative" ref={ref}>
      <div onClick={() => setIsOpen(!isOpen)}>{trigger}</div>
      {isOpen && (
        <div
          className={cn(
            "absolute top-[calc(100%+8px)] z-40 min-w-52 rounded-xl border border-border bg-popover text-popover-foreground e3 p-1.5 anim-scale-in origin-top",
            align === "start" ? "start-0" : "end-0",
            className
          )}
          onClick={() => setIsOpen(false)}
        >
          {children}
        </div>
      )}
    </div>
  );
}

export function DropdownItem({
  icon,
  children,
  onClick,
  danger,
  active,
}: {
  icon?: React.ReactNode;
  children: React.ReactNode;
  onClick?: () => void;
  danger?: boolean;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] transition-colors text-start",
        active ? "bg-primary/10 text-primary font-medium" : "hover:bg-secondary",
        danger && "text-destructive hover:bg-destructive/10"
      )}
    >
      {icon}
      {children}
    </button>
  );
}

function useControlled(value?: boolean, onChange?: (v: boolean) => void) {
  const [internal, setInternal] = useState(false);
  const isControlled = value !== undefined;
  const v = isControlled ? value : internal;
  const set = (nv: boolean) => {
    if (!isControlled) setInternal(nv);
    onChange?.(nv);
  };
  return [v, set] as const;
}

import { useState, useRef } from "react";

function useClickOutside(fn: () => void, active: boolean) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!active) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) fn();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [active]);
  return ref;
}
