"use client";

import { cn } from "@/lib/utils";

/* ═══════ تب‌ها ═══════ */

export function Tabs({
  tabs,
  active,
  onChange,
  variant = "line",
  className,
}: {
  tabs: { key: string; label: string; icon?: React.ReactNode; badge?: string | number }[];
  active: string;
  onChange: (key: string) => void;
  variant?: "line" | "pill";
  className?: string;
}) {
  if (variant === "pill") {
    return (
      <div className={cn("flex flex-wrap gap-1.5", className)}>
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => onChange(t.key)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-all",
              active === t.key
                ? "bg-primary text-primary-foreground shadow-[inset_0_1px_0_oklch(1_0_0/0.25)]"
                : "bg-secondary/70 text-muted-foreground hover:bg-secondary hover:text-foreground"
            )}
          >
            {t.icon}
            {t.label}
            {t.badge !== undefined && (
              <span
                className={cn(
                  "nums rounded-full px-1.5 text-[10px]",
                  active === t.key ? "bg-white/20" : "bg-foreground/8"
                )}
              >
                {t.badge}
              </span>
            )}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className={cn("border-b border-border overflow-x-auto", className)}>
      <div className="flex gap-1 min-w-max">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => onChange(t.key)}
            className={cn(
              "relative inline-flex items-center gap-2 px-4 py-2.5 text-[13px] font-medium transition-colors whitespace-nowrap",
              active === t.key ? "text-primary" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {t.icon}
            {t.label}
            {t.badge !== undefined && (
              <span className="nums rounded-full bg-secondary px-1.5 text-[10px] text-muted-foreground">
                {t.badge}
              </span>
            )}
            {active === t.key && (
              <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-primary" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
