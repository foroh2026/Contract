"use client";

import { cn } from "@/lib/utils";
import type { ContractStatus, StatementStatus, PurchaseStatus } from "@/types";

/* ═══════ نشان وضعیت (Badge) ═══════ */

const badgeStyles: Record<string, string> = {
  green: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400 border-emerald-500/25",
  amber: "bg-amber-500/12 text-amber-600 dark:text-amber-400 border-amber-500/25",
  red: "bg-red-500/12 text-red-600 dark:text-red-400 border-red-500/25",
  gray: "bg-slate-500/12 text-slate-600 dark:text-slate-300 border-slate-500/25",
  teal: "bg-teal-500/12 text-teal-600 dark:text-teal-400 border-teal-500/25",
  orange: "bg-orange-500/12 text-orange-600 dark:text-orange-400 border-orange-500/25",
  blue: "bg-sky-500/12 text-sky-600 dark:text-sky-400 border-sky-500/25",
  violet: "bg-violet-500/12 text-violet-600 dark:text-violet-400 border-violet-500/25",
};

const dots: Record<string, string> = {
  green: "bg-emerald-500",
  amber: "bg-amber-500",
  red: "bg-red-500",
  gray: "bg-slate-400",
  teal: "bg-teal-500",
  orange: "bg-orange-500",
  blue: "bg-sky-500",
  violet: "bg-violet-500",
};

export function Badge({
  color = "gray",
  dot = true,
  className,
  children,
}: {
  color?: keyof typeof badgeStyles;
  dot?: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium whitespace-nowrap",
        badgeStyles[color],
        className
      )}
    >
      {dot && <span className={cn("w-1.5 h-1.5 rounded-full", dots[color])} />}
      {children}
    </span>
  );
}

const contractStatusMap: Record<ContractStatus, { color: keyof typeof badgeStyles; label: string }> = {
  active: { color: "green", label: "فعال" },
  "near-end": { color: "amber", label: "نزدیک پایان" },
  delayed: { color: "red", label: "دارای تأخیر" },
  suspended: { color: "orange", label: "متوقف" },
  terminated: { color: "gray", label: "خاتمه‌یافته" },
  completed: { color: "teal", label: "تکمیل‌شده" },
};

export function ContractStatusBadge({ status }: { status: ContractStatus }) {
  const s = contractStatusMap[status];
  return <Badge color={s.color}>{s.label}</Badge>;
}

const statementStatusMap: Record<StatementStatus, { color: keyof typeof badgeStyles }> = {
  "پیش‌نویس": { color: "gray" },
  "در انتظار تأیید": { color: "amber" },
  "تأیید شده": { color: "blue" },
  "پرداخت شده": { color: "green" },
};

export function StatementStatusBadge({ status }: { status: StatementStatus }) {
  return <Badge color={statementStatusMap[status].color}>{status}</Badge>;
}

const purchaseStatusMap: Record<PurchaseStatus, { color: keyof typeof badgeStyles }> = {
  "ثبت‌شده": { color: "gray" },
  "در حال تأمین": { color: "amber" },
  "تحویل‌شده": { color: "green" },
  "لغو شده": { color: "red" },
};

export function PurchaseStatusBadge({ status }: { status: PurchaseStatus }) {
  return <Badge color={purchaseStatusMap[status].color}>{status}</Badge>;
}

export function ItemStatusBadge({ status }: { status: string }) {
  const color =
    status === "تکمیل‌شده" ? "green" : status === "در حال اجرا" ? "blue" : status === "متوقف" ? "orange" : "gray";
  return <Badge color={color as keyof typeof badgeStyles}>{status}</Badge>;
}
