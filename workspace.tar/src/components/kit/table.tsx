"use client";

import { cn } from "@/lib/utils";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { toFaDigits } from "@/lib/jalali";

/* ═══════ جدول ═══════ */

export function TableWrap({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("w-full overflow-x-auto rounded-xl border border-border bg-card", className)}>
      <table className="w-full text-sm">{children}</table>
    </div>
  );
}

export function THead({ children }: { children: React.ReactNode }) {
  return (
    <thead className="bg-secondary/60 border-b border-border">
      <tr>{children}</tr>
    </thead>
  );
}

export function TH({ className, children, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return (
    <th
      className={cn(
        "px-3.5 py-3 text-start text-[11.5px] font-semibold text-muted-foreground whitespace-nowrap",
        className
      )}
      {...props}
    >
      {children}
    </th>
  );
}

export function TBody({ children }: { children: React.ReactNode }) {
  return <tbody className="divide-y divide-border">{children}</tbody>;
}

export function TR({
  className,
  onClick,
  children,
}: {
  className?: string;
  onClick?: () => void;
  children: React.ReactNode;
}) {
  return (
    <tr
      onClick={onClick}
      className={cn(
        "transition-colors hover:bg-secondary/40",
        onClick && "cursor-pointer",
        className
      )}
    >
      {children}
    </tr>
  );
}

export function TD({ className, children, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return (
    <td className={cn("px-3.5 py-3 align-middle", className)} {...props}>
      {children}
    </td>
  );
}

/* ═══════ صفحه‌بندی (RTL) ═══════ */

export function Pagination({
  page,
  pageSize,
  total,
  onPage,
}: {
  page: number;
  pageSize: number;
  total: number;
  onPage: (p: number) => void;
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  const window = 2;
  const nums: number[] = [];
  for (let i = Math.max(1, page - window); i <= Math.min(pages, page + window); i++) nums.push(i);

  return (
    <div className="flex items-center justify-between gap-3 flex-wrap mt-4">
      <p className="text-xs text-muted-foreground">
        نمایش {toFaDigits((page - 1) * pageSize + 1)} تا {toFaDigits(Math.min(page * pageSize, total))} از{" "}
        {toFaDigits(total)} ردیف
      </p>
      <div className="flex items-center gap-1">
        <button
          disabled={page === 1}
          onClick={() => onPage(page - 1)}
          className="grid place-items-center w-8 h-8 rounded-lg border border-border bg-card disabled:opacity-40 hover:bg-secondary transition-colors"
          aria-label="صفحه قبل"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        {nums.map((n) => (
          <button
            key={n}
            onClick={() => onPage(n)}
            className={cn(
              "nums grid place-items-center min-w-8 h-8 px-2 rounded-lg text-[13px] transition-colors",
              n === page
                ? "bg-primary text-primary-foreground font-semibold"
                : "border border-border bg-card hover:bg-secondary"
            )}
          >
            {toFaDigits(n)}
          </button>
        ))}
        <button
          disabled={page === pages}
          onClick={() => onPage(page + 1)}
          className="grid place-items-center w-8 h-8 rounded-lg border border-border bg-card disabled:opacity-40 hover:bg-secondary transition-colors"
          aria-label="صفحه بعد"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
