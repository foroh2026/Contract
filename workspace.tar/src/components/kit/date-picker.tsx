"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Calendar, ChevronRight, ChevronLeft, X } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  JALALI_MONTHS, JALALI_WEEKDAYS_SHORT, formatJalali, isLeapJalali,
  jalaliMonthLength, jalaliWeekday, toFaDigits, toGregorian, toJalali, todayJalali,
} from "@/lib/jalali";

/* ═══════ تاریخ‌پیک شمسی — کاملاً فارسی ═══════
   ماه‌های فارسی، روزهای هفته فارسی، اعداد فارسی،
   انتخاب سال/ماه، دکمه امروز و پاک کردن
   ═══════════════════════════════════════════════════════════ */

export function JalaliDatePicker({
  value,           // ISO میلادی (yyyy-mm-dd) یا خالی
  onChange,        // ISO میلادی برگردانده می‌شود
  placeholder = "انتخاب تاریخ",
  clearable = true,
  disabled,
  className,
  id,
}: {
  value?: string;
  onChange: (iso: string) => void;
  placeholder?: string;
  clearable?: boolean;
  disabled?: boolean;
  className?: string;
  id?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const today = todayJalali();

  const initial = useMemo(() => {
    if (value) return toJalaliFromISO(value);
    return { jy: today.jy, jm: today.jm, jd: today.jd };
  }, [value]);

  const [view, setView] = useState({ jy: initial.jy, jm: initial.jm });
  const [selected, setSelected] = useState<{ jy: number; jm: number; jd: number } | null>(
    value ? toJalaliFromISO(value) : null
  );

  // همگام‌سازی با تغییر prop از طریق الگوی تنظیم حالت هنگام رندر
  const [prevValue, setPrevValue] = useState(value);
  if (value !== prevValue) {
    setPrevValue(value);
    const j = value ? toJalaliFromISO(value) : null;
    setSelected(j);
    if (j) setView({ jy: j.jy, jm: j.jm });
  }

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const years = useMemo(() => {
    const list: number[] = [];
    for (let y = today.jy - 6; y <= today.jy + 4; y++) list.push(y);
    return list;
  }, [today.jy]);

  const firstDayGrid = useMemo(() => {
    const g = toGregorian(view.jy, view.jm, 1);
    return jalaliWeekday(g); // 0=شنبه
  }, [view]);

  const daysInMonth = jalaliMonthLength(view.jy, view.jm);
  const isLeap = isLeapJalali(view.jy);

  const cells: (number | null)[] = [
    ...Array.from({ length: firstDayGrid }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const pick = (jd: number) => {
    setSelected({ jy: view.jy, jm: view.jm, jd });
    const g = toGregorian(view.jy, view.jm, jd);
    const iso = `${g.getFullYear()}-${String(g.getMonth() + 1).padStart(2, "0")}-${String(g.getDate()).padStart(2, "0")}`;
    onChange(iso);
    setOpen(false);
  };

  const prevMonth = () => {
    let { jy, jm } = view;
    jm--;
    if (jm === 0) { jm = 12; jy--; }
    setView({ jy, jm });
  };
  const nextMonth = () => {
    let { jy, jm } = view;
    jm++;
    if (jm === 13) { jm = 1; jy++; }
    setView({ jy, jm });
  };

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        id={id}
        type="button"
        disabled={disabled}
        onClick={() => setOpen(!open)}
        className={cn(
          "h-10 w-full rounded-lg border border-input bg-card px-3 flex items-center gap-2 text-sm transition-shadow",
          "focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/20",
          disabled && "opacity-50 cursor-not-allowed",
          open && "border-primary/60 ring-2 ring-primary/20"
        )}
      >
        <Calendar className="w-4 h-4 text-muted-foreground shrink-0" />
        <span className={cn("nums flex-1 text-start", !selected && "text-muted-foreground/70")}>
          {selected ? formatJalali(toGregorian(selected.jy, selected.jm, selected.jd)) : placeholder}
        </span>
        {clearable && selected && !disabled && (
          <span
            role="button"
            aria-label="پاک کردن تاریخ"
            className="grid place-items-center w-5 h-5 rounded text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
            onClick={(e) => {
              e.stopPropagation();
              setSelected(null);
              onChange("");
            }}
          >
            <X className="w-3.5 h-3.5" />
          </span>
        )}
      </button>

      {open && (
        <div className="absolute top-[calc(100%+6px)] start-0 z-50 w-[304px] rounded-xl border border-border bg-popover text-popover-foreground e4 p-3 anim-scale-in origin-top">
          {/* سربرگ: ماه و سال */}
          <div className="flex items-center justify-between gap-1.5 mb-2.5">
            <button type="button" onClick={prevMonth} aria-label="ماه قبل"
              className="grid place-items-center w-7 h-7 rounded-lg hover:bg-secondary transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-1.5">
              <select
                aria-label="ماه"
                value={view.jm}
                onChange={(e) => setView((v) => ({ ...v, jm: Number(e.target.value) }))}
                className="h-8 rounded-lg bg-secondary/70 px-2 text-[13px] font-semibold border-0 focus:outline-none cursor-pointer"
              >
                {JALALI_MONTHS.map((m, i) => (
                  <option key={m} value={i + 1}>{m}</option>
                ))}
              </select>
              <select
                aria-label="سال"
                value={view.jy}
                onChange={(e) => setView((v) => ({ ...v, jy: Number(e.target.value) }))}
                className="nums h-8 rounded-lg bg-secondary/70 px-2 text-[13px] font-semibold border-0 focus:outline-none cursor-pointer"
              >
                {years.map((y) => (
                  <option key={y} value={y}>{toFaDigits(y)}</option>
                ))}
              </select>
            </div>
            <button type="button" onClick={nextMonth} aria-label="ماه بعد"
              className="grid place-items-center w-7 h-7 rounded-lg hover:bg-secondary transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* روزهای هفته */}
          <div className="grid grid-cols-7 gap-0.5 mb-1">
            {JALALI_WEEKDAYS_SHORT.map((w) => (
              <div key={w} className="h-7 grid place-items-center text-[11px] font-semibold text-muted-foreground">
                {w}
              </div>
            ))}
          </div>

          {/* روزها */}
          <div className="grid grid-cols-7 gap-0.5">
            {cells.map((d, i) => {
              if (d === null) return <span key={i} />;
              const isToday = today.jy === view.jy && today.jm === view.jm && today.jd === d;
              const isSel = selected && selected.jy === view.jy && selected.jm === view.jm && selected.jd === d;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => pick(d)}
                  className={cn(
                    "nums h-8 rounded-lg text-[13px] font-medium transition-colors",
                    isSel
                      ? "bg-primary text-primary-foreground shadow-[inset_0_1px_0_oklch(1_0_0/0.25)]"
                      : isToday
                        ? "bg-primary/12 text-primary font-bold ring-1 ring-primary/40"
                        : "hover:bg-secondary"
                  )}
                >
                  {toFaDigits(d)}
                </button>
              );
            })}
          </div>

          {/* فوتر */}
          <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-border">
            <button
              type="button"
              onClick={() => {
                setSelected({ jy: today.jy, jm: today.jm, jd: today.jd });
                setView({ jy: today.jy, jm: today.jm });
                const g = toGregorian(today.jy, today.jm, today.jd);
                onChange(`${g.getFullYear()}-${String(g.getMonth() + 1).padStart(2, "0")}-${String(g.getDate()).padStart(2, "0")}`);
                setOpen(false);
              }}
              className="text-[12px] font-medium text-primary hover:underline"
            >
              امروز
            </button>
            <button
              type="button"
              onClick={() => {
                setSelected(null);
                onChange("");
                setOpen(false);
              }}
              className="text-[12px] text-muted-foreground hover:text-destructive transition-colors"
            >
              پاک کردن
            </button>
          </div>

          <p className="mt-2 text-center text-[10.5px] text-muted-foreground nums">
            سال {toFaDigits(view.jy)} {isLeap ? "(کبیسه)" : ""} — {JALALI_MONTHS[view.jm - 1]}
          </p>
        </div>
      )}
    </div>
  );
}

/** تبدیل ISO میلادی به جلالی (برای مقداردهی اولیه) */
function toJalaliFromISO(iso: string): { jy: number; jm: number; jd: number } {
  const [gy, gm, gd] = iso.slice(0, 10).split("-").map(Number);
  return toJalali(new Date(gy, gm - 1, gd));
}
