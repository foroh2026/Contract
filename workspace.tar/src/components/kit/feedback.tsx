"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { Inbox, RotateCcw, AlertTriangle } from "lucide-react";
import { Button } from "./button";

/* ═══════ حالت‌های بارگذاری، خالی و خطا ═══════ */

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg bg-secondary/80",
        "after:absolute after:inset-0 after:-translate-x-full after:animate-[shimmer_1.6s_infinite] after:bg-gradient-to-l after:from-transparent after:via-foreground/6 after:to-transparent",
        className
      )}
    />
  );
}

export function TableSkeleton({ rows = 6, cols = 6 }: { rows?: number; cols?: number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 space-y-3">
      <div className="flex gap-3">
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} className="h-8 flex-1" />
        ))}
      </div>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-3">
          {Array.from({ length: cols }).map((_, j) => (
            <Skeleton key={j} className="h-10 flex-1" />
          ))}
        </div>
      ))}
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-block w-6 h-6 rounded-full border-2 border-primary/25 border-t-primary animate-spin",
        className
      )}
    />
  );
}

export function LoadingBlock({ label = "در حال دریافت اطلاعات..." }: { label?: string }) {
  return (
    <div className="grid place-items-center py-20 text-center">
      <Spinner />
      <p className="mt-3 text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

export function EmptyState({
  title = "هنوز داده‌ای ثبت نشده است",
  description,
  icon,
  action,
  className,
}: {
  title?: string;
  description?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("grid place-items-center py-16 text-center", className)}>
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-primary/10 blur-xl scale-150" />
        <span className="relative grid place-items-center w-20 h-20 rounded-2xl border border-border bg-secondary/50 text-muted-foreground e1 rotate-3">
          {icon ?? <Inbox className="w-9 h-9" strokeWidth={1.4} />}
        </span>
      </div>
      <h3 className="mt-5 font-bold text-[0.95rem]">{title}</h3>
      {description && <p className="mt-1.5 text-[13px] text-muted-foreground max-w-sm leading-6">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({
  message = "دریافت اطلاعات با مشکل مواجه شد",
  onRetry,
}: {
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="grid place-items-center py-16 text-center">
      <span className="grid place-items-center w-16 h-16 rounded-2xl bg-destructive/10 text-destructive">
        <AlertTriangle className="w-8 h-8" strokeWidth={1.6} />
      </span>
      <h3 className="mt-4 font-bold">خطایی رخ داده است</h3>
      <p className="mt-1.5 text-[13px] text-muted-foreground">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" className="mt-4" onClick={onRetry}>
          <RotateCcw className="w-4 h-4" />
          تلاش مجدد
        </Button>
      )}
    </div>
  );
}

/* ═══════ شمارنده متحرک اعداد ═══════ */

export function CountUp({
  value,
  format,
  duration = 900,
  className,
}: {
  value: number;
  format?: (n: number) => string;
  duration?: number;
  className?: string;
}) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<number>(0);
  const startedRef = useRef(false);

  useEffect(() => {
    if (startedRef.current && ref.current === value) return;
    startedRef.current = true;
    const start = performance.now();
    const from = 0;
    const to = value;
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      const v = from + (to - from) * eased;
      ref.current = v;
      setDisplay(v);
      if (p < 1) raf = requestAnimationFrame(step);
      else ref.current = to;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  const shown = format ? format(display) : Math.round(display).toLocaleString("en-US");
  return <span className={cn("nums", className)}>{shown}</span>;
}
