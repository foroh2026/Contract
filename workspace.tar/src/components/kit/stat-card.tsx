"use client";

import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { CountUp } from "./feedback";
import { formatPercentInt } from "@/lib/format";

/* ═══════ کارت شاخص KPI با عمق سه‌بعدی ═══════ */

export interface StatCardProps {
  label: string;
  value: number;
  format?: (n: number) => string;
  icon: React.ReactNode;
  trend?: number; // درصد تغییر
  trendLabel?: string;
  status?: { label: string; color: string };
  tooltip?: string;
  iconFrom?: string; // رنگ گرادیان آیکن
  iconTo?: string;
  className?: string;
}

export function StatCard({
  label,
  value,
  format,
  icon,
  trend,
  trendLabel = "نسبت به ماه گذشته",
  status,
  tooltip,
  iconFrom = "oklch(0.6 0.1 195)",
  iconTo = "oklch(0.48 0.09 205)",
  className,
}: StatCardProps) {
  const trendIcon = trend === undefined ? null : trend > 0 ? TrendingUp : trend < 0 ? TrendingDown : Minus;
  const trendColor =
    trend === undefined ? "" : trend > 0 ? "text-emerald-500" : trend < 0 ? "text-red-500" : "text-muted-foreground";

  return (
    <div
      className={cn(
        "group relative rounded-xl border border-border bg-card card-3d card-3d-hover p-4 overflow-hidden",
        className
      )}
      title={tooltip}
    >
      {/* لایه برق بالای کارت */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-l from-transparent via-foreground/12 to-transparent" />
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[12.5px] font-medium text-muted-foreground truncate">{label}</p>
          <p className="mt-2 text-[1.45rem] leading-8 font-extrabold tracking-tight">
            <CountUp value={value} format={format} />
          </p>
        </div>
        <span
          className="icon-3d grid place-items-center w-11 h-11 rounded-xl text-white shrink-0 transition-transform duration-300 group-hover:scale-105 group-hover:-rotate-3"
          style={{ ["--icon-grad-a" as string]: iconFrom, ["--icon-grad-b" as string]: iconTo }}
        >
          {icon}
        </span>
      </div>
      <div className="mt-2.5 flex items-center justify-between gap-2 flex-wrap">
        {trend !== undefined && (
          <span className={cn("inline-flex items-center gap-1 text-[11.5px] font-semibold nums", trendColor)}>
            {trendIcon && (
              <>
                <TrendIcon icon={trendIcon} />
                {formatPercentInt(Math.abs(trend))}
              </>
            )}
            {trend === 0 && "بدون تغییر"}
            <span className="font-normal text-muted-foreground">{trendLabel}</span>
          </span>
        )}
        {status && (
          <span className={cn("rounded-full px-2 py-0.5 text-[10.5px] font-semibold", status.color)}>
            {status.label}
          </span>
        )}
      </div>
    </div>
  );
}

function TrendIcon({ icon: Icon }: { icon: React.ComponentType<{ className?: string }> }) {
  return <Icon className="w-3.5 h-3.5" />;
}
