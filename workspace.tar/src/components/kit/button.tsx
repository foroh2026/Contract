"use client";

import { forwardRef } from "react";
import { cn } from "@/lib/utils";

/* ═══════ دکمه — سیستم طراحی سامانه ═══════ */

type Variant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "success";
type Size = "sm" | "md" | "lg" | "icon";

const variants: Record<Variant, string> = {
  primary:
    "bg-primary text-primary-foreground shadow-[inset_0_1px_0_oklch(1_0_0/0.25),0_2px_6px_-1px_oklch(0.4_0.08_200/0.5)] hover:brightness-110 active:shadow-[inset_0_2px_4px_oklch(0_0_0/0.25)] active:translate-y-px",
  secondary:
    "bg-secondary text-secondary-foreground border border-border hover:bg-accent active:translate-y-px",
  outline:
    "bg-card text-foreground border border-border hover:bg-secondary hover:border-input active:translate-y-px",
  ghost: "text-foreground hover:bg-secondary active:translate-y-px",
  danger:
    "bg-destructive text-white shadow-[inset_0_1px_0_oklch(1_0_0/0.2),0_2px_6px_-1px_oklch(0.5_0.18_27/0.5)] hover:brightness-110 active:translate-y-px",
  success:
    "bg-success text-success-foreground shadow-[inset_0_1px_0_oklch(1_0_0/0.25)] hover:brightness-110 active:translate-y-px",
};

const sizes: Record<Size, string> = {
  sm: "h-8 px-3 text-xs gap-1.5 rounded-md",
  md: "h-10 px-4 text-sm gap-2 rounded-lg",
  lg: "h-11 px-6 text-[0.95rem] gap-2 rounded-lg",
  icon: "h-9 w-9 rounded-lg",
};

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center font-medium whitespace-nowrap transition-all duration-200",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:ring-offset-1 focus-visible:ring-offset-background",
        "disabled:pointer-events-none disabled:opacity-50 select-none",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    />
  )
);
Button.displayName = "Button";
