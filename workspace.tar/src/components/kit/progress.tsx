"use client";

import { cn } from "@/lib/utils";
import { formatPercentInt } from "@/lib/format";

/* ═══════ نوار پیشرفت و دایره پیشرفت ═══════ */

export function ProgressBar({
  value,
  plan,
  size = "md",
  className,
  showLabel = false,
}: {
  value: number;
  plan?: number;
  size?: "sm" | "md" | "lg";
  className?: string;
  showLabel?: boolean;
}) {
  const v = Math.max(0, Math.min(100, value));
  const heights = { sm: "h-1.5", md: "h-2.5", lg: "h-3.5" };
  const color = v >= 100 ? "bg-success" : v >= 60 ? "bg-primary" : v >= 30 ? "bg-sky-500" : "bg-amber-500";
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn("relative flex-1 rounded-full bg-secondary overflow-hidden", heights[size])}>
        {plan !== undefined && (
          <span
            className="absolute top-0 bottom-0 w-[2px] bg-foreground/55 z-10"
            style={{ right: `${Math.max(0, Math.min(100, plan))}%` }}
            title={`برنامه: ${formatPercentInt(plan)}`}
          />
        )}
        <div
          className={cn(
            "h-full rounded-full transition-[width] duration-700 ease-out relative",
            color
          )}
          style={{
            width: `${v}%`,
            backgroundImage: "linear-gradient(to bottom, oklch(1 0 0/0.28), oklch(1 0 0/0) 55%)",
          }}
        />
      </div>
      {showLabel && (
        <span className="nums text-[11px] font-semibold text-muted-foreground w-9 text-left">
          {formatPercentInt(v)}
        </span>
      )}
    </div>
  );
}

export function CircularProgress({
  value,
  size = 120,
  stroke = 10,
  label,
  sublabel,
}: {
  value: number;
  size?: number;
  stroke?: number;
  label?: string;
  sublabel?: string;
}) {
  const v = Math.max(0, Math.min(100, value));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - v / 100);
  const id = `cg-${size}-${Math.round(v)}`;
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="oklch(0.6 0.1 195)" />
            <stop offset="100%" stopColor="oklch(0.55 0.13 160)" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={stroke} className="text-secondary" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={`url(#${id})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-1000 ease-out"
          style={{ filter: "drop-shadow(0 2px 4px oklch(0.5 0.09 195/0.4))" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <div className="nums text-xl font-extrabold">{label ?? formatPercentInt(v)}</div>
          {sublabel && <div className="text-[10px] text-muted-foreground mt-0.5">{sublabel}</div>}
        </div>
      </div>
    </div>
  );
}

/** نشانگر وزن — نوار افقی کوچک */
export function WeightBar({ value, max = 40 }: { value: number; max?: number }) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="flex items-center gap-2">
      <div className="w-16 h-1.5 rounded-full bg-secondary overflow-hidden">
        <div className="h-full rounded-full bg-chart-2 transition-[width] duration-500" style={{ width: `${pct}%` }} />
      </div>
      <span className="nums text-[11px] text-muted-foreground">{formatPercentInt(value)}</span>
    </div>
  );
}
