"use client";

import { useState } from "react";
import { UserRound, UserPlus, ShieldCheck, Pencil, Trash2, Check, Minus } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD } from "@/components/kit/table";
import { Badge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { Switch } from "@/components/kit/form";
import { SearchInput } from "@/components/kit/form";
import { ConfirmDialog } from "@/components/kit/overlay";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { userService } from "@/services";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import type { UserRole } from "@/types";

/* ═══════ مدیریت کاربران ═══════ */

const ROLE_COLORS: Record<UserRole, string> = {
  "مدیر سیستم": "red",
  "مدیر قرارداد": "teal",
  "کارشناس قرارداد": "blue",
  "مالی": "green",
  "خرید": "amber",
  "ناظر": "gray",
};

export function UsersView() {
  const [q, setQ] = useState("");
  const { data: users, loading, error, reload } = useAsync(() => userService.list(), []);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const filtered = (users || []).filter(
    (u) => !q.trim() || u.firstName.includes(q) || u.lastName.includes(q) || u.username.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="کاربران"
        subtitle={`${toFaDigits(filtered.length)} کاربر در سامانه`}
        actions={
          <Button onClick={() => toast.success("کاربر جدید ایجاد شد")}>
            <UserPlus className="w-4 h-4" />
            کاربر جدید
          </Button>
        }
      />

      <div className="mb-4 max-w-md">
        <SearchInput placeholder="جستجوی نام یا نام کاربری..." value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {error ? (
        <ErrorState onRetry={reload} />
      ) : loading ? (
        <LoadingBlock />
      ) : filtered.length === 0 ? (
        <EmptyState title="کاربری یافت نشد" icon={<UserRound className="w-9 h-9" />} />
      ) : (
        <TableWrap>
          <THead>
            <TH>کاربر</TH>
            <TH>نام کاربری</TH>
            <TH>نقش</TH>
            <TH>وضعیت</TH>
            <TH>آخرین ورود</TH>
            <TH>عملیات</TH>
          </THead>
          <TBody>
            {filtered.map((u) => (
              <TR key={u.id}>
                <TD>
                  <div className="flex items-center gap-2.5">
                    <span className="grid place-items-center w-9 h-9 rounded-lg bg-primary/10 text-primary text-[12px] font-bold">
                      {u.firstName[0]}{u.lastName[0]}
                    </span>
                    <div>
                      <p className="text-[13px] font-semibold">{u.firstName} {u.lastName}</p>
                      <p className="text-[10.5px] text-muted-foreground">{u.email}</p>
                    </div>
                  </div>
                </TD>
                <TD><span className="text-[12px] font-mono" dir="ltr">{u.username}</span></TD>
                <TD><Badge color={ROLE_COLORS[u.role] as "teal"} dot={false}>{u.role}</Badge></TD>
                <TD>
                  <Switch
                    checked={u.active}
                    onChange={(v) => {
                      u.active = v;
                      toast.success(v ? "کاربر فعال شد" : "کاربر غیرفعال شد");
                      reload();
                    }}
                  />
                </TD>
                <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(u.lastLogin)}</TD>
                <TD>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" aria-label="ویرایش" onClick={() => toast.info("فرم ویرایش کاربر")}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button size="icon" variant="ghost" aria-label="حذف" onClick={() => setDeleteTarget(u.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </TD>
              </TR>
            ))}
          </TBody>
        </TableWrap>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => toast.success("کاربر حذف شد")}
        message="آیا از حذف این کاربر مطمئن هستید؟ دسترسی‌های او به سامانه قطع خواهد شد. این عملیات قابل بازگشت نیست."
        confirmLabel="حذف"
      />
    </div>
  );
}

/* ═══════ نقش‌ها و ماتریس دسترسی ═══════ */

type Action = "مشاهده" | "ایجاد" | "ویرایش" | "حذف" | "تأیید";
const ACTIONS: Action[] = ["مشاهده", "ایجاد", "ویرایش", "حذف", "تأیید"];

const RESOURCES: { name: string; perms: Record<UserRole, (Action | null)[]> }[] = [
  {
    name: "قرارداد",
    perms: {
      "مدیر سیستم": ["مشاهده", "ایجاد", "ویرایش", "حذف", "تأیید"],
      "مدیر قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, "تأیید"],
      "کارشناس قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "مالی": ["مشاهده", null, null, null, null],
      "خرید": ["مشاهده", null, null, null, null],
      "ناظر": ["مشاهده", null, null, null, null],
    },
  },
  {
    name: "خرید",
    perms: {
      "مدیر سیستم": ["مشاهده", "ایجاد", "ویرایش", "حذف", null],
      "مدیر قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "کارشناس قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "مالی": ["مشاهده", null, null, null, null],
      "خرید": ["مشاهده", "ایجاد", "ویرایش", null, "تأیید"],
      "ناظر": ["مشاهده", null, null, null, null],
    },
  },
  {
    name: "صورت وضعیت",
    perms: {
      "مدیر سیستم": ["مشاهده", "ایجاد", "ویرایش", null, "تأیید"],
      "مدیر قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, "تأیید"],
      "کارشناس قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "مالی": ["مشاهده", "ایجاد", null, null, "تأیید"],
      "خرید": ["مشاهده", null, null, null, null],
      "ناظر": ["مشاهده", null, null, null, null],
    },
  },
  {
    name: "دریافت",
    perms: {
      "مدیر سیستم": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "مدیر قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "کارشناس قرارداد": ["مشاهده", null, null, null, null],
      "مالی": ["مشاهده", "ایجاد", "ویرایش", null, "تأیید"],
      "خرید": ["مشاهده", null, null, null, null],
      "ناظر": ["مشاهده", null, null, null, null],
    },
  },
  {
    name: "اسناد",
    perms: {
      "مدیر سیستم": ["مشاهده", "ایجاد", "ویرایش", "حذف", null],
      "مدیر قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "کارشناس قرارداد": ["مشاهده", "ایجاد", "ویرایش", null, null],
      "مالی": ["مشاهده", null, null, null, null],
      "خرید": ["مشاهده", "ایجاد", null, null, null],
      "ناظر": ["مشاهده", null, null, null, null],
    },
  },
  {
    name: "گزارش",
    perms: {
      "مدیر سیستم": ["مشاهده", null, null, null, null],
      "مدیر قرارداد": ["مشاهده", null, null, null, null],
      "کارشناس قرارداد": ["مشاهده", null, null, null, null],
      "مالی": ["مشاهده", null, null, null, null],
      "خرید": ["مشاهده", null, null, null, null],
      "ناظر": ["مشاهده", null, null, null, null],
    },
  },
];

export function RolesView() {
  const [role, setRole] = useState<UserRole>("مدیر قرارداد");
  const ROLES: UserRole[] = ["مدیر سیستم", "مدیر قرارداد", "کارشناس قرارداد", "مالی", "خرید", "ناظر"];

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="نقش‌ها و دسترسی‌ها"
        subtitle="ماتریس دسترسی نقش‌ها به منابع سامانه"
        actions={
          <Button variant="outline" onClick={() => toast.success("تغییرات دسترسی ذخیره شد")}>
            <ShieldCheck className="w-4 h-4" />
            ذخیره دسترسی‌ها
          </Button>
        }
      />

      <Card className="mb-4">
        <CardHeader><CardTitle>نقش‌های سامانه</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2.5">
          {ROLES.map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`rounded-xl border px-3 py-3 text-center transition-all ${role === r ? "border-primary/50 bg-primary/8 e2" : "border-border bg-card hover:border-primary/30"}`}
            >
              <ShieldCheck className={`w-5 h-5 mx-auto ${role === r ? "text-primary" : "text-muted-foreground"}`} />
              <p className="text-[12px] font-bold mt-1.5">{r}</p>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ماتریس دسترسی نقش «{role}»</CardTitle>
        </CardHeader>
        <CardContent>
          <TableWrap className="border-0">
            <THead>
              <TH>منبع</TH>
              {ACTIONS.map((a) => <TH key={a} className="text-center">{a}</TH>)}
            </THead>
            <TBody>
              {RESOURCES.map((res) => {
                const perms = res.perms[role];
                return (
                  <TR key={res.name}>
                    <TD className="text-[13px] font-bold">{res.name}</TD>
                    {ACTIONS.map((a, i) => (
                      <TD key={a} className="text-center">
                        {perms[i] ? (
                          <span className="inline-grid place-items-center w-6 h-6 rounded-full bg-emerald-500/15 text-emerald-500">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        ) : (
                          <span className="inline-grid place-items-center w-6 h-6 rounded-full bg-secondary text-muted-foreground/50">
                            <Minus className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </TD>
                    ))}
                  </TR>
                );
              })}
            </TBody>
          </TableWrap>
        </CardContent>
      </Card>
    </div>
  );
}
