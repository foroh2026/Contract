"use client";

import { useMemo } from "react";
import { Paperclip, Layers, FileText } from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { ProgressBar, CircularProgress } from "@/components/kit/progress";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { contractService, appendixService } from "@/services";
import { weightedProgress, weightedPlan } from "@/lib/progress";
import { formatPercentInt } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";

/* ═══════ پیوست‌های فنی — نمای سراسری ═══════ */

export function AppendicesView() {
  const { navigate } = useRouter();
  const { data: contracts, loading, error, reload } = useAsync(() => contractService.list(), []);
  const { data: appendices } = useAsync(async () => {
    const cs = await contractService.list();
    const out: Record<string, Awaited<ReturnType<typeof appendixService.getByContract>>> = {};
    await Promise.all(cs.map(async (c) => (out[c.id] = await appendixService.getByContract(c.id))));
    return out;
  }, []);

  const rows = useMemo(() => {
    return (contracts || [])
      .map((c) => ({ contract: c, appendix: appendices?.[c.id] }))
      .filter((r) => r.appendix);
  }, [contracts, appendices]);

  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="پیوست‌های فنی"
        subtitle="ساختار اقلام، وزن‌ها و پیشرفت وزن‌دار تمام قراردادها — هسته محاسبه پیشرفت فیزیکی"
      />

      {loading ? <LoadingBlock /> : rows.length === 0 ? (
        <EmptyState title="پیوست فنی یافت نشد" icon={<Paperclip className="w-9 h-9" />} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {rows.map(({ contract: c, appendix: ap }) => {
            const actual = weightedProgress(ap!.items);
            const plan = weightedPlan(ap!.items);
            const done = ap!.items.filter((i) => i.progress >= 100).length;
            return (
              <Card key={c.id} hover className="p-4 cursor-pointer" onClick={() => navigate(`/contracts/${c.id}/technical-appendix`)}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="nums text-[11px] font-bold text-primary bg-primary/10 rounded px-1.5 py-0.5">{toFaDigits(c.code)}</span>
                      <span className="nums text-[10.5px] text-muted-foreground">نسخه ۰{toFaDigits(ap!.version)}</span>
                    </div>
                    <p className="text-[13px] font-bold mt-1.5 line-clamp-2 leading-6">{c.title}</p>
                    <p className="text-[10.5px] text-muted-foreground mt-1 nums">
                      {toFaDigits(ap!.chapters.length)} فصل • {toFaDigits(ap!.groups.length)} گروه • {toFaDigits(ap!.items.length)} قلم
                    </p>
                  </div>
                  <CircularProgress value={actual} size={76} stroke={7} />
                </div>
                <div className="mt-3">
                  <div className="flex justify-between text-[10.5px] text-muted-foreground mb-1">
                    <span>برنامه: {formatPercentInt(plan, 0)}</span>
                    <span>{toFaDigits(done)} قلم تکمیل</span>
                  </div>
                  <ProgressBar value={actual} plan={plan} size="sm" showLabel />
                </div>
                <div className="mt-3 pt-2.5 border-t border-border flex items-center justify-between text-[10.5px] text-muted-foreground nums">
                  <span className="flex items-center gap-1"><Layers className="w-3.5 h-3.5" />آخرین بازنگری: {formatJalali(ap!.revisionDate)}</span>
                  <span className="flex items-center gap-1 text-primary"><FileText className="w-3.5 h-3.5" />مشاهده</span>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
