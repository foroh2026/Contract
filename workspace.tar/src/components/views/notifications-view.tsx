"use client";

import { useState } from "react";
import { Bell, CheckCheck, AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Button } from "@/components/kit/button";
import { Tabs } from "@/components/kit/tabs";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { notificationService } from "@/services";
import { formatJalali, timeAgo, toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";
import type { Notification } from "@/types";

/* ═══════ مرکز اعلان‌ها ═══════ */

const KIND_STYLE: Record<Notification["kind"], { icon: React.ReactNode; bg: string; label: string }> = {
  warning: { icon: <AlertTriangle className="w-4 h-4" />, bg: "bg-amber-500/12 text-amber-500", label: "هشدار" },
  danger: { icon: <XCircle className="w-4 h-4" />, bg: "bg-red-500/12 text-red-500", label: "بحرانی" },
  success: { icon: <CheckCircle2 className="w-4 h-4" />, bg: "bg-emerald-500/12 text-emerald-500", label: "موفق" },
  info: { icon: <Info className="w-4 h-4" />, bg: "bg-sky-500/12 text-sky-500", label: "اطلاع" },
};

export function NotificationsView() {
  const { navigate } = useRouter();
  const { data: notifications, loading, error, reload } = useAsync(() => notificationService.list(), []);
  const [filter, setFilter] = useState("all");

  const filtered = (notifications || []).filter((n) =>
    filter === "all" ? true : filter === "unread" ? !n.read : n.kind === filter
  );
  const unread = (notifications || []).filter((n) => !n.read).length;

  return (
    <div className="anim-fade-up max-w-4xl">
      <PageHeader
        title="اعلان‌ها"
        subtitle={`${toFaDigits(unread)} اعلان خوانده‌نشده از مجموع ${toFaDigits(notifications?.length ?? 0)} اعلان`}
        actions={
          <Button
            variant="outline"
            onClick={async () => {
              await notificationService.markAllRead();
              toast.success("همه اعلان‌ها خوانده‌شده علامت‌گذاری شدند");
              reload();
            }}
          >
            <CheckCheck className="w-4 h-4" />
            خواندن همه
          </Button>
        }
      />

      <Tabs
        variant="pill"
        className="mb-4"
        active={filter}
        onChange={setFilter}
        tabs={[
          { key: "all", label: "همه", badge: notifications?.length },
          { key: "unread", label: "خوانده‌نشده", badge: unread },
          { key: "danger", label: "بحرانی" },
          { key: "warning", label: "هشدار" },
          { key: "success", label: "موفق" },
          { key: "info", label: "اطلاع" },
        ]}
      />

      {error ? (
        <ErrorState onRetry={reload} />
      ) : loading ? (
        <LoadingBlock />
      ) : filtered.length === 0 ? (
        <EmptyState title="اعلانی وجود ندارد" icon={<Bell className="w-9 h-9" />} description="در این دسته اعلانی ثبت نشده است." />
      ) : (
        <Card>
          <CardHeader><CardTitle>فهرست اعلان‌ها</CardTitle></CardHeader>
          <CardContent className="space-y-2.5">
            {filtered.map((n, i) => (
              <button
                key={n.id}
                onClick={() => {
                  notificationService.markRead(n.id);
                  if (n.link) navigate("/" + n.link);
                }}
                className={cn(
                  "w-full flex items-start gap-3 rounded-xl border p-4 text-start transition-all hover:e2 hover:-translate-y-0.5 anim-fade-up",
                  n.read ? "border-border bg-card" : "border-primary/30 bg-primary/5"
                )}
                style={{ animationDelay: `${i * 30}ms` }}
              >
                <span className={cn("grid place-items-center w-9 h-9 rounded-lg shrink-0", KIND_STYLE[n.kind].bg)}>
                  {KIND_STYLE[n.kind].icon}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className={cn("text-[13.5px]", n.read ? "font-semibold" : "font-extrabold")}>{n.title}</p>
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold", KIND_STYLE[n.kind].bg)}>
                      {KIND_STYLE[n.kind].label}
                    </span>
                    {!n.read && <span className="w-2 h-2 rounded-full bg-primary" />}
                  </div>
                  <p className="text-[12px] text-muted-foreground leading-6 mt-1">{n.description}</p>
                  <p className="text-[10.5px] text-muted-foreground/70 mt-1 nums">
                    {formatJalali(n.date)} — {timeAgo(n.date)}
                  </p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
