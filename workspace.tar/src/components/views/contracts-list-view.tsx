"use client";

import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, FilterX, Eye, Pencil, Trash2, MoreHorizontal, Printer, Download, FolderKanban } from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { TableWrap, THead, TH, TBody, TR, TD, Pagination } from "@/components/kit/table";
import { ProgressBar } from "@/components/kit/progress";
import { ContractStatusBadge } from "@/components/kit/badge";
import { Input, Select, Field } from "@/components/kit/form";
import { JalaliDatePicker } from "@/components/kit/date-picker";
import { Button } from "@/components/kit/button";
import { Dropdown, DropdownItem, ConfirmDialog } from "@/components/kit/overlay";
import { TableSkeleton, EmptyState, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter, parseRoute } from "@/lib/router";
import { contractService, employerService, appendixService } from "@/services";
import { formatRialCompact, formatRial, formatSignedPercent, parseFaNumber } from "@/lib/format";
import { formatJalali, daysUntil, toFaDigits } from "@/lib/jalali";
import { contractProgressSummary, weightedProgress } from "@/lib/progress";
import type { Contract, ContractStatus } from "@/types";
import { cn } from "@/lib/utils";

/* ═══════════════════════════════════════════════════
   لیست قراردادها + جستجو و فیلتر پیشرفته
   ═══════════════════════════════════════════════════ */

interface Filters {
  q: string;
  employer: string;
  status: string;
  startDate: string;
  endDate: string;
  minAmount: string;
  maxAmount: string;
  minProgress: string;
  maxProgress: string;
  onlyDelayed: boolean;
  onlyNearEnd: boolean;
}

const EMPTY: Filters = {
  q: "", employer: "", status: "", startDate: "", endDate: "",
  minAmount: "", maxAmount: "", minProgress: "", maxProgress: "",
  onlyDelayed: false, onlyNearEnd: false,
};

export function ContractsListView() {
  const { navigate, path } = useRouter();
  const { query } = parseRoute(path);
  const [filters, setFilters] = useState<Filters>({
    ...EMPTY,
    status: query.get("status") || "",
  });
  const [page, setPage] = useState(1);
  const [deleteTarget, setDeleteTarget] = useState<Contract | null>(null);
  const [showFilters, setShowFilters] = useState(true);
  const pageSize = 8;

  const { data: contracts, loading, error, reload } = useAsync(() => contractService.list(), []);
  const { data: employers } = useAsync(() => employerService.list(), []);
  const { data: appendices } = useAsync(async () => {
    const cs = await contractService.list();
    const out: Record<string, Awaited<ReturnType<typeof appendixService.getByContract>>> = {};
    await Promise.all(cs.map(async (c) => (out[c.id] = await appendixService.getByContract(c.id))));
    return out;
  }, []);

  const employerName = (id: string) => employers?.find((e) => e.id === id)?.shortName ?? "—";

  const filtered = useMemo(() => {
    let list = [...(contracts || [])];
    const f = filters;
    if (f.q.trim()) {
      const q = f.q.trim().toLowerCase();
      list = list.filter((c) => c.title.toLowerCase().includes(q) || c.code.toLowerCase().includes(q) || c.subject.includes(q));
    }
    if (f.employer) list = list.filter((c) => c.employerId === f.employer);
    if (f.status) list = list.filter((c) => c.status === f.status);
    if (f.startDate) list = list.filter((c) => c.startDate >= f.startDate);
    if (f.endDate) list = list.filter((c) => c.startDate <= f.endDate);
    if (f.minAmount) list = list.filter((c) => c.amountRial >= parseFaNumber(f.minAmount) * 1_000_000_000);
    if (f.maxAmount) list = list.filter((c) => c.amountRial <= parseFaNumber(f.maxAmount) * 1_000_000_000);
    if (f.onlyDelayed) list = list.filter((c) => c.status === "delayed");
    if (f.onlyNearEnd) list = list.filter((c) => c.status === "near-end");

    const minP = parseFaNumber(f.minProgress);
    const maxP = parseFaNumber(f.maxProgress);
    if (f.minProgress || f.maxProgress) {
      list = list.filter((c) => {
        const ap = appendices?.[c.id];
        const p = ap ? weightedProgress(ap.items) : 0;
        if (f.minProgress && p < minP) return false;
        if (f.maxProgress && p > maxP) return false;
        return true;
      });
    }
    // مرتب‌سازی: جدیدترین ابتدا
    list.sort((a, b) => (a.startDate < b.startDate ? 1 : -1));
    return list;
  }, [contracts, filters, appendices]);

  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);
  const activeFilterCount = Object.entries(filters).filter(([k, v]) => k !== "q" && v !== "" && v !== false).length + (filters.q ? 1 : 0);

  const set = (patch: Partial<Filters>) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPage(1);
  };

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="قراردادها"
        subtitle={`${toFaDigits(filtered.length)} قرارداد مطابق جستجوی فعلی از مجموع ${toFaDigits(contracts?.length ?? 0)} قرارداد`}
        actions={
          <>
            <Button variant="outline" onClick={() => setShowFilters((s) => !s)}>
              <FilterIcon />
              {showFilters ? "بستن فیلترها" : "نمایش فیلترها"}
              {activeFilterCount > 0 && (
                <span className="nums grid place-items-center min-w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] px-1">
                  {toFaDigits(activeFilterCount)}
                </span>
              )}
            </Button>
            <Button variant="outline" onClick={() => toast.success("گزارش قراردادها با فرمت Excel آماده دانلود شد")}>
              <Download className="w-4 h-4" />
              خروجی
            </Button>
            <Button variant="outline" onClick={() => toast.info("حالت چاپ فعال شد — از دیالوگ چاپ مرورگر استفاده کنید")}>
              <Printer className="w-4 h-4" />
              چاپ
            </Button>
            <Button onClick={() => navigate("/contracts/new")}>
              <Plus className="w-4 h-4" />
              ایجاد قرارداد
            </Button>
          </>
        }
      />

      {/* پنل فیلتر */}
      {showFilters && (
        <div className="rounded-xl border border-border bg-card e1 p-4 mb-4 anim-fade-up blueprint-grid">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Field label="جستجوی قرارداد">
              <Input placeholder="کد، نام یا موضوع..." value={filters.q} onChange={(e) => set({ q: e.target.value })} />
            </Field>
            <Field label="کارفرما">
              <Select value={filters.employer} onChange={(e) => set({ employer: e.target.value })}>
                <option value="">همه کارفرمایان</option>
                {employers?.map((e) => (
                  <option key={e.id} value={e.id}>{e.name}</option>
                ))}
              </Select>
            </Field>
            <Field label="وضعیت">
              <Select value={filters.status} onChange={(e) => set({ status: e.target.value })}>
                <option value="">همه وضعیت‌ها</option>
                <option value="active">فعال</option>
                <option value="near-end">نزدیک پایان</option>
                <option value="delayed">دارای تأخیر</option>
                <option value="suspended">متوقف</option>
                <option value="completed">تکمیل‌شده</option>
                <option value="terminated">خاتمه‌یافته</option>
              </Select>
            </Field>
            <Field label="محدوده مبلغ (میلیارد ریال)">
              <div className="flex gap-2">
                <Input placeholder="از" value={filters.minAmount} onChange={(e) => set({ minAmount: e.target.value })} className="nums" />
                <Input placeholder="تا" value={filters.maxAmount} onChange={(e) => set({ maxAmount: e.target.value })} className="nums" />
              </div>
            </Field>
            <Field label="تاریخ شروع از">
              <JalaliDatePicker value={filters.startDate} onChange={(v) => set({ startDate: v })} placeholder="انتخاب تاریخ" />
            </Field>
            <Field label="تاریخ شروع تا">
              <JalaliDatePicker value={filters.endDate} onChange={(v) => set({ endDate: v })} placeholder="انتخاب تاریخ" />
            </Field>
            <Field label="محدوده پیشرفت (٪)">
              <div className="flex gap-2">
                <Input placeholder="از" value={filters.minProgress} onChange={(e) => set({ minProgress: e.target.value })} className="nums" />
                <Input placeholder="تا" value={filters.maxProgress} onChange={(e) => set({ maxProgress: e.target.value })} className="nums" />
              </div>
            </Field>
            <Field label="فیلتر سریع">
              <div className="flex gap-2 flex-wrap">
                <QuickToggle active={filters.onlyDelayed} onClick={() => set({ onlyDelayed: !filters.onlyDelayed })} label="دارای تأخیر" activeClass="bg-red-500/15 text-red-500 border-red-500/40" />
                <QuickToggle active={filters.onlyNearEnd} onClick={() => set({ onlyNearEnd: !filters.onlyNearEnd })} label="نزدیک پایان" activeClass="bg-amber-500/15 text-amber-600 border-amber-500/40" />
              </div>
            </Field>
          </div>
          {activeFilterCount > 0 && (
            <div className="mt-3 pt-3 border-t border-border">
              <Button variant="ghost" size="sm" onClick={() => setFilters(EMPTY)}>
                <FilterX className="w-4 h-4" />
                حذف همه فیلترها
              </Button>
            </div>
          )}
        </div>
      )}

      {error ? (
        <ErrorState onRetry={reload} />
      ) : loading ? (
        <TableSkeleton rows={6} cols={7} />
      ) : paged.length === 0 ? (
        <EmptyState
          icon={<FolderKanban className="w-9 h-9" />}
          title="قراردادی یافت نشد"
          description="با فیلترهای فعلی هیچ قراردادی یافت نشد. می‌توانید فیلترها را حذف کنید یا قرارداد جدیدی ایجاد نمایید."
          action={
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setFilters(EMPTY)}>حذف فیلترها</Button>
              <Button onClick={() => navigate("/contracts/new")}>
                <Plus className="w-4 h-4" />
                ایجاد قرارداد
              </Button>
            </div>
          }
        />
      ) : (
        <>
          <TableWrap>
            <THead>
              <TH>کد قرارداد</TH>
              <TH className="min-w-56">نام قرارداد</TH>
              <TH>کارفرما</TH>
              <TH>مبلغ</TH>
              <TH>تاریخ شروع</TH>
              <TH>تاریخ پایان</TH>
              <TH className="min-w-36">پیشرفت / انحراف</TH>
              <TH>وضعیت</TH>
              <TH>عملیات</TH>
            </THead>
            <TBody>
              {paged.map((c) => {
                const ap = appendices?.[c.id];
                const summary = ap ? contractProgressSummary(c, ap) : null;
                const remain = daysUntil(c.endDate);
                return (
                  <TR key={c.id} onClick={() => navigate(`/contracts/${c.id}`)}>
                    <TD>
                      <span className="nums text-[12px] font-bold text-primary">{toFaDigits(c.code)}</span>
                    </TD>
                    <TD>
                      <p className="font-semibold text-[13px] line-clamp-1 max-w-72">{c.title}</p>
                      <p className="text-[11px] text-muted-foreground line-clamp-1 max-w-72">{c.subject}</p>
                    </TD>
                    <TD className="text-[12.5px] whitespace-nowrap">{employerName(c.employerId)}</TD>
                    <TD className="nums text-[12px] font-semibold whitespace-nowrap">{formatRialCompact(c.amountRial)}</TD>
                    <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(c.startDate)}</TD>
                    <TD className="text-[12px] whitespace-nowrap">
                      <span className="nums">{formatJalali(c.endDate)}</span>
                      {(c.status === "active" || c.status === "near-end" || c.status === "delayed") && (
                        <p className={cn("text-[10px]", remain < 0 ? "text-red-500" : remain < 30 ? "text-amber-500" : "text-muted-foreground")}>
                          {remain < 0 ? `${toFaDigits(Math.abs(remain))} روز تأخیر` : `${toFaDigits(remain)} روز باقی‌مانده`}
                        </p>
                      )}
                    </TD>
                    <TD>
                      {summary ? (
                        <div className="min-w-32">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="nums text-[12px] font-bold">{formatRialCompact(0).slice(0, 0)}{formatPercentStr(summary.actual)}</span>
                            <span className={cn("nums text-[10.5px] font-semibold", summary.deviation >= 0 ? "text-emerald-500" : "text-red-500")}>
                              {formatSignedPercent(summary.deviation, 0)}
                            </span>
                          </div>
                          <ProgressBar value={summary.actual} plan={summary.planned} size="sm" />
                        </div>
                      ) : "—"}
                    </TD>
                    <TD><ContractStatusBadge status={c.status} /></TD>
                    <TD onClick={(e) => e.stopPropagation()}>
                      <Dropdown
                        trigger={
                          <button className="grid place-items-center w-8 h-8 rounded-lg hover:bg-secondary transition-colors" aria-label="عملیات">
                            <MoreHorizontal className="w-4 h-4" />
                          </button>
                        }
                      >
                        <DropdownItem icon={<Eye className="w-4 h-4" />} onClick={() => navigate(`/contracts/${c.id}`)}>مشاهده جزئیات</DropdownItem>
                        <DropdownItem icon={<Pencil className="w-4 h-4" />} onClick={() => navigate(`/contracts/${c.id}/edit`)}>ویرایش</DropdownItem>
                        <DropdownItem icon={<Trash2 className="w-4 h-4" />} danger onClick={() => setDeleteTarget(c)}>حذف قرارداد</DropdownItem>
                      </Dropdown>
                    </TD>
                  </TR>
                );
              })}
            </TBody>
          </TableWrap>
          <Pagination page={page} pageSize={pageSize} total={filtered.length} onPage={setPage} />
        </>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) {
            await contractService.remove(deleteTarget.id);
            toast.success(`قرارداد ${deleteTarget.code} حذف شد`);
            reload();
          }
        }}
        message={`آیا از حذف قرارداد «${deleteTarget?.title}» مطمئن هستید؟ تمام پیوست فنی، صورت‌وضعیت‌ها و داده‌های مرتبط حذف خواهد شد. این عملیات قابل بازگشت نیست.`}
        confirmLabel="حذف"
      />
    </div>
  );
}

function formatPercentStr(n: number) {
  return toFaDigits(Math.round(n)) + "٪";
}

function QuickToggle({ active, onClick, label, activeClass }: { active: boolean; onClick: () => void; label: string; activeClass: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "h-10 px-3 rounded-lg border text-[12px] font-medium transition-all",
        active ? activeClass : "border-input bg-card text-muted-foreground hover:bg-secondary"
      )}
    >
      {label}
    </button>
  );
}

function FilterIcon() {
  return (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M3 6h18M7 12h10M10 18h4" />
    </svg>
  );
}
