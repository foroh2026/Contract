"use client";

import { useMemo, useState } from "react";
import { BarChart3, Printer, Download, FolderKanban, Landmark, Activity, FileText, Wallet, ShoppingCart, Paperclip, Wrench, AlarmClock } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD } from "@/components/kit/table";
import { Button } from "@/components/kit/button";
import { Tabs } from "@/components/kit/tabs";
import { ContractStatusBadge } from "@/components/kit/badge";
import { ProgressBar } from "@/components/kit/progress";
import { LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { contractService, statementService, paymentService, purchaseService, appendixService, employerService } from "@/services";
import { formatRialCompact, formatRial, formatSignedPercent } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import { contractProgressSummary } from "@/lib/progress";
import { cn } from "@/lib/utils";

/* ═══════ گزارشات — ۱۰ گزارش با فیلتر و خروجی ═══════ */

type ReportKey =
  | "contracts" | "financial" | "statements" | "payments" | "receivables"
  | "progress" | "purchases" | "makes" | "appendix" | "delayed";

const REPORT_TABS: { key: ReportKey; label: string; icon: React.ReactNode }[] = [
  { key: "contracts", label: "گزارش قراردادها", icon: <FolderKanban className="w-4 h-4" /> },
  { key: "financial", label: "گزارش مالی", icon: <Landmark className="w-4 h-4" /> },
  { key: "statements", label: "صورت‌وضعیت", icon: <FileText className="w-4 h-4" /> },
  { key: "payments", label: "دریافتی", icon: <Wallet className="w-4 h-4" /> },
  { key: "receivables", label: "مطالبات", icon: <Wallet className="w-4 h-4" /> },
  { key: "progress", label: "پیشرفت", icon: <Activity className="w-4 h-4" /> },
  { key: "purchases", label: "خرید", icon: <ShoppingCart className="w-4 h-4" /> },
  { key: "makes", label: "ساخت", icon: <Wrench className="w-4 h-4" /> },
  { key: "appendix", label: "پیوست فنی", icon: <Paperclip className="w-4 h-4" /> },
  { key: "delayed", label: "تأخیردار", icon: <AlarmClock className="w-4 h-4" /> },
];

export function ReportsView() {
  const [tab, setTab] = useState<ReportKey>("contracts");
  const [q, setQ] = useState("");
  const { data: contracts } = useAsync(() => contractService.list(), []);
  const { data: employers } = useAsync(() => employerService.list(), []);
  const { data: statements } = useAsync(() => statementService.list(), []);
  const { data: payments } = useAsync(() => paymentService.list(), []);
  const { data: purchases } = useAsync(() => purchaseService.list(), []);
  const { data: appendices } = useAsync(async () => {
    const cs = await contractService.list();
    const out: Record<string, Awaited<ReturnType<typeof appendixService.getByContract>>> = {};
    await Promise.all(cs.map(async (c) => (out[c.id] = await appendixService.getByContract(c.id))));
    return out;
  }, []);

  const report = useMemo(() => {
    const employerName = (id: string) => employers?.find((e) => e.id === id)?.shortName ?? "—";
    const match = (s: string) => !q.trim() || s.toLowerCase().includes(q.trim().toLowerCase()) || s.includes(q.trim());
    switch (tab) {
      case "contracts":
        return {
          cols: ["کد", "نام", "کارفرما", "مبلغ", "شروع", "پایان", "وضعیت"],
          rows: (contracts || []).filter((c) => match(c.code) && match(c.title)).map((c) => [
            toFaDigits(c.code), c.title, employerName(c.employerId), formatRialCompact(c.amountRial), formatJalali(c.startDate), formatJalali(c.endDate), "",
            <ContractStatusBadge key={c.id} status={c.status} />,
          ]),
        };
      case "financial":
        return {
          cols: ["کد", "مبلغ فعلی", "صورت‌وضعیت", "دریافتی", "مانده", "نسبت پرداخت"],
          rows: (contracts || []).filter((c) => match(c.code) && match(c.title)).map((c) => {
            const st = (statements || []).filter((s) => s.contractId === c.id).reduce((a, s) => a + s.finalAmount, 0);
            const pay = (payments || []).filter((p) => p.contractId === c.id).reduce((a, p) => a + p.amount, 0);
            const pct = Math.min(100, (pay / Math.max(1, st)) * 100);
            return [
              toFaDigits(c.code), formatRialCompact(c.amountRial), formatRialCompact(st), formatRialCompact(pay), formatRialCompact(Math.max(0, st - pay)),
              <ProgressBar key={c.id} value={pct} size="sm" showLabel />,
            ];
          }),
        };
      case "statements":
        return {
          cols: ["کد", "قرارداد", "تاریخ", "ناخالص", "نهایی", "وضعیت"],
          rows: (statements || []).filter((s) => match(s.code)).map((s) => {
            const c = (contracts || []).find((x) => x.id === s.contractId);
            return [toFaDigits(s.code), toFaDigits(c?.code ?? ""), formatJalali(s.date), formatRialCompact(s.grossAmount), formatRialCompact(s.finalAmount),
              <span key={s.id} className="text-[11.5px]">{s.status}</span>];
          }),
        };
      case "payments":
        return {
          cols: ["کد", "قرارداد", "مبلغ", "تاریخ", "روش"],
          rows: (payments || []).filter((p) => match(p.code)).map((p) => {
            const c = (contracts || []).find((x) => x.id === p.contractId);
            return [toFaDigits(p.code), toFaDigits(c?.code ?? ""), formatRial(p.amount), formatJalali(p.date), p.method];
          }),
        };
      case "receivables":
        return {
          cols: ["صورت‌وضعیت", "قرارداد", "مبلغ نهایی", "دریافتی", "مانده"],
          rows: (statements || []).map((s) => {
            const paid = (payments || []).filter((p) => p.statementId === s.id).reduce((a, p) => a + p.amount, 0);
            const rem = s.finalAmount - paid;
            const c = (contracts || []).find((x) => x.id === s.contractId);
            return rem > 0
              ? [toFaDigits(s.code), toFaDigits(c?.code ?? ""), formatRialCompact(s.finalAmount), formatRialCompact(paid),
                 <b key={s.id} className="nums text-red-500">{formatRialCompact(rem)}</b>]
              : null;
          }).filter((r): r is NonNullable<typeof r> => r !== null),
        };
      case "progress":
        return {
          cols: ["کد", "برنامه‌ای", "واقعی", "انحراف", "اقلام تکمیل"],
          rows: (contracts || []).filter((c) => match(c.code) && appendices?.[c.id]).map((c) => {
            const ap = appendices![c.id];
            const sum = contractProgressSummary(c, ap!);
            return [
              toFaDigits(c.code), `${toFaDigits(Math.round(sum.planned))}٪`,
              <b key={c.id} className="nums">{toFaDigits(Math.round(sum.actual))}٪</b>,
              <span key={c.id} className={cn("nums font-bold", sum.deviation >= 0 ? "text-emerald-500" : "text-red-500")}>{formatSignedPercent(sum.deviation, 1)}</span>,
              `${toFaDigits(sum.completedItems)}/${toFaDigits(sum.totalItems)}`,
            ];
          }),
        };
      case "purchases":
      case "makes": {
        const typeFilter = tab === "purchases" ? "خرید" : "ساخت";
        return {
          cols: ["کد", "قرارداد", "شرح", "تأمین‌کننده", "جمع", "وضعیت"],
          rows: (purchases || []).filter((p) => p.type === typeFilter && match(p.code)).map((p) => {
            const c = (contracts || []).find((x) => x.id === p.contractId);
            return [toFaDigits(p.code), toFaDigits(c?.code ?? ""), p.description, p.supplier, formatRialCompact(p.quantity * p.unitPrice), p.status];
          }),
        };
      }
      case "appendix":
        return {
          cols: ["کد", "فصل/گروه/قلم", "وزن", "پیشرفت", "وضعیت"],
          rows: (contracts || []).slice(0, 5).flatMap((c) => {
            const ap = appendices?.[c.id];
            if (!ap) return [];
            return ap.items.slice(0, 8).map((it) => {
              const g = ap.groups.find((x) => x.id === it.groupId);
              return [
                toFaDigits(c.code), `${g?.title ?? ""} — ${it.title}`,
                `${toFaDigits(it.weightPercent)}٪`, `${toFaDigits(it.progress)}٪`, it.status,
              ];
            });
          }),
        };
      case "delayed":
        return {
          cols: ["کد", "نام", "کارفرما", "پایان", "انحراف", "وضعیت"],
          rows: (contracts || []).filter((c) => c.status === "delayed" && match(c.code)).map((c) => {
            const ap = appendices?.[c.id];
            const sum = ap ? contractProgressSummary(c, ap) : null;
            return [
              toFaDigits(c.code), c.title, employerName(c.employerId), formatJalali(c.endDate),
              sum ? <span key={c.id} className="nums font-bold text-red-500">{formatSignedPercent(sum.deviation, 1)}</span> : "—",
              <ContractStatusBadge key={c.id} status={c.status} />,
            ];
          }),
        };
    }
  }, [tab, contracts, employers, statements, payments, purchases, appendices, q]);

  if (!contracts || !employers) return <LoadingBlock />;

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="گزارشات"
        subtitle="گزارش‌های تحلیلی سامانه با قابلیت فیلتر، خروجی و چاپ"
        actions={
          <>
            <Button variant="outline" onClick={() => setQ("")}>
              <Download className="w-4 h-4" />
              خروجی گزارش
            </Button>
            <Button variant="outline" onClick={() => toast.info("حالت چاپ فعال شد")}>
              <Printer className="w-4 h-4" />
              چاپ
            </Button>
          </>
        }
      />

      <Tabs tabs={REPORT_TABS} active={tab} onChange={(k) => setTab(k as ReportKey)} variant="pill" className="mb-4" />

      <Card>
        <CardHeader>
          <CardTitle><BarChart3 className="w-4 h-4 text-primary" /> {REPORT_TABS.find((t) => t.key === tab)?.label}</CardTitle>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جستجو در گزارش..."
            className="h-9 w-56 rounded-lg border border-input bg-card px-3 text-[13px] focus:outline-none focus:border-primary/60"
          />
        </CardHeader>
        <CardContent>
          {!report ? <LoadingBlock /> : report.rows.length === 0 ? (
            <p className="text-[13px] text-muted-foreground text-center py-8">داده‌ای برای این گزارش یافت نشد</p>
          ) : (
            <TableWrap className="border-0">
              <THead>
                {report.cols.map((c) => <TH key={c}>{c}</TH>)}
              </THead>
              <TBody>
                {report.rows.slice(0, 25).map((row, i) => (
                  <TR key={i}>
                    {row.map((cell, j) => (
                      <TD key={j} className={j === 0 ? "whitespace-nowrap" : ""}>
                        {typeof cell === "string" || typeof cell === "number" ? (
                          <span className="text-[12px]">{cell}</span>
                        ) : (
                          (cell as React.ReactNode)
                        )}
                      </TD>
                    ))}
                  </TR>
                ))}
              </TBody>
            </TableWrap>
          )}
          {report && report.rows.length > 25 && (
            <p className="text-[11px] text-muted-foreground mt-3">
              نمایش {toFaDigits(25)} ردیف از {toFaDigits(report.rows.length)} — برای مشاهده کامل از خروجی استفاده کنید
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
