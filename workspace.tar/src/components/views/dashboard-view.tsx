"use client";

import { LayoutDashboard, FolderKanban, CheckCircle2, AlarmClock, Landmark, FileText, Wallet, HandCoins, Plus, FileBarChart } from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent, SectionTitle } from "@/components/kit/card";
import { StatCard } from "@/components/kit/stat-card";
import { AreaChart } from "@/components/charts/area-chart";
import { GroupedBarChart, ChartLegend } from "@/components/charts/bar-chart";
import { DonutChart, HealthGauge } from "@/components/charts/donut-chart";
import { ProgressBar } from "@/components/kit/progress";
import { Skeleton, TableSkeleton, ErrorState } from "@/components/kit/feedback";
import { Button } from "@/components/kit/button";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { dashboardService, activityService } from "@/services";
import { formatRial, formatRialCompact, formatPercentInt, formatNumber } from "@/lib/format";
import { formatJalaliFull, timeAgo, toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";
import type { Activity } from "@/types";

/* ═══════════════════════════════════════════════════
   داشبورد مدیریتی — نمای کلان سامانه
   ═══════════════════════════════════════════════════ */

const KIND_META: Record<Activity["kind"], { icon: React.ReactNode; color: string }> = {
  contract: { icon: <FolderKanban className="w-3.5 h-3.5" />, color: "bg-teal-500/15 text-teal-500" },
  appendix: { icon: <FileText className="w-3.5 h-3.5" />, color: "bg-violet-500/15 text-violet-500" },
  progress: { icon: <FileBarChart className="w-3.5 h-3.5" />, color: "bg-sky-500/15 text-sky-500" },
  statement: { icon: <FileText className="w-3.5 h-3.5" />, color: "bg-amber-500/15 text-amber-500" },
  payment: { icon: <Wallet className="w-3.5 h-3.5" />, color: "bg-emerald-500/15 text-emerald-500" },
  purchase: { icon: <Landmark className="w-3.5 h-3.5" />, color: "bg-orange-500/15 text-orange-500" },
  document: { icon: <FileText className="w-3.5 h-3.5" />, color: "bg-slate-500/15 text-slate-400" },
  amendment: { icon: <FileText className="w-3.5 h-3.5" />, color: "bg-red-500/15 text-red-500" },
};

export function DashboardView() {
  const { navigate } = useRouter();
  const { data, loading, error, reload } = useAsync(() => dashboardService.stats(), []);
  const { data: activities } = useAsync(() => activityService.list(), []);

  const financial = [
    { label: "ارزش کل قراردادها", value: data?.totalValue ?? 0, color: "bg-primary" },
    { label: "مجموع صورت‌وضعیت‌ها", value: data?.statementsTotal ?? 0, color: "bg-amber-500" },
    { label: "مجموع دریافتی", value: data?.receivedTotal ?? 0, color: "bg-emerald-500" },
    { label: "مطالبات باقی‌مانده", value: data?.receivablesTotal ?? 0, color: "bg-red-500" },
  ];

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="داشبورد مدیریت"
        subtitle={`امروز: ${formatJalaliFull(new Date())}`}
        actions={
          <>
            <Button variant="outline" onClick={() => navigate("/reports")}>
              <FileBarChart className="w-4 h-4" />
              گزارشات
            </Button>
            <Button onClick={() => navigate("/contracts/new")}>
              <Plus className="w-4 h-4" />
              قرارداد جدید
            </Button>
          </>
        }
      />

      {error && <ErrorState onRetry={reload} />}

      {/* KPIها */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-[118px]" />
          ))}
        </div>
      ) : data ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard label="تعداد کل قراردادها" value={data.totalContracts} format={formatNumber} tooltip="مجموع همه قراردادهای ثبت‌شده در سامانه"
            icon={<FolderKanban className="w-5 h-5" />} trend={8}
            iconFrom="oklch(0.6 0.1 195)" iconTo="oklch(0.48 0.09 205)" />
          <StatCard label="قراردادهای فعال" value={data.activeContracts} format={formatNumber} tooltip="قراردادهایی که هم‌اکنون در حال اجرا هستند"
            icon={<CheckCircle2 className="w-5 h-5" />} trend={5}
            iconFrom="oklch(0.62 0.13 158)" iconTo="oklch(0.5 0.12 162)" />
          <StatCard label="نزدیک به پایان" value={data.nearEndContracts} format={formatNumber} tooltip="کمتر از ۴۵ روز تا پایان مهلت قرارداد"
            icon={<AlarmClock className="w-5 h-5" />} trend={2}
            iconFrom="oklch(0.72 0.14 78)" iconTo="oklch(0.6 0.13 70)" />
          <StatCard label="قراردادهای دارای تأخیر" value={data.delayedContracts} format={formatNumber} tooltip="انحراف منفی بیش از حد مجاز از برنامه"
            icon={<AlarmClock className="w-5 h-5" />} trend={-4}
            iconFrom="oklch(0.58 0.19 27)" iconTo="oklch(0.48 0.17 30)" />
          <StatCard label="ارزش کل قراردادها" value={data.totalValue} format={formatRialCompact} tooltip="مجموع مبلغ ریالی همه قراردادها"
            icon={<Landmark className="w-5 h-5" />} trend={12}
            iconFrom="oklch(0.55 0.1 235)" iconTo="oklch(0.45 0.09 240)" />
          <StatCard label="مجموع صورت‌وضعیت‌ها" value={data.statementsTotal} format={formatRialCompact} tooltip="ارزش کارکرد صورت‌وضعیت‌شده با احتساب مالیات"
            icon={<FileText className="w-5 h-5" />} trend={9}
            iconFrom="oklch(0.72 0.14 78)" iconTo="oklch(0.58 0.12 82)" />
          <StatCard label="مجموع دریافتی" value={data.receivedTotal} format={formatRialCompact} tooltip="مجموع مبالغ دریافتی از کارفرمایان"
            icon={<Wallet className="w-5 h-5" />} trend={14}
            iconFrom="oklch(0.62 0.13 158)" iconTo="oklch(0.5 0.12 162)" />
          <StatCard label="مجموع مطالبات" value={data.receivablesTotal} format={formatRialCompact} tooltip="مانده صورت‌وضعیت‌های پرداخت‌نشده"
            icon={<HandCoins className="w-5 h-5" />} trend={-6}
            iconFrom="oklch(0.58 0.19 27)" iconTo="oklch(0.48 0.17 30)" />
        </div>
      ) : null}

      {/* نمودارها */}
      {loading ? (
        <div className="grid lg:grid-cols-3 gap-4 mt-5">
          <Skeleton className="h-[320px] lg:col-span-2" />
          <Skeleton className="h-[320px]" />
        </div>
      ) : data ? (
        <div className="grid lg:grid-cols-3 gap-4 mt-5">
          <Card className="lg:col-span-2" hover>
            <CardHeader>
              <CardTitle>ارزش قراردادهای ثبت‌شده — ۱۲ ماه اخیر</CardTitle>
            </CardHeader>
            <CardContent>
              <AreaChart data={data.monthSeries} formatValue={(v) => formatRialCompact(v)} />
            </CardContent>
          </Card>

          <Card hover>
            <CardHeader>
              <CardTitle>قراردادها بر اساس وضعیت</CardTitle>
            </CardHeader>
            <CardContent className="pt-2">
              <DonutChart
                data={data.statusSeries.map((s, i) => ({
                  label: s.label,
                  value: s.value,
                  color: ["oklch(0.62 0.13 158)", "oklch(0.72 0.14 78)", "oklch(0.58 0.19 27)", "oklch(0.65 0.13 55)", "oklch(0.55 0.1 235)", "oklch(0.5 0.02 250)"][i % 6],
                }))}
              />
            </CardContent>
          </Card>
        </div>
      ) : null}

      {data && (
        <div className="grid lg:grid-cols-3 gap-4 mt-5">
          <Card className="lg:col-span-2" hover>
            <CardHeader>
              <div>
                <CardTitle>مقایسه پیشرفت برنامه‌ای و واقعی</CardTitle>
                <p className="text-[11px] text-muted-foreground mt-0.5">بر اساس وزن‌های پیوست فنی هر قرارداد</p>
              </div>
              <ChartLegend
                items={[
                  { label: "برنامه‌ای", color: "oklch(0.62 0.09 240)" },
                  { label: "واقعی", color: "oklch(0.62 0.1 195)" },
                ]}
              />
            </CardHeader>
            <CardContent>
              <GroupedBarChart data={data.progressComparison} />
            </CardContent>
          </Card>

          <Card hover>
            <CardHeader>
              <CardTitle>وضعیت مالی کلان</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-2">
              {financial.map((f) => {
                const max = financial[0].value || 1;
                return (
                  <div key={f.label}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[12px] text-muted-foreground">{f.label}</span>
                      <span className="nums text-[12px] font-bold">{formatRialCompact(f.value)}</span>
                    </div>
                    <div className="h-2.5 rounded-full bg-secondary overflow-hidden">
                      <div
                        className={cn("h-full rounded-full transition-[width] duration-1000", f.color)}
                        style={{ width: `${(f.value / max) * 100}%` }}
                      />
                    </div>
                  </div>
                );
              })}
              <p className="text-[11px] text-muted-foreground pt-1 border-t border-border">
                نسبت دریافت به صورت‌وضعیت:{" "}
                <b className="nums text-foreground">{formatPercentInt((data.receivedTotal / Math.max(1, data.statementsTotal)) * 100)}٪</b>
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* سلامت قراردادها + فعالیت‌ها */}
      <div className="grid lg:grid-cols-3 gap-4 mt-5">
        <Card hover className="lg:col-span-1">
          <CardHeader>
            <CardTitle>وضعیت سلامت قراردادها</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {data?.healthTop.map((h) => (
              <button
                key={h.contractId}
                onClick={() => navigate(`/contracts/${h.contractId}`)}
                className="w-full flex items-center gap-3 rounded-xl p-2.5 -mx-1 hover:bg-secondary/60 transition-colors text-start"
              >
                <HealthGauge score={h.score} size={74} label="" />
                <div className="min-w-0 flex-1">
                  <p className="nums text-[11px] text-muted-foreground">{toFaDigits(h.code)}</p>
                  <p className="text-[12.5px] font-semibold leading-5 line-clamp-2">{h.title}</p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <Card hover className="lg:col-span-2">
          <CardHeader>
            <CardTitle>آخرین فعالیت‌ها</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate("/contracts")}>مشاهده قراردادها</Button>
          </CardHeader>
          <CardContent>
            {activities ? <ActivityTimeline items={activities.slice(0, 9)} /> : <Skeleton className="h-72" />}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

/* ═══════ تایم‌لاین فعالیت‌ها ═══════ */

export function ActivityTimeline({ items, maxHeight }: { items: Activity[]; maxHeight?: number }) {
  return (
    <div className="relative space-y-4 before:absolute before:start-[15px] before:top-2 before:bottom-2 before:w-px before:bg-border overflow-y-auto" style={{ maxHeight }}>
      {items.map((a, i) => {
        const meta = KIND_META[a.kind];
        return (
          <div key={a.id} className="flex items-start gap-3 anim-fade-up" style={{ animationDelay: `${i * 40}ms` }}>
            <span className={cn("relative z-10 grid place-items-center w-8 h-8 rounded-full border border-border shrink-0", meta.color)}>
              {meta.icon}
            </span>
            <div className="min-w-0 flex-1 pb-1">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <p className="text-[13px] font-semibold">{a.title}</p>
                <span className="text-[10.5px] text-muted-foreground shrink-0">{timeAgo(a.date)}</span>
              </div>
              <p className="text-[11.5px] text-muted-foreground leading-5 line-clamp-2">{a.description}</p>
              <p className="text-[10.5px] text-muted-foreground/70 mt-0.5">توسط {a.user}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
