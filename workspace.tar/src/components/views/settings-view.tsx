"use client";

import { useState } from "react";
import { Settings2, Save, Sun, Moon, Monitor, CalendarDays, Coins, Percent, Tags, Ruler, Bell, Palette, Building2 } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "next-themes";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Input, Select, Field, Switch } from "@/components/kit/form";
import { Button } from "@/components/kit/button";
import { Tabs } from "@/components/kit/tabs";
import { toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";

/* ═══════ تنظیمات سامانه ═══════ */

export function SettingsView() {
  const [tab, setTab] = useState("general");
  const { theme, setTheme } = useTheme();
  const [vat, setVat] = useState("10");
  const [notifEnabled, setNotifEnabled] = useState(true);
  const [emailNotif, setEmailNotif] = useState(false);
  const [defaultCurrency, setDefaultCurrency] = useState("ریال");

  const save = () => toast.success("تنظیمات با موفقیت ذخیره شد");

  return (
    <div className="anim-fade-up max-w-5xl">
      <PageHeader
        title="تنظیمات"
        subtitle="پیکربندی عمومی، تاریخ، ارز و سایر تنظیمات سامانه"
        actions={
          <Button onClick={save}>
            <Save className="w-4 h-4" />
            ذخیره تنظیمات
          </Button>
        }
      />

      <Tabs
        variant="pill"
        className="mb-4"
        active={tab}
        onChange={setTab}
        tabs={[
          { key: "general", label: "تنظیمات عمومی", icon: <Settings2 className="w-4 h-4" /> },
          { key: "date", label: "تنظیمات تاریخ", icon: <CalendarDays className="w-4 h-4" /> },
          { key: "currency", label: "ارز و مالیات", icon: <Coins className="w-4 h-4" /> },
          { key: "statuses", label: "وضعیت‌ها", icon: <Tags className="w-4 h-4" /> },
          { key: "units", label: "واحدها", icon: <Ruler className="w-4 h-4" /> },
          { key: "notif", label: "اعلان‌ها", icon: <Bell className="w-4 h-4" /> },
          { key: "appearance", label: "ظاهر", icon: <Palette className="w-4 h-4" /> },
        ]}
      />

      {tab === "general" && (
        <Card>
          <CardHeader><CardTitle><Building2 className="w-4 h-4 text-primary" /> اطلاعات سازمان</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="نام شرکت"><Input defaultValue="شرکت تأمین تجهیزات صنعتی پیشرو" /></Field>
            <Field label="شناسه ملی"><Input defaultValue="10101234567" className="nums" /></Field>
            <Field label="ساختار سال مالی">
              <Select defaultValue="jalali">
                <option value="jalali">سال مالی شمسی (فروردین تا اسفند)</option>
              </Select>
            </Field>
            <Field label="زبان سامانه">
              <Select defaultValue="fa">
                <option value="fa">فارسی</option>
              </Select>
            </Field>
            <Field label="حالت نمایش اعداد">
              <Select defaultValue="fa">
                <option value="fa">اعداد فارسی (۰۱۲۳)</option>
                <option value="en">اعداد لاتین (0123)</option>
              </Select>
            </Field>
            <Field label="صفحه پیش‌فرض پس از ورود">
              <Select defaultValue="dashboard">
                <option value="dashboard">داشبورد</option>
                <option value="contracts">قراردادها</option>
              </Select>
            </Field>
          </CardContent>
        </Card>
      )}

      {tab === "date" && (
        <Card>
          <CardHeader><CardTitle><CalendarDays className="w-4 h-4 text-primary" /> تقویم و تاریخ</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="تقویم پایه">
              <Select defaultValue="jalali">
                <option value="jalali">تقویم هجری شمسی (جلالی)</option>
              </Select>
            </Field>
            <Field label="قالب نمایش تاریخ" hint="در تمام صفحات سامانه اعمال می‌شود">
              <Select defaultValue="numeric">
                <option value="numeric">۱۴۰۵/۰۶/۱۵</option>
                <option value="long">۱۵ شهریور ۱۴۰۵</option>
              </Select>
            </Field>
            <Field label="روز شروع هفته">
              <Select defaultValue="sat">
                <option value="sat">شنبه</option>
              </Select>
            </Field>
            <Field label="هشدار انقضای قرارداد (روز قبل)">
              <Input defaultValue="30" className="nums" />
            </Field>
          </CardContent>
        </Card>
      )}

      {tab === "currency" && (
        <Card>
          <CardHeader><CardTitle><Coins className="w-4 h-4 text-primary" /> ارز و ارزش افزوده</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="ارز پیش‌فرض">
              <Select value={defaultCurrency} onChange={(e) => setDefaultCurrency(e.target.value)}>
                <option value="ریال">ریال</option>
                <option value="تومان">تومان</option>
              </Select>
            </Field>
            <Field label="درصد ارزش افزوده">
              <div className="relative">
                <Input value={vat} onChange={(e) => setVat(e.target.value)} className="nums pl-9" />
                <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              </div>
            </Field>
            <Field label="ارزهای مجاز معاملات ارزی">
              <Select defaultValue="usd-eur">
                <option value="usd-eur">دلار آمریکا، یورو</option>
                <option value="usd">فقط دلار آمریکا</option>
                <option value="cny">دلار، یورو، یوان</option>
              </Select>
            </Field>
            <Field label="نرخ تبدیل پیش‌فرض (دلار)">
              <Input defaultValue="۸۵۰٬۰۰۰" className="nums" />
            </Field>
          </CardContent>
        </Card>
      )}

      {tab === "statuses" && (
        <Card>
          <CardHeader><CardTitle><Tags className="w-4 h-4 text-primary" /> وضعیت‌های قرارداد و صورت‌وضعیت</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-[12.5px] font-bold mb-2">وضعیت‌های قرارداد</p>
              <div className="flex flex-wrap gap-2">
                {["فعال", "نزدیک پایان", "دارای تأخیر", "متوقف", "تکمیل‌شده", "خاتمه‌یافته"].map((s) => (
                  <span key={s} className="rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-[12px]">{s}</span>
                ))}
                <Button size="sm" variant="ghost" onClick={() => toast.info("افزودن وضعیت جدید")}>+ افزودن</Button>
              </div>
            </div>
            <div>
              <p className="text-[12.5px] font-bold mb-2">وضعیت‌های صورت‌وضعیت</p>
              <div className="flex flex-wrap gap-2">
                {["پیش‌نویس", "در انتظار تأیید", "تأیید شده", "پرداخت شده"].map((s) => (
                  <span key={s} className="rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-[12px]">{s}</span>
                ))}
                <Button size="sm" variant="ghost" onClick={() => toast.info("افزودن وضعیت جدید")}>+ افزودن</Button>
              </div>
            </div>
            <div>
              <p className="text-[12.5px] font-bold mb-2">انواع سند مجاز</p>
              <div className="flex flex-wrap gap-2">
                {["قرارداد اصلی", "الحاقیه", "پیوست فنی", "صورتجلسه", "لیست اقلام", "گزارش فنی"].map((s) => (
                  <span key={s} className="rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-[12px]">{s}</span>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "units" && (
        <Card>
          <CardHeader><CardTitle><Ruler className="w-4 h-4 text-primary" /> واحدهای اندازه‌گیری</CardTitle></CardHeader>
          <CardContent>
            <p className="text-[12px] text-muted-foreground mb-3">واحدهای قابل استفاده در اقلام پیوست فنی و خرید</p>
            <div className="flex flex-wrap gap-2">
              {["عدد", "دستگاه", "ست", "متر", "متر مربع", "کیلوگرم", "تن", "لیتر", "فقره", "بسته"].map((u) => (
                <span key={u} className="rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-[12px]">{u}</span>
              ))}
              <Button size="sm" variant="ghost" onClick={() => toast.info("افزودن واحد جدید")}>+ افزودن واحد</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "notif" && (
        <Card>
          <CardHeader><CardTitle><Bell className="w-4 h-4 text-primary" /> تنظیمات اعلان</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-xl border border-border p-4">
              <div>
                <p className="text-[13px] font-bold">اعلان‌های سامانه</p>
                <p className="text-[11.5px] text-muted-foreground mt-0.5">نمایش هشدارها در مرکز اعلان‌ها</p>
              </div>
              <Switch checked={notifEnabled} onChange={setNotifEnabled} />
            </div>
            <div className="flex items-center justify-between rounded-xl border border-border p-4">
              <div>
                <p className="text-[13px] font-bold">اعلان ایمیلی</p>
                <p className="text-[11.5px] text-muted-foreground mt-0.5">ارسال خلاصه اعلان‌ها به ایمیل</p>
              </div>
              <Switch checked={emailNotif} onChange={setEmailNotif} />
            </div>
            <div className="rounded-xl border border-border p-4 space-y-3">
              <p className="text-[13px] font-bold">آستانه‌های هشدار</p>
              {[
                { label: "انحراف پیشرفت از برنامه (٪)", value: "10" },
                { label: "روزهای باقی‌مانده تا پایان", value: "30" },
                { label: "روزهای تأخیر پرداخت صورت‌وضعیت", value: "15" },
              ].map((r) => (
                <div key={r.label} className="flex items-center justify-between gap-3">
                  <span className="text-[12.5px] text-muted-foreground">{r.label}</span>
                  <Input defaultValue={r.value} className="nums w-24 h-9" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "appearance" && (
        <Card>
          <CardHeader><CardTitle><Palette className="w-4 h-4 text-primary" /> ظاهر و تم</CardTitle></CardHeader>
          <CardContent>
            <p className="text-[12.5px] font-bold mb-3">حالت نمایش</p>
            <div className="grid grid-cols-3 gap-3 max-w-lg">
              {[
                { key: "light", label: "حالت روز", icon: <Sun className="w-5 h-5" /> },
                { key: "dark", label: "حالت شب", icon: <Moon className="w-5 h-5" /> },
                { key: "system", label: "حالت سیستم", icon: <Monitor className="w-5 h-5" /> },
              ].map((o) => (
                <button
                  key={o.key}
                  onClick={() => setTheme(o.key)}
                  className={cn(
                    "rounded-xl border p-4 text-center transition-all",
                    theme === o.key ? "border-primary/50 bg-primary/8 e2" : "border-border bg-card hover:border-primary/30"
                  )}
                >
                  <span className={cn("grid place-items-center w-10 h-10 mx-auto rounded-xl", theme === o.key ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground")}>
                    {o.icon}
                  </span>
                  <p className="text-[12px] font-bold mt-2">{o.label}</p>
                </button>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground mt-4">
              تغییر تم بدون بارگذاری مجدد صفحه اعمال می‌شود. حالت سیستم بر اساس تنظیمات سیستم‌عامل شماست.
              رنگ اصلی سامانه «فیروزه‌ای صنعتی» و فونت «وزیرمتن» است — {toFaDigits(6)} وزن فونت به‌صورت محلی بارگذاری شده‌اند.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
