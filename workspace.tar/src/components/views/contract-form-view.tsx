"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Save, Info, CalendarClock, Landmark, Activity, ArrowRight } from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Input, Select, Textarea, Field } from "@/components/kit/form";
import { JalaliDatePicker } from "@/components/kit/date-picker";
import { Button } from "@/components/kit/button";
import { LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { contractService, employerService } from "@/services";
import { formatRial, parseFaNumber, formatNumber } from "@/lib/format";
import { diffDays, toFaDigits } from "@/lib/jalali";
import type { Contract } from "@/types";

/* ═══════════════════════════════════════════════════
   فرم ایجاد / ویرایش قرارداد — چهار بخشی
   ═══════════════════════════════════════════════════ */

interface FormState {
  title: string; code: string; subject: string; employerId: string; creditSource: string;
  startDate: string; endDate: string;
  amountRial: string; amountForeign: string; currency: string; exchangeRate: string; prepayment: string;
  status: string; description: string;
}

const EMPTY_FORM: FormState = {
  title: "", code: "", subject: "", employerId: "", creditSource: "بودجه عمومی",
  startDate: "", endDate: "",
  amountRial: "", amountForeign: "", currency: "دلار", exchangeRate: "", prepayment: "20",
  status: "active", description: "",
};

export function ContractFormView({ mode, contractId }: { mode: "create" | "edit"; contractId?: string }) {
  const { navigate } = useRouter();
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const { data: employers } = useAsync(() => employerService.list(), []);
  const { data: existing, loading: loadingExisting } = useAsync(
    () => (contractId ? contractService.get(contractId) : Promise.resolve(undefined)),
    [contractId]
  );

  useEffect(() => {
    if (mode === "edit" && existing) {
      setForm({
        title: existing.title, code: existing.code, subject: existing.subject,
        employerId: existing.employerId, creditSource: existing.creditSource,
        startDate: existing.startDate.slice(0, 10), endDate: existing.endDate.slice(0, 10),
        amountRial: String(existing.amountRial), amountForeign: existing.amountForeign ? String(existing.amountForeign) : "",
        currency: existing.currency || "دلار", exchangeRate: existing.exchangeRate ? String(existing.exchangeRate) : "",
        prepayment: String(existing.prepaymentPercent),
        status: existing.status, description: existing.description || "",
      });
    }
  }, [mode, existing]);

  const set = (patch: Partial<FormState>) => setForm((f) => ({ ...f, ...patch }));

  const duration = form.startDate && form.endDate ? diffDays(form.startDate, form.endDate) : null;
  const rialNum = parseFaNumber(form.amountRial);
  const finalEquivalent = rialNum > 0 && form.amountForeign && form.exchangeRate
    ? rialNum + parseFaNumber(form.amountForeign) * parseFaNumber(form.exchangeRate)
    : rialNum;

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.title.trim()) e.title = "نام قرارداد الزامی است";
    if (!form.employerId) e.employerId = "انتخاب کارفرما الزامی است";
    if (!form.startDate) e.startDate = "تاریخ شروع الزامی است";
    if (!form.endDate) e.endDate = "تاریخ پایان الزامی است";
    if (form.startDate && form.endDate && diffDays(form.startDate, form.endDate) <= 0)
      e.endDate = "تاریخ پایان باید بعد از تاریخ شروع باشد";
    if (rialNum <= 0) e.amountRial = "مبلغ قرارداد الزامی است";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) {
      toast.error("لطفاً خطاهای فرم را برطرف کنید");
      return;
    }
    setSaving(true);
    const payload: Partial<Contract> = {
      title: form.title.trim(),
      code: form.code.trim() || undefined,
      subject: form.subject.trim(),
      employerId: form.employerId,
      creditSource: form.creditSource,
      startDate: form.startDate,
      endDate: form.endDate,
      amountRial: rialNum,
      amountForeign: form.amountForeign ? parseFaNumber(form.amountForeign) : undefined,
      currency: form.amountForeign ? form.currency : undefined,
      exchangeRate: form.exchangeRate ? parseFaNumber(form.exchangeRate) : undefined,
      prepaymentPercent: parseFaNumber(form.prepayment) || 0,
      status: form.status as Contract["status"],
      description: form.description.trim(),
    };
    try {
      if (mode === "create") {
        const c = await contractService.create(payload);
        toast.success(`قرارداد ${c.code} با موفقیت ثبت شد`);
        navigate(`/contracts/${c.id}`);
      } else if (contractId) {
        await contractService.update(contractId, payload);
        toast.success("اطلاعات قرارداد بروزرسانی شد");
        navigate(`/contracts/${contractId}`);
      }
    } finally {
      setSaving(false);
    }
  };

  if (mode === "edit" && loadingExisting) return <LoadingBlock />;
  if (mode === "edit" && !existing && !loadingExisting) return <ErrorState message="قرارداد مورد نظر یافت نشد" onRetry={() => navigate("/contracts")} />;

  return (
    <div className="anim-fade-up max-w-5xl mx-auto">
      <PageHeader
        title={mode === "create" ? "ایجاد قرارداد جدید" : "ویرایش قرارداد"}
        subtitle="اطلاعات عمومی، زمان‌بندی، شرایط مالی و وضعیت قرارداد را تکمیل کنید"
        breadcrumb={[{ label: "قراردادها", route: "/contracts" }, { label: mode === "create" ? "ایجاد" : "ویرایش" }]}
        actions={
          <>
            <Button variant="outline" onClick={() => navigate("/contracts")}>
              <ArrowRight className="w-4 h-4" />
              بازگشت
            </Button>
            <Button onClick={submit} disabled={saving}>
              <Save className="w-4 h-4" />
              {saving ? "در حال ذخیره..." : "ذخیره قرارداد"}
            </Button>
          </>
        }
      />

      <div className="space-y-4">
        {/* اطلاعات عمومی */}
        <Card>
          <CardHeader>
            <CardTitle><Info className="w-4 h-4 text-primary" /> اطلاعات عمومی</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="نام قرارداد" required error={errors.title} className="md:col-span-2">
              <Input value={form.title} onChange={(e) => set({ title: e.target.value })} placeholder="مثال: تأمین قطعات موتور و سیستم انتقال قدرت" />
            </Field>
            <Field label="کد قرارداد" hint="در صورت خالی بودن به‌صورت خودکار تولید می‌شود">
              <Input value={form.code} onChange={(e) => set({ code: e.target.value })} placeholder="CTR-1405-..." className="nums" />
            </Field>
            <Field label="کارفرما" required error={errors.employerId}>
              <Select value={form.employerId} onChange={(e) => set({ employerId: e.target.value })}>
                <option value="">انتخاب کارفرما...</option>
                {employers?.map((e) => (
                  <option key={e.id} value={e.id}>{e.name}</option>
                ))}
              </Select>
            </Field>
            <Field label="موضوع قرارداد" className="md:col-span-2">
              <Input value={form.subject} onChange={(e) => set({ subject: e.target.value })} placeholder="خلاصه موضوع و دامنه کار" />
            </Field>
            <Field label="محل اعتبار">
              <Select value={form.creditSource} onChange={(e) => set({ creditSource: e.target.value })}>
                {["بودجه عمومی", "بودجه عمرانی", "اعتبارات اختصاصی طرح", "منابع داخلی شرکت", "فصل تأمین کالا", "اعتبارات پروژه‌های ملی"].map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </Select>
            </Field>
          </CardContent>
        </Card>

        {/* زمان‌بندی */}
        <Card>
          <CardHeader>
            <CardTitle><CalendarClock className="w-4 h-4 text-primary" /> زمان‌بندی</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Field label="تاریخ شروع" required error={errors.startDate}>
              <JalaliDatePicker value={form.startDate} onChange={(v) => set({ startDate: v })} />
            </Field>
            <Field label="تاریخ پایان" required error={errors.endDate}>
              <JalaliDatePicker value={form.endDate} onChange={(v) => set({ endDate: v })} />
            </Field>
            <Field label="مدت قرارداد">
              <div className="h-10 rounded-lg border border-dashed border-border bg-secondary/40 px-3 flex items-center text-[13px] nums">
                {duration !== null && duration > 0 ? (
                  <>
                    <b className="ml-1">{toFaDigits(duration)}</b> روز
                    <span className="text-muted-foreground"> ≈ {toFaDigits(Math.round(duration / 30))} ماه</span>
                  </>
                ) : (
                  <span className="text-muted-foreground">پس از انتخاب تاریخ‌ها محاسبه می‌شود</span>
                )}
              </div>
            </Field>
          </CardContent>
        </Card>

        {/* شرایط مالی */}
        <Card>
          <CardHeader>
            <CardTitle><Landmark className="w-4 h-4 text-primary" /> شرایط مالی</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Field label="مبلغ ریالی (ریال)" required error={errors.amountRial} className="md:col-span-2" hint="ارقام با اعداد فارسی یا لاتین قابل ورود است">
              <Input value={form.amountRial} onChange={(e) => set({ amountRial: e.target.value })} placeholder="مثال: ۲۵۰٬۰۰۰٬۰۰۰٬۰۰۰" className="nums" />
              {rialNum > 0 && <p className="text-[11px] text-primary font-medium">{formatRial(rialNum)}</p>}
            </Field>
            <Field label="درصد پیش‌پرداخت">
              <Input value={form.prepayment} onChange={(e) => set({ prepayment: e.target.value })} className="nums" />
            </Field>
            <Field label="مبلغ ارزی">
              <Input value={form.amountForeign} onChange={(e) => set({ amountForeign: e.target.value })} placeholder="اختیاری" className="nums" />
            </Field>
            <Field label="نوع ارز">
              <Select value={form.currency} onChange={(e) => set({ currency: e.target.value })} disabled={!form.amountForeign}>
                <option value="دلار">دلار آمریکا</option>
                <option value="یورو">یورو</option>
                <option value="یوان">یوان</option>
              </Select>
            </Field>
            <Field label="نرخ تبدیل (ریال)">
              <Input value={form.exchangeRate} onChange={(e) => set({ exchangeRate: e.target.value })} placeholder="اختیاری" className="nums" />
            </Field>
            {finalEquivalent > 0 && (
              <p className="md:col-span-3 text-[12px] text-muted-foreground rounded-lg bg-secondary/50 border border-border px-3 py-2">
                معادل کل قرارداد: <b className="nums text-foreground">{formatRial(finalEquivalent)}</b>
              </p>
            )}
          </CardContent>
        </Card>

        {/* وضعیت */}
        <Card>
          <CardHeader>
            <CardTitle><Activity className="w-4 h-4 text-primary" /> وضعیت و توضیحات</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-4">
            <Field label="وضعیت قرارداد">
              <Select value={form.status} onChange={(e) => set({ status: e.target.value })}>
                <option value="active">فعال</option>
                <option value="near-end">نزدیک پایان</option>
                <option value="delayed">دارای تأخیر</option>
                <option value="suspended">متوقف</option>
                <option value="completed">تکمیل‌شده</option>
                <option value="terminated">خاتمه‌یافته</option>
              </Select>
            </Field>
            <Field label="توضیحات">
              <Textarea value={form.description} onChange={(e) => set({ description: e.target.value })} rows={4} placeholder="شرح کامل قرارداد، شرایط خاص و ملاحظات..." />
            </Field>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-2 pb-4">
          <Button variant="outline" onClick={() => navigate("/contracts")}>انصراف</Button>
          <Button onClick={submit} disabled={saving}>
            <Save className="w-4 h-4" />
            {saving ? "در حال ذخیره..." : mode === "create" ? "ثبت قرارداد" : "ذخیره تغییرات"}
          </Button>
        </div>
      </div>
    </div>
  );
}
