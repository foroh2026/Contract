"use client";

import { useMemo } from "react";
import {
  Pencil, FileText, Wallet, HandCoins, Landmark, Activity, Paperclip,
  ShoppingCart, FolderOpen, History, Gauge, Plus, ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Tabs } from "@/components/kit/tabs";
import { ContractStatusBadge } from "@/components/kit/badge";
import { ProgressBar, CircularProgress } from "@/components/kit/progress";
import { Button } from "@/components/kit/button";
import { LoadingBlock, ErrorState, Skeleton } from "@/components/kit/feedback";
import { HealthGauge } from "@/components/charts/donut-chart";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import {
  contractService, employerService, appendixService, statementService,
  paymentService, purchaseService, activityService, amendmentService, documentService,
} from "@/services";
import { computeHealthScore } from "@/lib/health";
import { contractProgressSummary, remainingDays } from "@/lib/progress";
import { formatRialCompact, formatRial, formatSignedPercent, formatPercentInt, formatNumber } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";
import { ActivityTimeline } from "./dashboard-view";
import { AppendixTab } from "./contract/appendix-tab";
import { ProgressTab } from "./contract/progress-tab";
import { PurchasesTab } from "./contract/purchases-tab";
import { StatementsTab, PaymentsTab } from "./contract/statements-tab";
import { DocumentsTab, AmendmentsTab, ActivityTab } from "./contract/documents-tab";
import { FinancialTab } from "./contract/financial-tab";

/* ═══════════════════════════════════════════════════
   جزئیات قرارداد — داشبورد اختصاصی هر قرارداد
   ═══════════════════════════════════════════════════ */

export function ContractDetailView({ contractId, section }: { contractId: string; section: string }) {
  const { navigate } = useRouter();

  const { data: contract, loading, error, reload } = useAsync(() => contractService.get(contractId), [contractId]);
  const { data: employer } = useAsync(() => employerService.get(contract?.employerId || ""), [contract?.employerId]);
  const { data: appendix } = useAsync(() => appendixService.getByContract(contractId), [contractId]);
  const { data: statements } = useAsync(() => statementService.byContract(contractId), [contractId]);
  const { data: payments } = useAsync(() => paymentService.byContract(contractId), [contractId]);
  const { data: purchases } = useAsync(() => purchaseService.byContract(contractId), [contractId]);
  const { data: amendments } = useAsync(() => amendmentService.byContract(contractId), [contractId]);
  const { data: docs } = useAsync(() => documentService.byContract(contractId), [contractId]);
  const { data: activities } = useAsync(() => activityService.byContract(contractId), [contractId]);

  const summary = useMemo(
    () => (contract && appendix ? contractProgressSummary(contract, appendix) : null),
    [contract, appendix]
  );

  const health = useMemo(() => {
    if (!contract || !summary || !statements || !payments || !purchases) return null;
    return computeHealthScore({
      contract, actual: summary.actual, planned: summary.planned, statements, payments, purchases,
    });
  }, [contract, summary, statements, payments, purchases]);

  if (loading) return <LoadingBlock label="در حال دریافت اطلاعات قرارداد..." />;
  if (error || !contract) return <ErrorState message="قرارداد مورد نظر یافت نشد" onRetry={reload} />;

  const paid = (payments || []).reduce((a, p) => a + p.amount, 0);
  const stTotal = (statements || []).reduce((a, s) => a + s.finalAmount, 0);
  const receivables = Math.max(0, stTotal - paid);
  const remain = remainingDays(contract);

  const TABS = [
    { key: "overview", label: "اطلاعات قرارداد", icon: <Gauge className="w-4 h-4" /> },
    { key: "financial", label: "مالی", icon: <Landmark className="w-4 h-4" /> },
    { key: "technical-appendix", label: "پیوست فنی", icon: <Paperclip className="w-4 h-4" />, badge: appendix?.items.length },
    { key: "purchases", label: "خرید و ساخت", icon: <ShoppingCart className="w-4 h-4" />, badge: purchases?.length },
    { key: "progress", label: "پیشرفت", icon: <Activity className="w-4 h-4" /> },
    { key: "statements", label: "صورت‌وضعیت", icon: <FileText className="w-4 h-4" />, badge: statements?.length },
    { key: "payments", label: "دریافتی‌ها", icon: <Wallet className="w-4 h-4" />, badge: payments?.length },
    { key: "documents", label: "اسناد", icon: <FolderOpen className="w-4 h-4" />, badge: docs?.length },
    { key: "amendments", label: "الحاقیه‌ها", icon: <FileText className="w-4 h-4" />, badge: amendments?.length },
    { key: "activity", label: "تاریخچه فعالیت", icon: <History className="w-4 h-4" /> },
  ];

  return (
    <div className="anim-fade-up">
      <PageHeader
        title={contract.title}
        breadcrumb={[
          { label: "قراردادها", route: "/contracts" },
          { label: toFaDigits(contract.code) },
          { label: TABS.find((t) => t.key === section)?.label || "جزئیات" },
        ]}
        actions={
          <>
            <Button variant="outline" onClick={() => navigate("/contracts")}>
              <ArrowRight className="w-4 h-4" />
              بازگشت به لیست
            </Button>
            <Button variant="outline" onClick={() => navigate(`/contracts/${contract.id}/edit`)}>
              <Pencil className="w-4 h-4" />
              ویرایش
            </Button>
            <Button onClick={() => navigate(`/contracts/${contract.id}/progress`)}>
              <Plus className="w-4 h-4" />
              ثبت پیشرفت
            </Button>
          </>
        }
      />

      {/* هدر قرارداد */}
      <Card className="mb-4 overflow-hidden relative">
        <div className="absolute inset-0 hero-panel pointer-events-none" />
        <div className="absolute inset-0 blueprint-grid opacity-40 pointer-events-none" />
        <CardContent className="relative pt-5">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div className="min-w-0">
              <div className="flex items-center gap-2.5 flex-wrap">
                <span className="nums rounded-lg bg-primary/12 border border-primary/25 text-primary px-2.5 py-1 text-[12.5px] font-extrabold">
                  {toFaDigits(contract.code)}
                </span>
                <ContractStatusBadge status={contract.status} />
              </div>
              <h2 className="text-lg font-extrabold mt-2.5">{contract.title}</h2>
              <p className="text-[13px] text-muted-foreground mt-1">{contract.subject}</p>
              <div className="flex items-center gap-4 mt-3 flex-wrap text-[12px] text-muted-foreground">
                <span>کارفرما: <b className="text-foreground">{employer?.name ?? "—"}</b></span>
                <span className="w-px h-4 bg-border" />
                <span>اعتبار: <b className="text-foreground">{contract.creditSource}</b></span>
              </div>
              <div className="flex items-center gap-3 mt-2 flex-wrap text-[12px]">
                <span className="nums rounded-lg bg-secondary px-2.5 py-1 border border-border">
                  شروع: <b>{formatJalali(contract.startDate)}</b>
                </span>
                <span className="nums rounded-lg bg-secondary px-2.5 py-1 border border-border">
                  پایان: <b>{formatJalali(contract.endDate)}</b>
                </span>
                {(contract.status === "active" || contract.status === "near-end" || contract.status === "delayed") && (
                  <span className={cn(
                    "nums rounded-lg px-2.5 py-1 border font-semibold",
                    remain < 0 ? "bg-red-500/12 text-red-500 border-red-500/30" : remain < 30 ? "bg-amber-500/12 text-amber-600 border-amber-500/30" : "bg-emerald-500/12 text-emerald-600 border-emerald-500/30"
                  )}>
                    {remain < 0 ? `${toFaDigits(Math.abs(remain))} روز تأخیر` : `${toFaDigits(remain)} روز باقی‌مانده`}
                  </span>
                )}
              </div>
            </div>
            {health && (
              <div className="shrink-0 rounded-2xl border border-border bg-card/70 backdrop-blur px-4 py-2 e1">
                <HealthGauge score={health.score} size={150} />
              </div>
            )}
          </div>

          {/* نوار KPI قرارداد */}
          <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mt-5">
            <MiniKpi label="مبلغ قرارداد" value={formatRialCompact(contract.amountRial)} icon={<Landmark className="w-4 h-4" />} />
            <MiniKpi label="پیشرفت واقعی" value={formatPercentInt(summary?.actual ?? 0)} icon={<Activity className="w-4 h-4" />} accent="text-emerald-500" />
            <MiniKpi label="پیشرفت برنامه‌ای" value={formatPercentInt(summary?.planned ?? 0)} icon={<Gauge className="w-4 h-4" />} accent="text-sky-500" />
            <MiniKpi
              label="انحراف"
              value={formatSignedPercent(summary?.deviation ?? 0, 1)}
              icon={<Gauge className="w-4 h-4" />}
              accent={(summary?.deviation ?? 0) >= 0 ? "text-emerald-500" : "text-red-500"}
            />
            <MiniKpi label="صورت‌وضعیت‌ها" value={formatRialCompact(stTotal)} icon={<FileText className="w-4 h-4" />} />
            <MiniKpi label="دریافتی" value={formatRialCompact(paid)} icon={<Wallet className="w-4 h-4" />} accent="text-emerald-500" />
            <MiniKpi label="مطالبات" value={formatRialCompact(receivables)} icon={<HandCoins className="w-4 h-4" />} accent="text-red-500" />
          </div>
        </CardContent>
      </Card>

      {/* تب‌ها */}
      <Tabs
        tabs={TABS}
        active={section}
        onChange={(k) => navigate(`/contracts/${contractId}/${k}`)}
        variant="pill"
        className="mb-4"
      />

      {/* محتوای تب */}
      {section === "overview" && (
        <OverviewTab
          contract={contract}
          summary={summary}
          appendixItems={appendix?.items.length ?? 0}
          completedItems={summary?.completedItems ?? 0}
          activities={activities || []}
          stTotal={stTotal}
          paid={paid}
          health={health}
        />
      )}
      {section === "financial" && contract && (
        <FinancialTab contract={contract} statements={statements || []} payments={payments || []} amendments={amendments || []} />
      )}
      {section === "technical-appendix" && <AppendixTab contractId={contractId} />}
      {section === "purchases" && <PurchasesTab contractId={contractId} />}
      {section === "progress" && <ProgressTab contractId={contractId} />}
      {section === "statements" && <StatementsTab contractId={contractId} />}
      {section === "payments" && <PaymentsTab contractId={contractId} />}
      {section === "documents" && <DocumentsTab contractId={contractId} />}
      {section === "amendments" && contract && (
        <AmendmentsTab contract={contract} amendments={amendments || []} />
      )}
      {section === "activity" && contract && <ActivityTab contractId={contract.id} />}
    </div>
  );
}

function MiniKpi({ label, value, icon, accent }: { label: string; value: string; icon: React.ReactNode; accent?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card/80 backdrop-blur px-3 py-2.5 e1">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <span className={cn("shrink-0", accent)}>{icon}</span>
        <span className="text-[10.5px] truncate">{label}</span>
      </div>
      <p className={cn("nums text-[14px] font-extrabold mt-1 truncate", accent)}>{value}</p>
    </div>
  );
}

/* ═══════ تب نمای کلی قرارداد ═══════ */

function OverviewTab({
  contract, summary, appendixItems, completedItems, activities, stTotal, paid, health,
}: {
  contract: NonNullable<Awaited<ReturnType<typeof contractService.get>>>;
  summary: ReturnType<typeof contractProgressSummary> | null;
  appendixItems: number;
  completedItems: number;
  activities: Awaited<ReturnType<typeof activityService.byContract>>;
  stTotal: number;
  paid: number;
  health: ReturnType<typeof computeHealthScore> | null;
}) {
  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-1" hover>
        <CardHeader><CardTitle>پیشرفت کل قرارداد</CardTitle></CardHeader>
        <CardContent className="flex flex-col items-center gap-4">
          <CircularProgress value={summary?.actual ?? 0} size={150} sublabel="پیشرفت واقعی وزن‌دار" />
          <div className="w-full space-y-3">
            <div>
              <div className="flex justify-between text-[12px] mb-1">
                <span className="text-muted-foreground">برنامه‌ای</span>
                <b className="nums text-sky-500">{formatPercentInt(summary?.planned ?? 0)}</b>
              </div>
              <ProgressBar value={summary?.planned ?? 0} size="sm" />
            </div>
            <div>
              <div className="flex justify-between text-[12px] mb-1">
                <span className="text-muted-foreground">واقعی</span>
                <b className="nums text-emerald-500">{formatPercentInt(summary?.actual ?? 0)}</b>
              </div>
              <ProgressBar value={summary?.actual ?? 0} size="sm" />
            </div>
            <p className={cn("text-center text-[12px] font-bold nums", (summary?.deviation ?? 0) >= 0 ? "text-emerald-500" : "text-red-500")}>
              انحراف: {formatSignedPercent(summary?.deviation ?? 0, 1)}
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2" hover>
        <CardHeader><CardTitle>وضعیت پیوست فنی</CardTitle></CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-3">
            <div className="rounded-xl border border-border bg-secondary/40 p-4 text-center">
              <p className="nums text-2xl font-extrabold">{toFaDigits(appendixItems)}</p>
              <p className="text-[11.5px] text-muted-foreground mt-1">کل اقلام تعریف‌شده</p>
            </div>
            <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/8 p-4 text-center">
              <p className="nums text-2xl font-extrabold text-emerald-500">{toFaDigits(completedItems)}</p>
              <p className="text-[11.5px] text-muted-foreground mt-1">قلم تکمیل‌شده</p>
            </div>
            <div className="rounded-xl border border-border bg-secondary/40 p-4 text-center">
              <p className="nums text-2xl font-extrabold text-amber-500">{toFaDigits((summary?.inProgressItems ?? 0) + (summary?.stoppedItems ?? 0))}</p>
              <p className="text-[11.5px] text-muted-foreground mt-1">در حال اجرا / متوقف</p>
            </div>
          </div>

          {health && (
            <div className="mt-4 rounded-xl border border-border p-4">
              <p className="text-[13px] font-bold mb-3">عوامل مؤثر بر امتیاز سلامت ({toFaDigits(health.score)} از {toFaDigits(100)})</p>
              <div className="space-y-2.5">
                {health.factors.map((f) => (
                  <div key={f.label} className="flex items-center gap-3">
                    <span className="text-[11.5px] text-muted-foreground w-40 shrink-0">{f.label}</span>
                    <ProgressBar value={f.score} size="sm" className="flex-1" />
                    <span className="nums text-[11px] font-bold w-16 text-left">{formatNumber(f.score)}٪ (وزن {toFaDigits(f.weight)})</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="lg:col-span-2" hover>
        <CardHeader><CardTitle>خلاصه مالی</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {[
            { label: "مبلغ قرارداد", value: contract.amountRial, color: "bg-primary" },
            { label: "صورت‌وضعیت‌ها", value: stTotal, color: "bg-amber-500" },
            { label: "دریافتی", value: paid, color: "bg-emerald-500" },
          ].map((row) => (
            <div key={row.label}>
              <div className="flex justify-between text-[12px] mb-1.5">
                <span className="text-muted-foreground">{row.label}</span>
                <b className="nums">{formatRial(row.value)}</b>
              </div>
              <div className="h-2.5 rounded-full bg-secondary overflow-hidden">
                <div className={cn("h-full rounded-full transition-[width] duration-1000", row.color)} style={{ width: `${(row.value / Math.max(1, contract.amountRial)) * 100}%` }} />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card hover>
        <CardHeader><CardTitle>آخرین فعالیت‌های قرارداد</CardTitle></CardHeader>
        <CardContent>
          {activities.length ? (
            <ActivityTimeline items={activities.slice(0, 6)} />
          ) : (
            <p className="text-[12px] text-muted-foreground text-center py-6">فعالیتی ثبت نشده است</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
