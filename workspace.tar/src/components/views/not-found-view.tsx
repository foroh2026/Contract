"use client";

import { Compass } from "lucide-react";
import { Button } from "@/components/kit/button";
import { useRouter } from "@/lib/router";

/* ═══════ صفحه ۴۰۴ ═══════ */

export function NotFoundView() {
  const { navigate } = useRouter();
  return (
    <div className="grid place-items-center py-24 text-center anim-fade-up">
      <span className="grid place-items-center w-20 h-20 rounded-2xl bg-primary/10 text-primary e1 rotate-3">
        <Compass className="w-10 h-10" strokeWidth={1.4} />
      </span>
      <h1 className="mt-5 text-xl font-extrabold">صفحه مورد نظر یافت نشد</h1>
      <p className="mt-2 text-[13px] text-muted-foreground max-w-sm leading-7">
        آدرس واردشده در سامانه وجود ندارد یا به مسیر دیگری منتقل شده است.
      </p>
      <Button className="mt-5" onClick={() => navigate("/dashboard")}>
        بازگشت به داشبورد
      </Button>
    </div>
  );
}
