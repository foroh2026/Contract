"use client";

import { useMemo, useState } from "react";
import { Activity, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD } from "@/components/kit/table";
import { ProgressBar } from "@/components/kit/progress";
import { ContractStatusBadge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { GroupedBarChart } from "@/components/charts/bar-chart";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { contractService, appendixService } from "@/services";
import { contractProgressSummary } from "@/lib/progress";
import { formatSignedPercent } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";

/* ═══════ پیشرفت قراردادها — نمای سراسری ═══════ */

export function ProgressView() {
  const { navigate } = useRouter();
  const { data: contracts, loading, error, reload } = useAsync(() => contractService.list(), []);
  const { data: appendices } = useAsync(async () => {
    const cs = await contractService.list();
    const out: Record<string, Awaited<ReturnType<typeof appendixService.getByContract>>> = {};
    await Promise.all(cs.map(async (c) => (out[c.id] = await appendixService.getByContract(c.id))));
    return out;
  }, []);

  const rows = useMemo(() => {
    return (contracts || [])
      .filter((c) => c.status !== "terminated")
      .map((c) => {
        const ap = appendices?.[c.id];
        return ap ? { contract: c, summary: contractProgressSummary(c, ap) } : null;
      })
      .filter((x): x is NonNullable<typeof x> => x !== null)
      .sort((a, b) => a.summary.deviation - b.summary.deviation);
  }, [contracts, appendices]);

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="پیشرفت قراردادها"
        subtitle="مقایسه پیشرفت برنامه‌ای و واقعی بر اساس وزن‌های پیوست فنی"
        actions={
          <Button variant="outline" onClick={() => toast.success("گزارش پیشرفت صادر شد")}>
            <FileSpreadsheet className="w-4 h-4" />
            خروجی
          </Button>
        }
      />

      <Card className="mb-4">
        <CardHeader>
          <CardTitle><Activity className="w-4 h-4 text-primary" /> مقایسه برنامه و عملکرد</CardTitle>
        </CardHeader>
        <CardContent>
          <GroupedBarChart data={rows.slice(0, 10).map((r) => ({ label: r.contract.code.slice(-3), plan: Math.round(r.summary.planned), actual: Math.round(r.summary.actual) }))} />
        </CardContent>
      </Card>

      <TableWrap>
        <THead>
          <TH>کد قرارداد</TH>
          <TH>نام قرارداد</TH>
          <TH>وضعیت</TH>
          <TH className="min-w-48">پیشرفت واقعی / برنامه‌ای</TH>
          <TH>انحراف</TH>
          <TH>اقلام تکمیل‌شده</TH>
        </THead>
        <TBody>
          {rows.map(({ contract: c, summary }) => (
            <TR key={c.id} onClick={() => navigate(`/contracts/${c.id}/progress`)}>
              <TD><span className="nums text-[12px] font-bold text-primary">{toFaDigits(c.code)}</span></TD>
              <TD className="text-[12.5px] font-semibold max-w-72"><p className="truncate">{c.title}</p></TD>
              <TD><ContractStatusBadge status={c.status} /></TD>
              <TD>
                <ProgressBar value={summary.actual} plan={summary.planned} size="sm" showLabel />
                <p className="nums text-[10px] text-muted-foreground mt-1">برنامه: {toFaDigits(Math.round(summary.planned))}٪</p>
              </TD>
              <TD>
                <span className={cn("nums text-[12.5px] font-bold", summary.deviation >= 0 ? "text-emerald-500" : "text-red-500")}>
                  {formatSignedPercent(summary.deviation, 1)}
                </span>
              </TD>
              <TD className="nums text-[12px] whitespace-nowrap">
                {toFaDigits(summary.completedItems)} از {toFaDigits(summary.totalItems)}
              </TD>
            </TR>
          ))}
        </TBody>
      </TableWrap>
    </div>
  );
}
