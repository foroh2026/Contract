"use client";

import { useMemo, useState } from "react";
import { FileText, Wallet, HandCoins, Plus } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD, Pagination } from "@/components/kit/table";
import { ProgressBar } from "@/components/kit/progress";
import { StatementStatusBadge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { SearchInput, Select } from "@/components/kit/form";
import { StatCard } from "@/components/kit/stat-card";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { statementService, paymentService, contractService, employerService } from "@/services";
import { formatRialCompact, formatRial } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import type { Statement } from "@/types";
import { cn } from "@/lib/utils";

/* ═══════ صورت‌وضعیت‌ها — نمای سراسری ═══════ */

export function useStatementsData() {
  const { data: statements, loading, error, reload } = useAsync(() => statementService.list(), []);
  const { data: payments } = useAsync(() => paymentService.list(), []);
  const { data: contracts } = useAsync(() => contractService.list(), []);
  return { statements: statements || [], payments: payments || [], contracts: contracts || [], loading, error, reload };
}

export function StatementsView() {
  const { navigate } = useRouter();
  const { statements, payments, contracts, loading, error, reload } = useStatementsData();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const contractCode = (id: string) => contracts.find((c) => c.id === id)?.code ?? "—";
  const paidOf = (sid: string) => payments.filter((p) => p.statementId === sid).reduce((a, p) => a + p.amount, 0);

  const filtered = useMemo(() => {
    const contractCode = (id: string) => contracts.find((c) => c.id === id)?.code ?? "—";
    let list = [...statements];
    if (q.trim()) {
      const lc = q.trim().toLowerCase();
      list = list.filter((s) => s.code.toLowerCase().includes(lc) || contractCode(s.contractId).toLowerCase().includes(lc));
    }
    if (status) list = list.filter((s) => s.status === status);
    list.sort((a, b) => (a.date < b.date ? 1 : -1));
    return list;
  }, [statements, q, status, contracts]);

  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);
  const total = statements.reduce((a, s) => a + s.finalAmount, 0);
  const paidTotal = statements.reduce((a, s) => a + paidOf(s.id), 0);

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="صورت‌وضعیت‌ها"
        subtitle="کارکردهای تأییدشده و وضعیت پرداخت آن‌ها"
        actions={
          <Button onClick={() => toast.success("صورت‌وضعیت جدید ثبت شد")}>
            <Plus className="w-4 h-4" />
            صورت‌وضعیت جدید
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <StatCard label="مجموع صورت‌وضعیت‌ها" value={total} format={formatRialCompact} icon={<FileText className="w-5 h-5" />} tooltip="با احتساب ارزش افزوده" />
        <StatCard label="مجموع دریافتی" value={paidTotal} format={formatRialCompact} icon={<Wallet className="w-5 h-5" />} iconFrom="oklch(0.62 0.13 158)" iconTo="oklch(0.5 0.12 162)" />
        <StatCard label="مانده مطالبات" value={Math.max(0, total - paidTotal)} format={formatRialCompact} icon={<HandCoins className="w-5 h-5" />} iconFrom="oklch(0.58 0.19 27)" iconTo="oklch(0.48 0.17 30)" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>همه صورت‌وضعیت‌ها</CardTitle>
          <div className="flex gap-2 flex-wrap">
            <SearchInput placeholder="کد صورت‌وضعیت یا قرارداد..." value={q} onChange={(e) => setQ(e.target.value)} className="w-56" />
            <Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-40">
              <option value="">همه وضعیت‌ها</option>
              <option>پیش‌نویس</option>
              <option>در انتظار تأیید</option>
              <option>تأیید شده</option>
              <option>پرداخت شده</option>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {error ? <ErrorState onRetry={reload} /> : loading ? <LoadingBlock /> : paged.length === 0 ? (
            <EmptyState title="صورت‌وضعیتی یافت نشد" icon={<FileText className="w-9 h-9" />} />
          ) : (
            <>
              <TableWrap className="border-0">
                <THead>
                  <TH>شماره</TH>
                  <TH>قرارداد</TH>
                  <TH>تاریخ</TH>
                  <TH>مبلغ ناخالص</TH>
                  <TH>مبلغ نهایی</TH>
                  <TH className="min-w-36">وضعیت پرداخت</TH>
                  <TH>وضعیت</TH>
                </THead>
                <TBody>
                  {paged.map((s: Statement) => {
                    const paid = paidOf(s.id);
                    const pct = Math.min(100, (paid / Math.max(1, s.finalAmount)) * 100);
                    return (
                      <TR key={s.id} onClick={() => navigate(`/contracts/${s.contractId}/statements`)}>
                        <TD><span className="nums text-[12.5px] font-extrabold text-primary">{toFaDigits(s.code)}</span></TD>
                        <TD><span className="nums text-[11.5px]">{toFaDigits(contractCode(s.contractId))}</span></TD>
                        <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(s.date)}</TD>
                        <TD className="nums text-[12px] whitespace-nowrap">{formatRialCompact(s.grossAmount)}</TD>
                        <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRialCompact(s.finalAmount)}</TD>
                        <TD><ProgressBar value={pct} size="sm" showLabel /></TD>
                        <TD><StatementStatusBadge status={s.status} /></TD>
                      </TR>
                    );
                  })}
                </TBody>
              </TableWrap>
              <Pagination page={page} pageSize={pageSize} total={filtered.length} onPage={setPage} />
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ═══════ دریافتی‌ها — نمای سراسری ═══════ */

export function PaymentsView() {
  const { navigate } = useRouter();
  const { statements, payments, contracts, loading, error, reload } = useStatementsData();
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const contractCode = (id: string) => contracts.find((c) => c.id === id)?.code ?? "—";

  const filtered = useMemo(() => {
    const contractCode = (id: string) => contracts.find((c) => c.id === id)?.code ?? "—";
    let list = [...payments];
    if (q.trim()) {
      const lc = q.trim().toLowerCase();
      list = list.filter((p) => p.code.toLowerCase().includes(lc) || p.reference.toLowerCase().includes(lc) || contractCode(p.contractId).toLowerCase().includes(lc));
    }
    list.sort((a, b) => (a.date < b.date ? 1 : -1));
    return list;
  }, [payments, q, contracts]);

  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);
  const total = payments.reduce((a, p) => a + p.amount, 0);

  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="دریافتی‌ها"
        subtitle={`مجموع دریافت‌های ثبت‌شده: ${formatRial(total)}`}
        actions={
          <Button onClick={() => toast.success("دریافت جدید ثبت شد")}>
            <Plus className="w-4 h-4" />
            ثبت دریافت
          </Button>
        }
      />

      <Card>
        <CardHeader>
          <CardTitle>همه دریافت‌ها</CardTitle>
          <SearchInput placeholder="کد دریافت، شماره پیگیری..." value={q} onChange={(e) => setQ(e.target.value)} className="w-60" />
        </CardHeader>
        <CardContent>
          {loading ? <LoadingBlock /> : paged.length === 0 ? (
            <EmptyState title="دریافتی یافت نشد" icon={<Wallet className="w-9 h-9" />} />
          ) : (
            <>
              <TableWrap className="border-0">
                <THead>
                  <TH>کد</TH>
                  <TH>قرارداد</TH>
                  <TH>صورت‌وضعیت</TH>
                  <TH>مبلغ</TH>
                  <TH>تاریخ</TH>
                  <TH>روش</TH>
                  <TH>مرجع</TH>
                  <TH>شرح</TH>
                </THead>
                <TBody>
                  {paged.map((p) => {
                    const st = statements.find((s) => s.id === p.statementId);
                    return (
                      <TR key={p.id} onClick={() => navigate(`/contracts/${p.contractId}/payments`)}>
                        <TD><span className="nums text-[12px] font-bold text-primary">{toFaDigits(p.code)}</span></TD>
                        <TD><span className="nums text-[11.5px]">{toFaDigits(contractCode(p.contractId))}</span></TD>
                        <TD><span className="nums text-[11.5px]">{st ? toFaDigits(st.code) : <span className="text-muted-foreground">پیش‌پرداخت</span>}</span></TD>
                        <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRial(p.amount)}</TD>
                        <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(p.date)}</TD>
                        <TD className="text-[12px] whitespace-nowrap">{p.method}</TD>
                        <TD className="nums text-[12px] text-muted-foreground">{toFaDigits(p.reference)}</TD>
                        <TD className="text-[11.5px] text-muted-foreground max-w-48"><p className="truncate">{p.description}</p></TD>
                      </TR>
                    );
                  })}
                </TBody>
              </TableWrap>
              <Pagination page={page} pageSize={pageSize} total={filtered.length} onPage={setPage} />
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ═══════ مطالبات — نمای سراسری ═══════ */

export function ReceivablesView() {
  const { navigate } = useRouter();
  const { statements, payments, contracts, loading, error, reload } = useStatementsData();
  const { data: employers } = useAsync(() => employerService.list(), []);

  const rows = useMemo(() => {
    return statements
      .map((s) => {
        const paid = payments.filter((p) => p.statementId === s.id).reduce((a, p) => a + p.amount, 0);
        const remaining = s.finalAmount - paid;
        return { s, paid, remaining, contract: contracts.find((c) => c.id === s.contractId) };
      })
      .filter((r) => r.remaining > 0 && r.s.status !== "پیش‌نویس")
      .sort((a, b) => b.remaining - a.remaining);
  }, [statements, payments, contracts]);

  const totalRemaining = rows.reduce((a, r) => a + r.remaining, 0);
  const overdue = rows.filter((r) => r.s.status === "تأیید شده").reduce((a, r) => a + r.remaining, 0);

  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="anim-fade-up">
      <PageHeader title="مطالبات" subtitle="مبالغ قابل دریافت از کارفرمایان بر اساس صورت‌وضعیت‌های تأییدشده" />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <StatCard label="کل مطالبات" value={totalRemaining} format={formatRialCompact} icon={<HandCoins className="w-5 h-5" />} tooltip="مجموع مانده صورت‌وضعیت‌ها" />
        <StatCard label="در انتظار پرداخت (تأییدشده)" value={overdue} format={formatRialCompact} icon={<HandCoins className="w-5 h-5" />} iconFrom="oklch(0.58 0.19 27)" iconTo="oklch(0.48 0.17 30)" />
        <StatCard label="تعداد اقلام باز" value={rows.length} format={(n) => toFaDigits(Math.round(n))} icon={<FileText className="w-5 h-5" />} iconFrom="oklch(0.72 0.14 78)" iconTo="oklch(0.6 0.13 70)" />
      </div>

      <Card>
        <CardHeader><CardTitle>اقلام مطالبات</CardTitle></CardHeader>
        <CardContent>
          {loading ? <LoadingBlock /> : rows.length === 0 ? (
            <EmptyState title="مطلباتی وجود ندارد" description="همه صورت‌وضعیت‌ها تسویه شده‌اند." />
          ) : (
            <TableWrap className="border-0">
              <THead>
                <TH>صورت‌وضعیت</TH>
                <TH>قرارداد</TH>
                <TH>کارفرما</TH>
                <TH>تاریخ</TH>
                <TH>مبلغ نهایی</TH>
                <TH>دریافتی</TH>
                <TH>مانده</TH>
                <TH>وضعیت</TH>
              </THead>
              <TBody>
                {rows.map(({ s, paid, remaining, contract }) => (
                  <TR key={s.id} onClick={() => navigate(`/contracts/${s.contractId}/statements`)}>
                    <TD><span className="nums text-[12.5px] font-extrabold text-primary">{toFaDigits(s.code)}</span></TD>
                    <TD><span className="nums text-[11.5px]">{toFaDigits(contract?.code ?? "—")}</span></TD>
                    <TD className="text-[12px] max-w-44"><p className="truncate">{employers?.find((e) => e.id === contract?.employerId)?.shortName ?? "—"}</p></TD>
                    <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(s.date)}</TD>
                    <TD className="nums text-[12px] whitespace-nowrap">{formatRialCompact(s.finalAmount)}</TD>
                    <TD className="nums text-[12px] text-emerald-500 whitespace-nowrap">{formatRialCompact(paid)}</TD>
                    <TD className="nums text-[12.5px] font-extrabold text-red-500 whitespace-nowrap">{formatRialCompact(remaining)}</TD>
                    <TD><StatementStatusBadge status={s.status} /></TD>
                  </TR>
                ))}
              </TBody>
            </TableWrap>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
