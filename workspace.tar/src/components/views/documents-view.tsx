"use client";

import { useMemo, useState } from "react";
import { FolderOpen, FileUp, FolderKanban } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Button } from "@/components/kit/button";
import { SearchInput, Select } from "@/components/kit/form";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { documentService, contractService } from "@/services";
import { DocumentCards } from "@/components/views/contract/documents-tab";
import { toFaDigits } from "@/lib/jalali";
import type { DocKind } from "@/types";

/* ═══════ مدیریت اسناد — نمای سراسری ═══════ */

const KINDS: (DocKind | "همه")[] = ["همه", "قرارداد اصلی", "الحاقیه", "پیوست فنی", "صورتجلسه", "لیست اقلام", "گزارش فنی", "مکاتبات", "سایر"];

export function DocumentsView() {
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("همه");
  const [contractId, setContractId] = useState("");
  const { data: docs, loading, error, reload } = useAsync(() => documentService.list(), []);
  const { data: contracts } = useAsync(() => contractService.list(), []);

  const filtered = useMemo(() => {
    let list = [...(docs || [])];
    if (q.trim()) {
      const lc = q.trim().toLowerCase();
      list = list.filter((d) => d.name.toLowerCase().includes(lc) || d.uploader.includes(lc));
    }
    if (kind !== "همه") list = list.filter((d) => d.kind === kind);
    if (contractId) list = list.filter((d) => d.contractId === contractId);
    list.sort((a, b) => (a.date < b.date ? 1 : -1));
    return list;
  }, [docs, q, kind, contractId]);

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="اسناد و مدارک"
        subtitle={`${toFaDigits(filtered.length)} سند در سامانه`}
        actions={
          <Button onClick={() => toast.success("سند جدید بارگذاری شد")}>
            <FileUp className="w-4 h-4" />
            بارگذاری سند
          </Button>
        }
      />

      <div className="rounded-xl border border-border bg-card e1 p-4 mb-4 flex gap-2 flex-wrap items-center blueprint-grid">
        <SearchInput placeholder="جستجوی نام سند یا بارگذاری‌کننده..." value={q} onChange={(e) => setQ(e.target.value)} className="flex-1 min-w-52" />
        <Select value={kind} onChange={(e) => setKind(e.target.value)} className="w-40">
          {KINDS.map((k) => (
            <option key={k} value={k}>{k}</option>
          ))}
        </Select>
        <Select value={contractId} onChange={(e) => setContractId(e.target.value)} className="w-52">
          <option value="">همه قراردادها</option>
          {contracts?.map((c) => (
            <option key={c.id} value={c.id}>{c.code} — {c.title.slice(0, 30)}</option>
          ))}
        </Select>
      </div>

      {error ? (
        <ErrorState onRetry={reload} />
      ) : loading ? (
        <LoadingBlock />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="سندی یافت نشد"
          description="با فیلترهای فعلی سندی یافت نشد."
          icon={<FolderKanban className="w-9 h-9" />}
        />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle><FolderOpen className="w-4 h-4 text-primary" /> فهرست اسناد</CardTitle>
          </CardHeader>
          <CardContent>
            <DocumentCards docs={filtered} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
