"use client";

import { useMemo, useState } from "react";
import { ShoppingCart, Wrench, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD, Pagination } from "@/components/kit/table";
import { PurchaseStatusBadge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { SearchInput, Select } from "@/components/kit/form";
import { StatCard } from "@/components/kit/stat-card";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { purchaseService, contractService, appendixService } from "@/services";
import { formatRialCompact, formatRial, formatNumber } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import type { Purchase } from "@/types";

/* ═══════ خرید و ساخت — نمای سراسری ═══════ */

export function usePurchaseData() {
  const { data: purchases, loading, error, reload } = useAsync(() => purchaseService.list(), []);
  const { data: contracts } = useAsync(() => contractService.list(), []);
  const { data: appendices } = useAsync(async () => {
    const cs = await contractService.list();
    const out: Record<string, Awaited<ReturnType<typeof appendixService.getByContract>>> = {};
    await Promise.all(cs.map(async (c) => (out[c.id] = await appendixService.getByContract(c.id))));
    return out;
  }, []);
  return { purchases: purchases || [], loading, error, reload, contracts: contracts || [], appendices };
}

export function itemTitle(appendices: Record<string, { items: { id: string; title: string; code: string }[] } | undefined>, contractId: string, itemId?: string) {
  if (!itemId) return undefined;
  return appendices[contractId]?.items.find((i) => i.id === itemId);
}

export function PurchasesView() {
  const { navigate } = useRouter();
  const { purchases, loading, error, reload, contracts, appendices } = usePurchaseData();
  const [q, setQ] = useState("");
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const filtered = useMemo(() => {
    let list = [...purchases];
    if (q.trim()) {
      const lc = q.trim().toLowerCase();
      list = list.filter((p) => p.code.toLowerCase().includes(lc) || p.description.includes(lc) || p.supplier.includes(lc));
    }
    if (type) list = list.filter((p) => p.type === type);
    if (status) list = list.filter((p) => p.status === status);
    list.sort((a, b) => (a.date < b.date ? 1 : -1));
    return list;
  }, [purchases, q, type, status]);

  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);
  const contractCode = (id: string) => contracts.find((c) => c.id === id)?.code ?? "—";
  const totals = useMemo(() => {
    const buy = purchases.filter((p) => p.type === "خرید" && p.status !== "لغو شده").reduce((a, p) => a + p.quantity * p.unitPrice, 0);
    const make = purchases.filter((p) => p.type === "ساخت" && p.status !== "لغو شده").reduce((a, p) => a + p.quantity * p.unitPrice, 0);
    return { buy, make, all: buy + make };
  }, [purchases]);

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="خرید و ساخت"
        subtitle="مدیریت سفارش‌های خرید و ساخت تمام قراردادها"
        actions={
          <Button variant="outline" onClick={() => toast.success("گزارش خرید و ساخت صادر شد")}>
            <FileSpreadsheet className="w-4 h-4" />
            خروجی
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <StatCard label="مجموع سفارش‌های خرید" value={totals.buy} format={formatRialCompact} tooltip="ارزش همه سفارش‌های خرید"
          icon={<ShoppingCart className="w-5 h-5" />} iconFrom="oklch(0.55 0.1 235)" iconTo="oklch(0.45 0.09 240)" />
        <StatCard label="مجموع سفارش‌های ساخت" value={totals.make} format={formatRialCompact} tooltip="ارزش همه سفارش‌های ساخت داخلی"
          icon={<Wrench className="w-5 h-5" />} iconFrom="oklch(0.72 0.14 78)" iconTo="oklch(0.6 0.13 70)" />
        <StatCard label="جمع کل خرید و ساخت" value={totals.all} format={formatRialCompact} tooltip="ارزش کل سفارش‌های فعال"
          icon={<ShoppingCart className="w-5 h-5" />} iconFrom="oklch(0.62 0.13 158)" iconTo="oklch(0.5 0.12 162)" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>فهرست سفارش‌ها</CardTitle>
          <div className="flex gap-2 flex-wrap">
            <SearchInput placeholder="جستجو..." value={q} onChange={(e) => setQ(e.target.value)} className="w-52" />
            <Select value={type} onChange={(e) => setType(e.target.value)} className="w-32">
              <option value="">همه انواع</option>
              <option value="خرید">خرید</option>
              <option value="ساخت">ساخت</option>
            </Select>
            <Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-36">
              <option value="">همه وضعیت‌ها</option>
              <option>ثبت‌شده</option>
              <option>در حال تأمین</option>
              <option>تحویل‌شده</option>
              <option>لغو شده</option>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {error ? (
            <ErrorState onRetry={reload} />
          ) : loading ? (
            <LoadingBlock />
          ) : paged.length === 0 ? (
            <EmptyState title="سفارشی یافت نشد" description="با فیلترهای فعلی سفارشی یافت نشد." icon={<ShoppingCart className="w-9 h-9" />} />
          ) : (
            <>
              <TableWrap className="border-0">
                <THead>
                  <TH>کد</TH>
                  <TH>نوع</TH>
                  <TH>قرارداد</TH>
                  <TH className="min-w-56">شرح</TH>
                  <TH>تأمین‌کننده</TH>
                  <TH>قلم پیوست فنی</TH>
                  <TH>تعداد</TH>
                  <TH>جمع</TH>
                  <TH>تاریخ</TH>
                  <TH>وضعیت</TH>
                </THead>
                <TBody>
                  {paged.map((p: Purchase) => {
                    const it = itemTitle(appendices, p.contractId, p.itemId);
                    return (
                      <TR key={p.id} onClick={() => navigate(`/contracts/${p.contractId}/purchases`)}>
                        <TD><span className="nums text-[12px] font-bold text-primary">{toFaDigits(p.code)}</span></TD>
                        <TD>
                          {p.type === "خرید" ? (
                            <span className="text-[11.5px] font-medium text-sky-500">خرید</span>
                          ) : (
                            <span className="text-[11.5px] font-medium text-amber-500">ساخت</span>
                          )}
                        </TD>
                        <TD><span className="nums text-[11.5px]">{toFaDigits(contractCode(p.contractId))}</span></TD>
                        <TD className="text-[12px] max-w-64"><p className="truncate">{p.description}</p></TD>
                        <TD className="text-[12px] whitespace-nowrap">{p.supplier}</TD>
                        <TD className="text-[11px] max-w-36">
                          {it ? (
                            <>
                              <span className="nums font-bold text-violet-500">{toFaDigits(it.code)}</span>
                              <span className="block truncate text-muted-foreground">{it.title}</span>
                            </>
                          ) : "—"}
                        </TD>
                        <TD className="nums text-[12px] whitespace-nowrap">{toFaDigits(formatNumber(p.quantity))} {p.unit}</TD>
                        <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRialCompact(p.quantity * p.unitPrice)}</TD>
                        <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(p.date)}</TD>
                        <TD><PurchaseStatusBadge status={p.status} /></TD>
                      </TR>
                    );
                  })}
                </TBody>
              </TableWrap>
              <Pagination page={page} pageSize={pageSize} total={filtered.length} onPage={setPage} />
              <p className="text-[11px] text-muted-foreground mt-2">
                جمع مبلغ فیلترشده: <b className="nums text-foreground">{formatRial(filtered.reduce((a, p) => a + p.quantity * p.unitPrice, 0))}</b>
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
