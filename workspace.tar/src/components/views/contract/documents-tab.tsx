"use client";

import { FolderOpen, Download, FileText, FileSpreadsheet, File as FileIcon, FileImage, DraftingCompass, History } from "lucide-react";
import { toast } from "sonner";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Badge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { documentService, activityService } from "@/services";
import { formatFileSize, formatRial, formatRialCompact } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";
import type { DocKind } from "@/types";

/* ═══════ اسناد و مدارک قرارداد — کارت فایل ═══════ */

const FILE_META: Record<string, { icon: React.ReactNode; color: string }> = {
  pdf: { icon: <FileText className="w-6 h-6" />, color: "bg-red-500/12 text-red-500" },
  xlsx: { icon: <FileSpreadsheet className="w-6 h-6" />, color: "bg-emerald-500/12 text-emerald-500" },
  docx: { icon: <FileIcon className="w-6 h-6" />, color: "bg-sky-500/12 text-sky-500" },
  dwg: { icon: <DraftingCompass className="w-6 h-6" />, color: "bg-violet-500/12 text-violet-500" },
  img: { icon: <FileImage className="w-6 h-6" />, color: "bg-amber-500/12 text-amber-500" },
};

const KIND_COLORS: Record<DocKind, string> = {
  "قرارداد اصلی": "teal",
  "الحاقیه": "amber",
  "پیوست فنی": "violet",
  "صورتجلسه": "blue",
  "لیست اقلام": "green",
  "گزارش فنی": "orange",
  "مکاتبات": "gray",
  "سایر": "gray",
};

export function DocumentCards({ docs }: { docs: NonNullable<Awaited<ReturnType<typeof documentService.list>>> }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
      {docs.map((d, i) => {
        const meta = FILE_META[d.fileType] ?? FILE_META.pdf;
        return (
          <div
            key={d.id}
            className="group rounded-xl border border-border bg-card card-3d card-3d-hover p-4 flex items-start gap-3 anim-fade-up"
            style={{ animationDelay: `${i * 30}ms` }}
          >
            <span className={cn("grid place-items-center w-12 h-12 rounded-xl shrink-0 e1", meta.color)}>{meta.icon}</span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-[13px] font-semibold truncate group-hover:text-primary transition-colors" title={d.name}>{d.name}</p>
                <Badge color={KIND_COLORS[d.kind] as "teal"} dot={false}>{d.kind}</Badge>
              </div>
              <div className="flex items-center gap-3 mt-1.5 flex-wrap text-[10.5px] text-muted-foreground nums">
                <span>نسخه {toFaDigits(d.version)}</span>
                <span>{formatJalali(d.date)}</span>
                <span>{formatFileSize(d.sizeKb * 1024)}</span>
              </div>
              <p className="text-[10.5px] text-muted-foreground mt-0.5">بارگذاری: {d.uploader}</p>
            </div>
            <Button size="icon" variant="ghost" aria-label="دانلود" onClick={() => toast.info(`در حال دانلود ${d.name}`)}>
              <Download className="w-4 h-4" />
            </Button>
          </div>
        );
      })}
    </div>
  );
}

export function DocumentsTab({ contractId }: { contractId: string }) {
  const { data: docs, loading, error, reload } = useAsync(() => documentService.byContract(contractId), [contractId]);

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <Card className="anim-fade-up">
      <CardHeader>
        <div>
          <CardTitle><FolderOpen className="w-4 h-4 text-primary" /> اسناد و مدارک قرارداد</CardTitle>
          <p className="text-[11px] text-muted-foreground mt-0.5">{toFaDigits(docs?.length ?? 0)} سند</p>
        </div>
        <Button size="sm" variant="outline" onClick={() => toast.success("سند جدید بارگذاری شد")}>
          بارگذاری سند
        </Button>
      </CardHeader>
      <CardContent>
        {(docs || []).length === 0 ? (
          <EmptyState title="سندی بارگذاری نشده است" icon={<FolderOpen className="w-9 h-9" />} />
        ) : (
          <DocumentCards docs={docs!} />
        )}
      </CardContent>
    </Card>
  );
}

/* ═══════ الحاقیه‌های قرارداد ═══════ */

interface AmendmentLike {
  id: string;
  code: string;
  contractId: string;
  date: string;
  description: string;
  amountChange: number;
  durationChangeDays: number;
  status: string;
  fileName?: string;
}

export function AmendmentsTab({
  contract,
  amendments,
}: {
  contract: { amountRial: number };
  amendments: AmendmentLike[];
}) {
  const increase = amendments.filter((a) => a.amountChange > 0).reduce((a, x) => a + x.amountChange, 0);
  const decrease = amendments.filter((a) => a.amountChange < 0).reduce((a, x) => a + x.amountChange, 0);
  const current = contract.amountRial + increase + decrease;

  return (
    <div className="space-y-4 anim-fade-up">
      <Card>
        <CardHeader><CardTitle>تأثیر الحاقیه‌ها بر مبلغ قرارداد</CardTitle></CardHeader>
        <CardContent>
          <div className="flex items-center justify-center gap-4 flex-wrap text-center">
            <AmountBox label="مبلغ اولیه قرارداد" value={contract.amountRial} tone="bg-card border-border" />
            <span className="text-2xl font-bold text-muted-foreground">+</span>
            <AmountBox label="مجموع افزایش‌ها" value={increase} tone="bg-emerald-500/8 border-emerald-500/25" valueClass="text-emerald-500" />
            <span className="text-2xl font-bold text-muted-foreground">−</span>
            <AmountBox label="مجموع کاهش‌ها" value={Math.abs(decrease)} tone="bg-red-500/8 border-red-500/25" valueClass="text-red-500" />
            <span className="text-2xl font-bold text-muted-foreground">=</span>
            <AmountBox label="مبلغ فعلی قرارداد" value={current} tone="bg-primary/8 border-primary/30" valueClass="text-primary" highlight />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle><History className="w-4 h-4 text-primary" /> فهرست الحاقیه‌ها</CardTitle>
          <p className="text-[11px] text-muted-foreground">{toFaDigits(amendments.length)} الحاقیه</p>
        </CardHeader>
        <CardContent>
          {amendments.length === 0 ? (
            <EmptyState title="الحاقیه‌ای ثبت نشده است" description="تغییرات قرارداد شامل افزایش/کاهش مبلغ و مدت در این بخش ثبت می‌شود." />
          ) : (
            <div className="space-y-2.5">
              {amendments.map((a) => (
                <div key={a.id} className="rounded-xl border border-border bg-card p-4 flex items-start gap-3 flex-wrap">
                  <span className="grid place-items-center w-10 h-10 rounded-xl bg-primary/10 text-primary text-[11px] font-bold shrink-0 nums">
                    {a.code.replace("الحاقیه ", "")}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-[13px] font-bold">{a.code}</p>
                      <Badge color={a.status === "تأیید شده" ? "green" : "amber"} dot={false}>{a.status}</Badge>
                    </div>
                    <p className="text-[12px] text-muted-foreground mt-1 leading-6">{a.description}</p>
                    <div className="flex items-center gap-4 mt-1.5 flex-wrap text-[11px] nums text-muted-foreground">
                      <span>تاریخ: {formatJalali(a.date)}</span>
                      {a.durationChangeDays !== 0 && (
                        <span>تغییر مدت: <b className={a.durationChangeDays > 0 ? "text-emerald-500" : "text-red-500"}>{a.durationChangeDays > 0 ? "+" : "−"}{toFaDigits(Math.abs(a.durationChangeDays))} روز</b></span>
                      )}
                      {a.fileName && <span>فایل: {a.fileName}</span>}
                    </div>
                  </div>
                  <div className="text-end shrink-0">
                    <p className="text-[10.5px] text-muted-foreground">تأثیر مبلغ</p>
                    <p className={`nums text-[14px] font-extrabold ${a.amountChange >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                      {a.amountChange >= 0 ? "+" : "−"}{formatRialCompact(Math.abs(a.amountChange))}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AmountBox({ label, value, tone, valueClass, highlight }: { label: string; value: number; tone: string; valueClass?: string; highlight?: boolean }) {
  return (
    <div className={cn("rounded-xl border px-5 py-3.5 min-w-44", tone, highlight && "e2")}>
      <p className="text-[10.5px] text-muted-foreground">{label}</p>
      <p className={cn("nums text-[15px] font-extrabold mt-1", valueClass)}>{formatRialCompact(value)}</p>
    </div>
  );
}

/* ═══════ تاریخچه فعالیت قرارداد ═══════ */

export function ActivityTab({ contractId }: { contractId: string }) {
  const { data: activities, loading, error, reload } = useAsync(() => activityService.byContract(contractId), [contractId]);

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;

  const sorted = (activities || []).slice().sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <Card className="anim-fade-up">
      <CardHeader>
        <CardTitle><History className="w-4 h-4 text-primary" /> تایم‌لاین کامل قرارداد</CardTitle>
        <p className="text-[11px] text-muted-foreground">{toFaDigits(sorted.length)} رویداد ثبت‌شده</p>
      </CardHeader>
      <CardContent>
        {sorted.length === 0 ? (
          <EmptyState title="فعالیتی ثبت نشده است" />
        ) : (
          <div className="space-y-0">
            {sorted.map((a, i) => (
              <div key={a.id} className="relative flex gap-4 pb-6">
                {i < sorted.length - 1 && <span className="absolute start-[15px] top-9 bottom-0 w-px bg-border" />}
                <span className="grid place-items-center w-8 h-8 rounded-full border border-border bg-secondary/60 text-primary shrink-0 z-10">
                  <span className="w-2 h-2 rounded-full bg-primary" />
                </span>
                <div className="min-w-0 flex-1 rounded-xl border border-border bg-card px-4 py-3">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <p className="text-[13px] font-bold">{a.title}</p>
                    <span className="nums text-[11px] text-muted-foreground">{formatJalali(a.date)}</span>
                  </div>
                  <p className="text-[11.5px] text-muted-foreground mt-1 leading-6">{a.description}</p>
                  <p className="text-[10.5px] text-muted-foreground/70 mt-1">توسط {a.user}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
