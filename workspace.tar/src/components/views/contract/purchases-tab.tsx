"use client";

import { Plus, ShoppingCart, Wrench } from "lucide-react";
import { toast } from "sonner";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD } from "@/components/kit/table";
import { PurchaseStatusBadge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { purchaseService, appendixService } from "@/services";
import { formatRialCompact, formatNumber } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";

/* ═══════ خرید و ساخت قرارداد — اتصال به اقلام پیوست فنی ═══════ */

export function PurchasesTab({ contractId }: { contractId: string }) {
  const { data: purchases, loading, error, reload } = useAsync(() => purchaseService.byContract(contractId), [contractId]);
  const { data: appendix } = useAsync(() => appendixService.getByContract(contractId), [contractId]);

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;

  const itemName = (id?: string) => (id ? appendix?.items.find((i) => i.id === id)?.title : undefined);
  const itemCode = (id?: string) => (id ? appendix?.items.find((i) => i.id === id)?.code : undefined);
  const total = (purchases || []).filter((p) => p.status !== "لغو شده").reduce((a, p) => a + p.quantity * p.unitPrice, 0);

  return (
    <div className="space-y-4 anim-fade-up">
      <Card>
        <CardHeader>
          <div>
            <CardTitle><ShoppingCart className="w-4 h-4 text-primary" /> سفارش‌های خرید و ساخت</CardTitle>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              جمع کل: <b className="nums text-foreground">{formatRialCompact(total)}</b> — {toFaDigits(purchases?.length ?? 0)} سفارش
            </p>
          </div>
          <Button size="sm" onClick={() => toast.success("فرم ثبت سفارش جدید باز شد — سفارش نمونه ثبت گردید")}>
            <Plus className="w-4 h-4" />
            سفارش جدید
          </Button>
        </CardHeader>
        <CardContent>
          {(purchases || []).length === 0 ? (
            <EmptyState title="سفارشی ثبت نشده است" description="برای این قرارداد هنوز خرید یا ساخت‌سازی ثبت نشده است." icon={<ShoppingCart className="w-9 h-9" />} />
          ) : (
            <TableWrap className="border-0">
              <THead>
                <TH>کد</TH>
                <TH>نوع</TH>
                <TH className="min-w-56">شرح</TH>
                <TH>تأمین‌کننده</TH>
                <TH>قلم پیوست فنی</TH>
                <TH>فی واحد</TH>
                <TH>تعداد</TH>
                <TH>جمع</TH>
                <TH>تاریخ</TH>
                <TH>وضعیت</TH>
              </THead>
              <TBody>
                {purchases!.map((p) => (
                  <TR key={p.id}>
                    <TD><span className="nums text-[12px] font-bold text-primary">{toFaDigits(p.code)}</span></TD>
                    <TD>
                      {p.type === "خرید" ? (
                        <span className="inline-flex items-center gap-1 text-[11.5px] font-medium text-sky-500"><ShoppingCart className="w-3.5 h-3.5" />خرید</span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11.5px] font-medium text-amber-500"><Wrench className="w-3.5 h-3.5" />ساخت</span>
                      )}
                    </TD>
                    <TD className="text-[12px] max-w-72"><p className="truncate">{p.description}</p></TD>
                    <TD className="text-[12px] whitespace-nowrap">{p.supplier}</TD>
                    <TD className="text-[11.5px] max-w-40">
                      {p.itemId ? (
                        <span title={itemName(p.itemId)}>
                          <span className="nums font-bold text-violet-500">{toFaDigits(itemCode(p.itemId) || "")}</span>
                          <span className="block truncate text-muted-foreground">{itemName(p.itemId)}</span>
                        </span>
                      ) : "—"}
                    </TD>
                    <TD className="nums text-[12px] whitespace-nowrap">{formatRialCompact(p.unitPrice)}</TD>
                    <TD className="nums text-[12px] whitespace-nowrap">{toFaDigits(formatNumber(p.quantity))} {p.unit}</TD>
                    <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRialCompact(p.quantity * p.unitPrice)}</TD>
                    <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(p.date)}</TD>
                    <TD><PurchaseStatusBadge status={p.status} /></TD>
                  </TR>
                ))}
              </TBody>
            </TableWrap>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
