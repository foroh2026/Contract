"use client";

import { useMemo, useState } from "react";
import {
  ChevronDown, ChevronLeft, Paperclip, Layers, Boxes, FileUp, Eye,
  GitBranch, Calculator, PackageCheck, Loader2, Download,
  ShoppingCart as ShoppingCartIcon2, FileText as FileText2,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Button } from "@/components/kit/button";
import { Badge, ItemStatusBadge } from "@/components/kit/badge";
import { ProgressBar, CircularProgress, WeightBar } from "@/components/kit/progress";
import { Modal } from "@/components/kit/overlay";
import { LoadingBlock, ErrorState, EmptyState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { appendixService, documentService, paymentService, purchaseService, statementService } from "@/services";
import { weightedProgress, weightedPlan } from "@/lib/progress";
import { formatPercentInt, formatRialCompact, formatNumber } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";
import type { TechnicalItem } from "@/types";

/* ═══════════════════════════════════════════════════
   ماژول پیوست فنی قرارداد — هسته محاسبه پیشرفت

   پیشرفت کل = Σ (وزن هر قلم × درصد پیشرفت همان قلم)
   ═══════════════════════════════════════════════════ */

export function AppendixTab({ contractId }: { contractId: string }) {
  const { data: appendix, loading, error, reload } = useAsync(() => appendixService.getByContract(contractId), [contractId]);
  const { data: docs } = useAsync(() => documentService.byContract(contractId), [contractId]);
  const [selectedItem, setSelectedItem] = useState<TechnicalItem | null>(null);
  const [openChapters, setOpenChapters] = useState<Record<string, boolean>>({});
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({});

  const appendixDocs = useMemo(
    () => (docs || []).filter((d) => d.kind === "پیوست فنی").sort((a, b) => b.version - a.version),
    [docs]
  );

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState message="پیوست فنی یافت نشد" onRetry={reload} />;
  if (!appendix)
    return (
      <EmptyState
        title="پیوست فنی تعریف نشده است"
        description="برای این قرارداد هنوز ساختار اقلام و وزن‌های پیوست فنی ثبت نشده است."
        icon={<Paperclip className="w-9 h-9" />}
      />
    );

  const totalActual = weightedProgress(appendix.items);
  const totalPlan = weightedPlan(appendix.items);
  const totalWeight = Math.round(appendix.items.reduce((a, i) => a + i.weightPercent, 0) * 10) / 10;
  const totalAmount = appendix.items.reduce((a, i) => a + i.amount, 0);

  const toggleChapter = (id: string) => setOpenChapters((s) => ({ ...s, [id]: !s[id] }));
  const toggleGroup = (id: string) => setOpenGroups((s) => ({ ...s, [id]: !s[id] }));

  return (
    <div className="space-y-4 anim-fade-up">
      {/* خلاصه پیوست فنی */}
      <div className="grid lg:grid-cols-4 gap-4">
        <Card hover className="lg:col-span-1">
          <CardHeader><CardTitle><Calculator className="w-4 h-4 text-primary" /> محاسبه وزن‌دار</CardTitle></CardHeader>
          <CardContent className="flex flex-col items-center gap-3">
            <CircularProgress value={totalActual} size={140} sublabel="پیشرفت پیوست فنی" />
            <div className="w-full space-y-1.5 text-[12px]">
              <div className="flex justify-between">
                <span className="text-muted-foreground">برنامه‌ای وزن‌دار</span>
                <b className="nums text-sky-500">{formatPercentInt(totalPlan)}</b>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">جمع وزن اقلام</span>
                <b className={cn("nums", totalWeight === 100 ? "text-emerald-500" : "text-amber-500")}>{formatPercentInt(totalWeight)}</b>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">ارزش اقلام</span>
                <b className="nums">{formatRialCompact(totalAmount)}</b>
              </div>
            </div>
            <p className="text-[10.5px] text-muted-foreground text-center leading-5 bg-secondary/50 rounded-lg p-2 border border-border w-full">
              پیشرفت کل = Σ (وزن قلم × پیشرفت قلم)
            </p>
          </CardContent>
        </Card>

        <Card hover className="lg:col-span-3">
          <CardHeader>
            <div>
              <CardTitle><Paperclip className="w-4 h-4 text-primary" /> مستندات پیوست فنی</CardTitle>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                نسخه جاری: <b className="nums">۰{toFaDigits(appendix.version)}</b> — تاریخ بازنگری: <b className="nums">{formatJalali(appendix.revisionDate)}</b>
              </p>
            </div>
            <Button size="sm" variant="outline" onClick={() => toast.success("فایل پیوست فنی جدید بارگذاری شد (نسخه بعدی)")}>
              <FileUp className="w-4 h-4" />
              بارگذاری نسخه جدید
            </Button>
          </CardHeader>
          <CardContent>
            {appendixDocs.length === 0 ? (
              <p className="text-[12px] text-muted-foreground text-center py-4">فایلی برای پیوست فنی بارگذاری نشده است</p>
            ) : (
              <div className="space-y-2">
                {appendixDocs.map((d, i) => (
                  <div key={d.id} className={cn(
                    "flex items-center gap-3 rounded-xl border p-3",
                    i === 0 ? "border-primary/30 bg-primary/5" : "border-border"
                  )}>
                    <span className={cn(
                      "grid place-items-center w-9 h-9 rounded-lg shrink-0 font-bold text-[11px] nums",
                      i === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                    )}>
                      V{toFaDigits(d.version)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[12.5px] font-semibold truncate">{d.name}</p>
                      <p className="text-[10.5px] text-muted-foreground nums">
                        {formatJalali(d.date)} — {d.uploader} — {formatNumber(d.sizeKb)} کیلوبایت
                      </p>
                    </div>
                    {i === 0 && <Badge color="teal" dot={false}>نسخه جاری</Badge>}
                    <Button size="icon" variant="ghost" onClick={() => toast.info(`در حال دانلود ${d.name}`)} aria-label="دانلود">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            {/* نمایش فرمول */}
            <div className="mt-4 rounded-xl border border-dashed border-primary/40 bg-primary/5 p-3">
              <p className="text-[11.5px] font-bold text-primary mb-2 flex items-center gap-1.5">
                <GitBranch className="w-3.5 h-3.5" />
                نمونه محاسبه پیشرفت وزن‌دار (بزرگ‌ترین اقلام)
              </p>
              <div className="space-y-1">
                {appendix.items
                  .slice()
                  .sort((a, b) => b.weightPercent - a.weightPercent)
                  .slice(0, 3)
                  .map((it) => (
                    <div key={it.id} className="flex items-center justify-between text-[11.5px] nums">
                      <span className="text-muted-foreground">{it.title} — وزن {formatPercentInt(it.weightPercent)} × پیشرفت {formatPercentInt(it.progress)}</span>
                      <b className="text-foreground">= {formatNumber(Math.round(it.weightPercent * it.progress) / 100, 1)}٪</b>
                    </div>
                  ))}
                <div className="flex items-center justify-between text-[12px] nums border-t border-primary/20 pt-1.5 mt-1.5">
                  <span className="font-bold">پیشرفت کل پیوست فنی</span>
                  <b className="text-primary">{formatNumber(totalActual, 1)}٪</b>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ساختار درختی فصل → گروه → قلم */}
      <Card>
        <CardHeader>
          <div>
            <CardTitle><Layers className="w-4 h-4 text-primary" /> ساختار پیوست فنی</CardTitle>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {toFaDigits(appendix.chapters.length)} فصل، {toFaDigits(appendix.groups.length)} گروه، {toFaDigits(appendix.items.length)} قلم
            </p>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              const allOpen = appendix.chapters.every((c) => openChapters[c.id] !== false);
              const next: Record<string, boolean> = {};
              appendix.chapters.forEach((c) => (next[c.id] = !allOpen));
              appendix.groups.forEach((g) => (next[g.id] = !allOpen));
              setOpenChapters(next);
              setOpenGroups(next);
            }}
          >
            <Eye className="w-4 h-4" />
            باز/بستن همه
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          {appendix.chapters.map((ch) => {
            const chItems = appendix.items.filter((i) => i.chapterId === ch.id);
            const chProgress = weightedProgress(chItems);
            const chPlan = weightedPlan(chItems);
            const chWeight = Math.round(chItems.reduce((a, i) => a + i.weightPercent, 0) * 10) / 10;
            const open = openChapters[ch.id] ?? true;
            return (
              <div key={ch.id} className="rounded-xl border border-border overflow-hidden">
                {/* فصل */}
                <button
                  onClick={() => toggleChapter(ch.id)}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-secondary/50 hover:bg-secondary transition-colors text-start"
                >
                  <ChevronDown className={cn("w-4 h-4 text-muted-foreground transition-transform shrink-0", !open && "-rotate-90")} />
                  <span className="grid place-items-center w-8 h-8 rounded-lg bg-primary/12 text-primary shrink-0"><Layers className="w-4 h-4" /></span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <p className="text-[13.5px] font-bold">{ch.title}</p>
                      <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                        <span className="nums">وزن: {formatPercentInt(chWeight)}</span>
                        <span className="nums">{toFaDigits(chItems.length)} قلم</span>
                      </div>
                    </div>
                    <ProgressBar value={chProgress} plan={chPlan} size="sm" showLabel className="mt-1.5 max-w-md" />
                  </div>
                </button>

                {/* گروه‌ها */}
                {open && (
                  <div className="divide-y divide-border">
                    {appendix.groups.filter((g) => g.chapterId === ch.id).map((g) => {
                      const gItems = appendix.items.filter((i) => i.groupId === g.id);
                      const gProgress = weightedProgress(gItems);
                      const gOpen = openGroups[g.id] ?? true;
                      return (
                        <div key={g.id}>
                          <button
                            onClick={() => toggleGroup(g.id)}
                            className="w-full flex items-center gap-3 px-4 ps-10 py-2.5 hover:bg-secondary/40 transition-colors text-start"
                          >
                            <ChevronLeft className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform shrink-0", gOpen && "-rotate-90")} />
                            <span className="grid place-items-center w-7 h-7 rounded-lg bg-secondary text-muted-foreground shrink-0"><Boxes className="w-3.5 h-3.5" /></span>
                            <p className="text-[12.5px] font-semibold flex-1">{g.title}</p>
                            <div className="hidden sm:block w-40"><ProgressBar value={gProgress} size="sm" showLabel /></div>
                          </button>

                          {/* اقلام */}
                          {gOpen && (
                            <div className="ps-10 pe-4 pb-3 pt-1 space-y-2 bg-background/60">
                              {gItems.map((it) => (
                                <button
                                  key={it.id}
                                  onClick={() => setSelectedItem(it)}
                                  className="w-full flex items-center gap-3 rounded-lg border border-border bg-card px-3 py-2.5 hover:border-primary/40 hover:e2 transition-all text-start group"
                                >
                                  <span className="nums text-[10.5px] font-bold text-muted-foreground bg-secondary rounded px-1.5 py-0.5 shrink-0">
                                    {toFaDigits(it.code)}
                                  </span>
                                  <div className="min-w-0 flex-1">
                                    <div className="flex items-center justify-between gap-2 flex-wrap">
                                      <p className="text-[12.5px] font-semibold group-hover:text-primary transition-colors truncate">{it.title}</p>
                                      <ItemStatusBadge status={it.status} />
                                    </div>
                                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                                      <ProgressBar value={it.progress} plan={it.planPercent} size="sm" showLabel className="flex-1 min-w-32" />
                                      <span className="text-[10.5px] text-muted-foreground shrink-0">
                                        وزن: <b className="nums text-foreground">{formatPercentInt(it.weightPercent)}</b>
                                      </span>
                                      <span className="nums text-[10.5px] text-muted-foreground shrink-0">
                                        {toFaDigits(formatNumber(it.quantity))} {it.unit}
                                      </span>
                                    </div>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* جزئیات قلم — اتصال به خرید، صورت‌وضعیت و اسناد */}
      <ItemDetailModal item={selectedItem} onClose={() => setSelectedItem(null)} contractId={contractId} />
    </div>
  );
}

/* ═══════ جزئیات قلم و ارتباطات آن در کل سیستم ═══════ */

function ItemDetailModal({
  item, onClose, contractId,
}: {
  item: TechnicalItem | null;
  onClose: () => void;
  contractId: string;
}) {
  const { data: purchases } = useAsync(
    () => (item ? purchaseService.byContract(contractId) : Promise.resolve([])),
    [item?.id]
  );
  const { data: statements } = useAsync(
    () => (item ? statementService.byContract(contractId) : Promise.resolve([])),
    [item?.id]
  );
  const { data: logs } = useAsync(
    () => (item ? appendixService.itemLogs(item.id) : Promise.resolve([])),
    [item?.id]
  );
  const [loading] = useState(false);

  if (!item) return null;
  const itemPurchases = (purchases || []).filter((p) => p.itemId === item.id);
  const lastStatement = statements?.[0];
  const itemLogs = (logs || []).sort((a, b) => (a.date < b.date ? -1 : 1));

  return (
    <Modal
      open={!!item}
      onClose={onClose}
      title={`جزئیات قلم ${toFaDigits(item.code)}`}
      size="lg"
    >
      {loading ? (
        <div className="grid place-items-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : (
        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-[15px] font-bold">{item.title}</h3>
              <ItemStatusBadge status={item.status} />
              <Badge color="violet" dot={false}>{item.type}</Badge>
            </div>
            <p className="text-[12px] text-muted-foreground mt-1.5 leading-6">{item.description}</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <InfoCell label="تعداد" value={`${toFaDigits(formatNumber(item.quantity))} ${item.unit}`} />
            <InfoCell label="مبلغ" value={formatRialCompact(item.amount)} />
            <InfoCell label="وزن" value={formatPercentInt(item.weightPercent)} />
            <InfoCell label="بازه اجرا" value={`${formatJalali(item.startDate, "short")} — ${formatJalali(item.endDate, "short")}`} />
          </div>

          <div className="rounded-xl border border-border p-3.5 space-y-3">
            <div>
              <div className="flex justify-between text-[12px] mb-1">
                <span className="text-muted-foreground">پیشرفت واقعی</span>
                <b className="nums text-emerald-500">{formatNumber(item.progress, 0)}٪</b>
              </div>
              <ProgressBar value={item.progress} plan={item.planPercent} />
            </div>
            <p className="text-[11px] text-muted-foreground nums">
              سهم این قلم در پیشرفت کل: <b className="text-foreground">{formatNumber(Math.round(item.weightPercent * item.progress) / 100, 1)}٪</b>
              <span className="mx-1.5">|</span>
              سهم برنامه‌ای: <b className="text-foreground">{formatNumber(Math.round(item.weightPercent * item.planPercent) / 100, 1)}٪</b>
            </p>
          </div>

          {/* ارتباطات در کل سیستم */}
          <div className="grid sm:grid-cols-3 gap-2.5">
            <ConnectionCard
              icon={<ShoppingCartIcon />}
              title="خریدهای مرتبط"
              main={itemPurchases.length ? `${toFaDigits(itemPurchases.length)} سفارش` : "—"}
              sub={itemPurchases.length
                ? `${toFaDigits(formatNumber(itemPurchases.reduce((a, p) => a + p.quantity, 0)))} ${item.unit} — ${formatRialCompact(itemPurchases.reduce((a, p) => a + p.quantity * p.unitPrice, 0))}`
                : "سفارشی ثبت نشده"}
            />
            <ConnectionCard
              icon={<StatementIcon />}
              title="صورت‌وضعیت مرتبط"
              main={lastStatement ? toFaDigits(lastStatement.code) : "—"}
              sub={lastStatement ? formatRialCompact(lastStatement.finalAmount) : "مشمول صورت‌وضعیت نشده"}
            />
            <ConnectionCard
              icon={<PackageCheck className="w-4 h-4 text-primary" />}
              title="سابقه پیشرفت"
              main={`${toFaDigits(itemLogs.length)} ثبت`}
              sub={itemLogs.length ? `آخرین: ${formatJalali(itemLogs[itemLogs.length - 1].date, "short")}` : "سابقه‌ای وجود ندارد"}
            />
          </div>

          {/* تایم‌لاین پیشرفت قلم */}
          {itemLogs.length > 0 && (
            <div className="rounded-xl border border-border p-3.5">
              <p className="text-[12.5px] font-bold mb-3 flex items-center gap-1.5">
                <GitBranch className="w-3.5 h-3.5 text-primary" />
                تایم‌لاین پیشرفت قلم
              </p>
              <ol className="relative space-y-3 before:absolute before:start-[7px] before:top-2 before:bottom-2 before:w-px before:bg-border">
                {itemLogs.map((l) => (
                  <li key={l.id} className="flex items-start gap-3 ps-0.5">
                    <span className="relative z-10 mt-1 w-3.5 h-3.5 rounded-full border-2 border-primary bg-card shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="nums text-[11.5px] font-bold">{formatJalali(l.date)}</span>
                        <span className="nums text-[11.5px] font-extrabold text-emerald-500">
                          {toFaDigits(l.previous)}٪ ← {toFaDigits(l.current)}٪
                        </span>
                      </div>
                      <p className="text-[11px] text-muted-foreground">{l.description} — {l.user}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}

function InfoCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-secondary/50 border border-border px-3 py-2">
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className="nums text-[12px] font-bold mt-0.5">{value}</p>
    </div>
  );
}

function ConnectionCard({ icon, title, main, sub }: { icon: React.ReactNode; title: string; main: string; sub: string }) {
  return (
    <div className="rounded-xl border border-border p-3">
      <p className="text-[10.5px] text-muted-foreground flex items-center gap-1.5">{icon}{title}</p>
      <p className="nums text-[14px] font-extrabold mt-1">{main}</p>
      <p className="nums text-[10.5px] text-muted-foreground mt-0.5 truncate">{sub}</p>
    </div>
  );
}

const ShoppingCartIcon = () => <ShoppingCartIcon2 className="w-4 h-4 text-primary" />;
const StatementIcon = () => <FileText2 className="w-4 h-4 text-primary" />;
