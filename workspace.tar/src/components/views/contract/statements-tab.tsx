"use client";

import { FileText, Plus, Wallet } from "lucide-react";
import { toast } from "sonner";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { TableWrap, THead, TH, TBody, TR, TD } from "@/components/kit/table";
import { ProgressBar } from "@/components/kit/progress";
import { StatementStatusBadge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { statementService, paymentService } from "@/services";
import { formatRialCompact, formatRial } from "@/lib/format";
import { formatJalali, toFaDigits } from "@/lib/jalali";

/* ═══════ صورت‌وضعیت‌های قرارداد ═══════ */

export function StatementsTab({ contractId }: { contractId: string }) {
  const { data: statements, loading, error, reload } = useAsync(() => statementService.byContract(contractId), [contractId]);
  const { data: payments } = useAsync(() => paymentService.byContract(contractId), [contractId]);

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;

  const paidOf = (sid: string) => (payments || []).filter((p) => p.statementId === sid).reduce((a, p) => a + p.amount, 0);
  const grand = (statements || []).reduce((a, s) => a + s.finalAmount, 0);
  const grandPaid = (statements || []).reduce((a, s) => a + paidOf(s.id), 0);

  return (
    <div className="space-y-4 anim-fade-up">
      <Card>
        <CardHeader>
          <div>
            <CardTitle><FileText className="w-4 h-4 text-primary" /> صورت‌وضعیت‌ها</CardTitle>
            <p className="text-[11px] text-muted-foreground mt-0.5 nums">
              مجموع: {formatRialCompact(grand)} — دریافتی: {formatRialCompact(grandPaid)} — مانده: {formatRialCompact(Math.max(0, grand - grandPaid))}
            </p>
          </div>
          <Button size="sm" onClick={() => toast.success("صورت‌وضعیت جدید ثبت شد")}>
            <Plus className="w-4 h-4" />
            صورت‌وضعیت جدید
          </Button>
        </CardHeader>
        <CardContent>
          {(statements || []).length === 0 ? (
            <EmptyState title="صورت‌وضعیتی ثبت نشده است" description="پس از تأیید کارکرد، صورت‌وضعیت‌ها در این بخش نمایش داده می‌شوند." icon={<FileText className="w-9 h-9" />} />
          ) : (
            <TableWrap className="border-0">
              <THead>
                <TH>شماره</TH>
                <TH>تاریخ</TH>
                <TH className="min-w-56">شرح</TH>
                <TH>مبلغ ناخالص</TH>
                <TH>ارزش افزوده</TH>
                <TH>مبلغ نهایی</TH>
                <TH className="min-w-40">وضعیت پرداخت</TH>
                <TH>وضعیت</TH>
              </THead>
              <TBody>
                {statements!.map((s) => {
                  const paid = paidOf(s.id);
                  const pct = Math.min(100, (paid / Math.max(1, s.finalAmount)) * 100);
                  return (
                    <TR key={s.id}>
                      <TD><span className="nums text-[12.5px] font-extrabold text-primary">{toFaDigits(s.code)}</span></TD>
                      <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(s.date)}</TD>
                      <TD className="text-[11.5px] text-muted-foreground max-w-72"><p className="line-clamp-2">{s.description}</p></TD>
                      <TD className="nums text-[12px] whitespace-nowrap">{formatRialCompact(s.grossAmount)}</TD>
                      <TD className="nums text-[12px] whitespace-nowrap">{toFaDigits(s.vatPercent)}٪ — {formatRialCompact(s.finalAmount - s.grossAmount)}</TD>
                      <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRialCompact(s.finalAmount)}</TD>
                      <TD>
                        <ProgressBar value={pct} size="sm" showLabel />
                        <p className="nums text-[10px] text-muted-foreground mt-1">{formatRial(paid)} از {formatRial(s.finalAmount)}</p>
                      </TD>
                      <TD><StatementStatusBadge status={s.status} /></TD>
                    </TR>
                  );
                })}
              </TBody>
            </TableWrap>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ═══════ دریافتی‌های قرارداد ═══════ */

export function PaymentsTab({ contractId }: { contractId: string }) {
  const { data: payments, loading, error, reload } = useAsync(() => paymentService.byContract(contractId), [contractId]);
  const { data: statements } = useAsync(() => statementService.byContract(contractId), [contractId]);

  if (loading) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;

  const total = (payments || []).reduce((a, p) => a + p.amount, 0);
  const stCode = (sid?: string) => (sid ? statements?.find((s) => s.id === sid)?.code : undefined);

  return (
    <Card className="anim-fade-up">
      <CardHeader>
        <div>
          <CardTitle><Wallet className="w-4 h-4 text-primary" /> دریافتی‌های قرارداد</CardTitle>
          <p className="text-[11px] text-muted-foreground mt-0.5 nums">
            مجموع دریافت‌ها: <b className="text-foreground">{formatRial(total)}</b>
          </p>
        </div>
        <Button size="sm" onClick={() => toast.success("دریافت جدید ثبت شد")}>
          <Plus className="w-4 h-4" />
          ثبت دریافت
        </Button>
      </CardHeader>
      <CardContent>
        {(payments || []).length === 0 ? (
          <EmptyState title="دریافتی ثبت نشده است" icon={<Wallet className="w-9 h-9" />} />
        ) : (
          <TableWrap className="border-0">
            <THead>
              <TH>کد</TH>
              <TH>صورت‌وضعیت</TH>
              <TH>مبلغ</TH>
              <TH>تاریخ</TH>
              <TH>روش پرداخت</TH>
              <TH>شماره پیگیری</TH>
              <TH>شرح</TH>
            </THead>
            <TBody>
              {payments!.map((p) => (
                <TR key={p.id}>
                  <TD><span className="nums text-[12px] font-bold text-primary">{toFaDigits(p.code)}</span></TD>
                  <TD className="nums text-[12px]">{p.statementId ? toFaDigits(stCode(p.statementId) || "—") : <span className="text-muted-foreground">پیش‌پرداخت</span>}</TD>
                  <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRial(p.amount)}</TD>
                  <TD className="nums text-[12px] whitespace-nowrap">{formatJalali(p.date)}</TD>
                  <TD className="text-[12px] whitespace-nowrap">{p.method}</TD>
                  <TD className="nums text-[12px] text-muted-foreground">{toFaDigits(p.reference)}</TD>
                  <TD className="text-[11.5px] text-muted-foreground max-w-56"><p className="truncate">{p.description}</p></TD>
                </TR>
              ))}
            </TBody>
          </TableWrap>
        )}
      </CardContent>
    </Card>
  );
}
