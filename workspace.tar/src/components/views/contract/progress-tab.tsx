"use client";

import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Activity, Save, GitBranch, History, AlertTriangle, Loader2, Upload } from "lucide-react";
import { PageHeader } from "@/components/layout/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { Button } from "@/components/kit/button";
import { ProgressBar, CircularProgress } from "@/components/kit/progress";
import { ItemStatusBadge } from "@/components/kit/badge";
import { Field, Textarea } from "@/components/kit/form";
import { JalaliDatePicker } from "@/components/kit/date-picker";
import { Modal } from "@/components/kit/overlay";
import { LoadingBlock, ErrorState, EmptyState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { appendixService, contractService } from "@/services";
import { weightedProgress, weightedPlan, groupProgress } from "@/lib/progress";
import { formatPercentInt, formatSignedPercent } from "@/lib/format";
import { formatJalali, todayISO, toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";
import type { TechnicalItem } from "@/types";

/* ═══════════════════════════════════════════════════
   پیشرفت فیزیکی قرارداد — بر اساس اقلام پیوست فنی
   ═══════════════════════════════════════════════════ */

export function ProgressTab({ contractId }: { contractId: string }) {
  const { navigate } = useRouter();
  const { data: contract, loading: lc } = useAsync(() => contractService.get(contractId), [contractId]);
  const { data: appendix, loading, error, reload } = useAsync(() => appendixService.getByContract(contractId), [contractId]);
  const { data: logs } = useAsync(() => appendixService.allLogs(contractId), [contractId]);
  const [registerItem, setRegisterItem] = useState<TechnicalItem | null>(null);

  if (loading || lc) return <LoadingBlock />;
  if (error) return <ErrorState onRetry={reload} />;
  if (!appendix || !contract)
    return (
      <EmptyState
        title="پیوست فنی تعریف نشده است"
        description="برای این قرارداد هنوز ساختار اقلام و وزن‌های پیوست فنی ثبت نشده است. ابتدا پیوست فنی را تعریف کنید تا پیشرفت وزن‌دار قابل محاسبه باشد."
      />
    );

  const actual = weightedProgress(appendix.items);
  const plan = weightedPlan(appendix.items);
  const deviation = Math.round((actual - plan) * 10) / 10;

  return (
    <div className="space-y-4 anim-fade-up">
      {/* پیشرفت کل */}
      <Card className="overflow-hidden relative">
        <div className="absolute inset-0 hero-panel pointer-events-none" />
        <CardContent className="relative pt-5">
          <div className="flex items-center justify-between gap-6 flex-wrap">
            <div className="flex items-center gap-6 flex-wrap">
              <CircularProgress value={actual} size={150} sublabel="پیشرفت کل قرارداد" />
              <div className="space-y-3 min-w-56">
                <ProgressRow label="برنامه‌ای" value={plan} color="text-sky-500" bar="bg-sky-500" />
                <ProgressRow label="واقعی" value={actual} color="text-emerald-500" bar="bg-emerald-500" />
                <div className={cn(
                  "rounded-lg border px-3 py-2 flex items-center gap-2 text-[12.5px] font-bold nums",
                  deviation >= 0 ? "border-emerald-500/30 bg-emerald-500/8 text-emerald-600" : "border-red-500/30 bg-red-500/8 text-red-500"
                )}>
                  <AlertTriangle className="w-4 h-4" />
                  انحراف از برنامه: {formatSignedPercent(deviation, 1)}
                </div>
              </div>
            </div>
            <div className="text-[12px] text-muted-foreground leading-7 bg-card/70 border border-border rounded-xl px-4 py-3 e1 max-w-xs">
              <p className="font-bold text-foreground mb-1">روش محاسبه</p>
              پیشرفت هر قلم از ثبت‌های میدانی اعلام و با وزن تعریف‌شده در پیوست فنی ترکیب می‌شود:
              <span className="nums block mt-1 text-primary font-bold" dir="ltr">Σ(wᵢ × pᵢ)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* تفکیک بر اساس گروه‌ها */}
      <Card>
        <CardHeader>
          <CardTitle><GitBranch className="w-4 h-4 text-primary" /> تفکیک پیشرفت بر اساس گروه‌های پیوست فنی</CardTitle>
          <p className="text-[11px] text-muted-foreground">خط عمودی روی نوارها = مقدار برنامه‌ای</p>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-2 gap-x-6 gap-y-3.5">
          {appendix.groups.map((g) => {
            const items = appendix.items.filter((i) => i.groupId === g.id);
            const gp = groupProgress(items);
            const gplan = weightedPlan(items);
            return (
              <div key={g.id}>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <p className="text-[12.5px] font-semibold truncate">{g.title}</p>
                  <span className="nums text-[12px] font-extrabold text-primary shrink-0">{formatPercentInt(gp, 0)}</span>
                </div>
                <ProgressBar value={gp} plan={gplan} size="md" />
                <p className="text-[10px] text-muted-foreground mt-1 nums">{toFaDigits(items.length)} قلم</p>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* اقلام و ثبت پیشرفت */}
      <Card>
        <CardHeader>
          <CardTitle><Activity className="w-4 h-4 text-primary" /> ثبت پیشرفت اقلام</CardTitle>
          <p className="text-[11px] text-muted-foreground">برای ثبت پیشرفت جدید، روی قلم موردنظر کلیک کنید</p>
        </CardHeader>
        <CardContent className="space-y-2">
          {appendix.items
            .slice()
            .sort((a, b) => a.progress - b.progress)
            .map((it) => (
              <button
                key={it.id}
                onClick={() => setRegisterItem(it)}
                className="w-full flex items-center gap-3 rounded-xl border border-border bg-card px-3.5 py-3 hover:border-primary/40 hover:e2 transition-all text-start group"
              >
                <span className="nums text-[10.5px] font-bold text-muted-foreground bg-secondary rounded px-1.5 py-0.5 shrink-0">
                  {toFaDigits(it.code)}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2 flex-wrap mb-1">
                    <p className="text-[12.5px] font-semibold group-hover:text-primary transition-colors truncate">{it.title}</p>
                    <div className="flex items-center gap-2">
                      <span className={cn("nums text-[11px] font-bold", it.progress >= it.planPercent ? "text-emerald-500" : "text-red-500")}>
                        {formatSignedPercent(it.progress - it.planPercent, 0)}
                      </span>
                      <ItemStatusBadge status={it.status} />
                    </div>
                  </div>
                  <ProgressBar value={it.progress} plan={it.planPercent} size="sm" showLabel />
                </div>
              </button>
            ))}
        </CardContent>
      </Card>

      {/* سابقه ثبت‌های اخیر قرارداد */}
      <Card>
        <CardHeader><CardTitle><History className="w-4 h-4 text-primary" /> سابقه ثبت پیشرفت (کل قرارداد)</CardTitle></CardHeader>
        <CardContent>
          {logs && logs.length > 0 ? (
            <div className="overflow-y-auto max-h-96 rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead className="bg-secondary/60 border-b border-border sticky top-0">
                  <tr>
                    {["تاریخ", "قلم", "قبلی", "جدید", "شرح", "کاربر"].map((h) => (
                      <th key={h} className="px-3 py-2.5 text-start text-[11px] font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {logs.slice(0, 30).map((l) => {
                    const item = appendix.items.find((i) => i.id === l.itemId);
                    return (
                      <tr key={l.id} className="hover:bg-secondary/40 transition-colors">
                        <td className="nums px-3 py-2.5 text-[12px] whitespace-nowrap">{formatJalali(l.date)}</td>
                        <td className="px-3 py-2.5 text-[12px] max-w-48 truncate">{item?.title ?? "—"}</td>
                        <td className="nums px-3 py-2.5 text-[12px] text-muted-foreground">{toFaDigits(l.previous)}٪</td>
                        <td className="nums px-3 py-2.5 text-[12px] font-bold text-emerald-500">{toFaDigits(l.current)}٪</td>
                        <td className="px-3 py-2.5 text-[11.5px] text-muted-foreground max-w-56 truncate">{l.description}</td>
                        <td className="px-3 py-2.5 text-[11.5px] whitespace-nowrap">{l.user}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-[12px] text-muted-foreground text-center py-6">سابقه‌ای ثبت نشده است</p>
          )}
        </CardContent>
      </Card>

      {/* مودال ثبت پیشرفت */}
      <RegisterProgressModal
        item={registerItem}
        contractId={contractId}
        onClose={() => setRegisterItem(null)}
        onSaved={() => {
          reload();
          toast.success("پیشرفت قلم با موفقیت ثبت شد و پیشرفت کل بروزرسانی گردید");
          setRegisterItem(null);
        }}
      />
    </div>
  );
}

function ProgressRow({ label, value, color, bar }: { label: string; value: number; color: string; bar: string }) {
  return (
    <div>
      <div className="flex items-center justify-between text-[12.5px] mb-1">
        <span className="text-muted-foreground">{label}</span>
        <b className={cn("nums", color)}>{formatPercentInt(value, 0)}</b>
      </div>
      <div className="h-3 rounded-full bg-secondary overflow-hidden">
        <div className={cn("h-full rounded-full transition-[width] duration-1000", bar)} style={{ width: `${Math.min(100, value)}%` }} />
      </div>
    </div>
  );
}

/* ═══════ مودال ثبت پیشرفت قلم ═══════ */

function RegisterProgressModal({
  item, contractId, onClose, onSaved,
}: {
  item: TechnicalItem | null;
  contractId: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [progress, setProgress] = useState("");
  const [date, setDate] = useState(todayISO());
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  const current = item?.progress ?? 0;
  const newP = Math.max(0, Math.min(100, Number(progress) || 0));

  const save = async () => {
    if (!item) return;
    setSaving(true);
    try {
      await appendixService.updateItemProgress(item.id, newP, description);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={!!item}
      onClose={onClose}
      title="ثبت پیشرفت قلم"
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            ثبت پیشرفت
          </Button>
        </div>
      }
    >
      {item && (
        <div className="space-y-4">
          <div className="rounded-xl bg-secondary/50 border border-border p-3.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div>
                <p className="nums text-[10.5px] text-muted-foreground">{toFaDigits(item.code)}</p>
                <p className="text-[13.5px] font-bold">{item.title}</p>
              </div>
              <div className="text-end">
                <p className="text-[10.5px] text-muted-foreground">پیشرفت قبلی</p>
                <p className="nums text-lg font-extrabold text-emerald-500">{toFaDigits(current)}٪</p>
              </div>
            </div>
          </div>

          <Field label="پیشرفت جدید (٪)" required>
            <input
              type="range"
              min={0}
              max={100}
              value={newP}
              onChange={(e) => setProgress(e.target.value)}
              className="w-full accent-[oklch(0.52_0.09_200)]"
              aria-label="درصد پیشرفت جدید"
            />
            <div className="flex items-center gap-2 mt-2">
              <input
                type="number"
                min={0}
                max={100}
                value={progress}
                onChange={(e) => setProgress(e.target.value)}
                placeholder={`${current} — وارد کنید`}
                className="h-10 w-28 rounded-lg border border-input bg-card px-3 text-sm nums focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/20"
              />
              <span className="nums text-[13px] font-bold text-primary">{toFaDigits(newP)}٪</span>
              <span className="text-[11px] text-muted-foreground">افزایش نسبت به قبل: {toFaDigits(Math.max(0, newP - current))} واحد درصد</span>
            </div>
          </Field>

          <Field label="تاریخ ثبت" required>
            <JalaliDatePicker value={date} onChange={setDate} />
          </Field>

          <Field label="شرح عملیات">
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              placeholder="مثال: تکمیل مونتاژ و تأیید آزمون عملکرد..."
            />
          </Field>

          <button
            type="button"
            onClick={() => toast.success("فایل مستند پیشرفت بارگذاری شد")}
            className="w-full rounded-xl border-2 border-dashed border-border hover:border-primary/50 hover:bg-primary/5 transition-all px-4 py-5 text-center"
          >
            <Upload className="w-5 h-5 mx-auto text-muted-foreground" />
            <p className="text-[12px] font-medium mt-1.5">بارگذاری مستندات پیشرفت</p>
            <p className="text-[10.5px] text-muted-foreground">تصاویر، گزارش آزمون یا صورتجلسه</p>
          </button>
        </div>
      )}
    </Modal>
  );
}
