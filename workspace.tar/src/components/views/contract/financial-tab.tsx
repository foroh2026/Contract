"use client";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/kit/card";
import { formatRial, formatRialCompact } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";
import { cn } from "@/lib/utils";

function toFaNumSafe(n: number): string {
  return toFaDigits(n.toLocaleString("en-US").replace(/,/g, "\u066C"));
}

/* ═══════ تب مالی قرارداد ═══════ */

interface AmendmentLike {
  amountChange: number;
}
interface StatementLike {
  grossAmount: number;
  finalAmount: number;
}
interface PaymentLike {
  amount: number;
}

export function FinancialTab({
  contract, statements, payments, amendments,
}: {
  contract: { amountRial: number; prepaymentPercent: number; amountForeign?: number; currency?: string; exchangeRate?: number };
  statements: StatementLike[];
  payments: PaymentLike[];
  amendments: AmendmentLike[];
}) {
  const increase = amendments.filter((a) => a.amountChange > 0).reduce((a, x) => a + x.amountChange, 0);
  const decrease = amendments.filter((a) => a.amountChange < 0).reduce((a, x) => a + x.amountChange, 0);
  const currentAmount = contract.amountRial + increase + decrease;
  const gross = statements.reduce((a, s) => a + s.grossAmount, 0);
  const vat = statements.reduce((a, s) => a + (s.finalAmount - s.grossAmount), 0);
  const final = gross + vat;
  const paid = payments.reduce((a, p) => a + p.amount, 0);
  const prepayment = Math.round((currentAmount * contract.prepaymentPercent) / 100);

  const rows = [
    { label: "مبلغ فعلی قرارداد (با الحاقیه‌ها)", value: currentAmount, tone: "text-foreground" },
    { label: `پیش‌پرداخت (${toFaDigits(contract.prepaymentPercent)}٪)`, value: prepayment, tone: "text-muted-foreground" },
    { label: "مجموع صورت‌وضعیت‌ها (ناخالص)", value: gross, tone: "text-foreground" },
    { label: "ارزش افزوده", value: vat, tone: "text-muted-foreground" },
    { label: "مبلغ نهایی صورت‌وضعیت‌ها", value: final, tone: "text-amber-500" },
    { label: "مجموع دریافتی‌ها", value: paid, tone: "text-emerald-500" },
    { label: "مانده مطالبات", value: Math.max(0, final - paid), tone: "text-red-500" },
  ];

  const paidPct = Math.min(100, (paid / Math.max(1, final)) * 100);

  return (
    <div className="grid lg:grid-cols-3 gap-4 anim-fade-up">
      <Card className="lg:col-span-2">
        <CardHeader><CardTitle>تراز مالی قرارداد</CardTitle></CardHeader>
        <CardContent>
          <div className="rounded-xl border border-border overflow-hidden">
            {rows.map((r, i) => (
              <div
                key={r.label}
                className={cn(
                  "flex items-center justify-between gap-3 px-4 py-3",
                  i % 2 === 0 ? "bg-secondary/30" : "bg-card",
                  i === rows.length - 1 && "border-t-2 border-t-border"
                )}
              >
                <span className="text-[12.5px] text-muted-foreground">{r.label}</span>
                <b className={`nums text-[13.5px] ${r.tone}`}>{formatRial(r.value)}</b>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>پرداخت‌شده از مبلغ نهایی</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-2">
            <p className="nums text-3xl font-extrabold text-primary">{toFaDigits(Math.round(paidPct))}٪</p>
            <p className="text-[11px] text-muted-foreground mt-1">نسبت دریافتی به صورت‌وضعیت‌ها</p>
          </div>
          <div className="h-3.5 rounded-full bg-secondary overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-l from-emerald-500 to-primary transition-[width] duration-1000"
              style={{ width: `${paidPct}%` }}
            />
          </div>
          <div className="space-y-1.5 text-[12px] nums">
            <div className="flex justify-between">
              <span className="text-muted-foreground">پرداخت‌شده</span>
              <b className="text-emerald-500">{formatRialCompact(paid)}</b>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">مانده</span>
              <b className="text-red-500">{formatRialCompact(Math.max(0, final - paid))}</b>
            </div>
          </div>
          {contract.amountForeign && (
            <div className="rounded-lg bg-secondary/50 border border-border p-3 text-[11.5px] nums leading-6">
              بخش ارزی: <b>{toFaNumSafe(contract.amountForeign)} {contract.currency}</b>
              {contract.exchangeRate ? <> با نرخ <b>{toFaNumSafe(contract.exchangeRate)} ریال</b></> : null}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
