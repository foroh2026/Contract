"use client";

import { useMemo, useState } from "react";
import { Building2, Mail, Phone, MapPin, UserRound, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page-header";
import { Card } from "@/components/kit/card";
import { Badge } from "@/components/kit/badge";
import { Button } from "@/components/kit/button";
import { SearchInput } from "@/components/kit/form";
import { TableWrap, THead, TH, TBody, TR, TD } from "@/components/kit/table";
import { EmptyState, LoadingBlock, ErrorState } from "@/components/kit/feedback";
import { useAsync } from "@/hooks/useAsync";
import { useRouter } from "@/lib/router";
import { employerService, contractService } from "@/services";
import { formatRialCompact } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";

/* ═══════ کارفرمایان ═══════ */

export function EmployersView() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const { data: employers, loading, error, reload } = useAsync(() => employerService.list(), []);
  const { data: contracts } = useAsync(() => contractService.list(), []);

  const filtered = useMemo(() => {
    const list = employers || [];
    if (!q.trim()) return list;
    const lc = q.trim();
    return list.filter((e) => e.name.includes(lc) || e.shortName.includes(lc) || e.code.toLowerCase().includes(lc.toLowerCase()));
  }, [employers, q]);

  const stats = useMemo(() => {
    const map: Record<string, { count: number; total: number }> = {};
    (contracts || []).forEach((c) => {
      const m = map[c.employerId] || { count: 0, total: 0 };
      m.count++;
      m.total += c.amountRial;
      map[c.employerId] = m;
    });
    return map;
  }, [contracts]);

  return (
    <div className="anim-fade-up">
      <PageHeader
        title="کارفرمایان"
        subtitle={`${toFaDigits(filtered.length)} کارفرما ثبت‌شده`}
        actions={
          <Button variant="outline" onClick={() => toast.success("فهرست کارفرمایان صادر شد")}>
            <FileSpreadsheet className="w-4 h-4" />
            خروجی Excel
          </Button>
        }
      />

      <div className="mb-4 max-w-md">
        <SearchInput placeholder="جستجوی کارفرما..." value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {error ? (
        <ErrorState onRetry={reload} />
      ) : loading ? (
        <LoadingBlock />
      ) : filtered.length === 0 ? (
        <EmptyState title="کارفرمایی یافت نشد" />
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 mb-4">
            {filtered.slice(0, 6).map((e) => (
              <Card key={e.id} hover className="p-4">
                <div className="flex items-start gap-3">
                  <span className="grid place-items-center w-11 h-11 rounded-xl bg-primary/10 text-primary e1 shrink-0">
                    <Building2 className="w-5 h-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-[13.5px] font-bold truncate">{e.name}</p>
                      <Badge color={e.type === "دولتی" ? "teal" : e.type === "نیمه‌دولتی" ? "blue" : "gray"} dot={false}>{e.type}</Badge>
                    </div>
                    <p className="nums text-[10.5px] text-muted-foreground mt-0.5">{toFaDigits(e.code)} — شناسه ملی {toFaDigits(e.nationalId)}</p>
                    <div className="flex items-center gap-3 mt-2 flex-wrap text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1"><UserRound className="w-3.5 h-3.5" />{e.contactPerson}</span>
                      <span className="flex items-center gap-1 nums"><Phone className="w-3.5 h-3.5" />{toFaDigits(e.phone)}</span>
                      <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" />{e.email}</span>
                    </div>
                    <div className="flex items-center gap-4 mt-2.5 pt-2.5 border-t border-border nums text-[11.5px]">
                      <span>{toFaDigits(stats[e.id]?.count ?? 0)} قرارداد</span>
                      <span className="font-bold text-primary">{formatRialCompact(stats[e.id]?.total ?? 0)}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <TableWrap>
            <THead>
              <TH>کد</TH>
              <TH>نام سازمان</TH>
              <TH>نوع</TH>
              <TH>رابط کارفرما</TH>
              <TH>تلفن</TH>
              <TH>تعداد قرارداد</TH>
              <TH>حجم کل قراردادها</TH>
              <TH></TH>
            </THead>
            <TBody>
              {filtered.map((e) => (
                <TR key={e.id}>
                  <TD><span className="nums text-[12px] font-bold text-primary">{toFaDigits(e.code)}</span></TD>
                  <TD>
                    <p className="text-[13px] font-semibold">{e.name}</p>
                    <p className="text-[10.5px] text-muted-foreground flex items-center gap-1"><MapPin className="w-3 h-3" />{e.address}</p>
                  </TD>
                  <TD>
                    <Badge color={e.type === "دولتی" ? "teal" : e.type === "نیمه‌دولتی" ? "blue" : "gray"} dot={false}>{e.type}</Badge>
                  </TD>
                  <TD className="text-[12px] whitespace-nowrap">{e.contactPerson}</TD>
                  <TD className="nums text-[12px] whitespace-nowrap">{toFaDigits(e.phone)}</TD>
                  <TD className="nums text-[13px] font-bold">{toFaDigits(stats[e.id]?.count ?? 0)}</TD>
                  <TD className="nums text-[12px] font-bold whitespace-nowrap">{formatRialCompact(stats[e.id]?.total ?? 0)}</TD>
                  <TD>
                    <Button size="sm" variant="ghost" onClick={() => navigate("/contracts")}>قراردادها</Button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </TableWrap>
        </>
      )}
    </div>
  );
}
