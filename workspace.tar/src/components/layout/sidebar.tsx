"use client";

import { useMemo } from "react";
import {
  LayoutDashboard, FolderKanban, Building2, Paperclip, ShoppingCart,
  Activity, FileText, Wallet, HandCoins, FolderOpen, BarChart3,
  Bell, Users, Settings, ChevronDown, ShieldCheck, X, Gavel,
  ChevronsLeft, ChevronsRight, CircleDot,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useRouter, parseRoute } from "@/lib/router";
import { useUIStore } from "@/store/ui";
import { toFaDigits } from "@/lib/jalali";
import { useAsync } from "@/hooks/useAsync";
import { contractService } from "@/services";

/* ═══════ منوی کنار (Sidebar) — RTL، قابل جمع‌شدن ═══════ */

interface MenuItem {
  key: string;
  label: string;
  icon: React.ReactNode;
  route?: string;
  children?: { label: string; route: string; match?: (segs: string[], q: URLSearchParams) => boolean }[];
}

const MENU: MenuItem[] = [
  { key: "dashboard", label: "داشبورد", icon: <LayoutDashboard className="w-[18px] h-[18px]" />, route: "/dashboard" },
  {
    key: "contracts",
    label: "مدیریت قراردادها",
    icon: <FolderKanban className="w-[18px] h-[18px]" />,
    children: [
      { label: "همه قراردادها", route: "/contracts" },
      { label: "قراردادهای فعال", route: "/contracts?status=active" },
      { label: "نزدیک به پایان", route: "/contracts?status=near-end" },
      { label: "خاتمه‌یافته", route: "/contracts?status=terminated" },
    ],
  },
  { key: "employers", label: "کارفرمایان", icon: <Building2 className="w-[18px] h-[18px]" />, route: "/employers" },
  { key: "appendices", label: "پیوست‌های فنی", icon: <Paperclip className="w-[18px] h-[18px]" />, route: "/appendices" },
  { key: "purchases", label: "خرید و ساخت", icon: <ShoppingCart className="w-[18px] h-[18px]" />, route: "/purchases" },
  { key: "progress", label: "پیشرفت قرارداد", icon: <Activity className="w-[18px] h-[18px]" />, route: "/progress" },
  { key: "statements", label: "صورت‌وضعیت‌ها", icon: <FileText className="w-[18px] h-[18px]" />, route: "/statements" },
  { key: "payments", label: "دریافتی‌ها", icon: <Wallet className="w-[18px] h-[18px]" />, route: "/payments" },
  { key: "receivables", label: "مطالبات", icon: <HandCoins className="w-[18px] h-[18px]" />, route: "/receivables" },
  { key: "documents", label: "اسناد و مدارک", icon: <FolderOpen className="w-[18px] h-[18px]" />, route: "/documents" },
  { key: "reports", label: "گزارشات", icon: <BarChart3 className="w-[18px] h-[18px]" />, route: "/reports" },
  { key: "notifications", label: "اعلان‌ها", icon: <Bell className="w-[18px] h-[18px]" />, route: "/notifications" },
  {
    key: "users-group",
    label: "مدیریت کاربران",
    icon: <Users className="w-[18px] h-[18px]" />,
    children: [
      { label: "کاربران", route: "/users" },
      { label: "نقش‌ها و دسترسی‌ها", route: "/roles" },
    ],
  },
  { key: "settings", label: "تنظیمات", icon: <Settings className="w-[18px] h-[18px]" />, route: "/settings" },
];

export function Sidebar() {
  const { path, navigate } = useRouter();
  const { sidebarCollapsed, toggleSidebar, mobileSidebarOpen, setMobileSidebar } = useUIStore();
  const { data: contracts } = useAsync(() => contractService.list(), []);
  const { segments: segs, query } = parseRoute(path);

  const counts = useMemo(() => {
    const cs = contracts || [];
    return {
      contracts: cs.length,
      active: cs.filter((c) => c.status === "active").length,
      nearEnd: cs.filter((c) => c.status === "near-end").length,
      terminated: cs.filter((c) => c.status === "terminated" || c.status === "completed").length,
    };
  }, [contracts]);

  const openGroups = useMemo(() => {
    const set = new Set<string>();
    MENU.forEach((m) => {
      if (!m.children) return;
      m.children.forEach((ch) => {
        const [base, qs] = ch.route.split("?");
        const s = base.split("/").filter(Boolean);
        const q = new URLSearchParams(qs || "");
        // فعال اگر مسیر فعلی با پایه مطابقت دارد
        const sameBase = segs.length > 0 && segs[0] === s[0];
        if (sameBase) {
          if (!q.get("status")) set.add(m.key);
          else if (q.get("status") === query.get("status")) set.add(m.key);
        }
      });
    });
    return set;
  }, [segs, query]);

  const isItemActive = (m: MenuItem): boolean => {
    if (!m.route) return false;
    const [base] = m.route.split("?");
    const s = base.split("/").filter(Boolean);
    return segs[0] === s[0];
  };

  const go = (route: string) => {
    navigate(route);
    setMobileSidebar(false);
  };

  return (
    <>
      {/* پوشش موبایل */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden anim-fade-in" onClick={() => setMobileSidebar(false)} />
      )}

      <aside
        className={cn(
          "fixed lg:sticky top-0 bottom-0 z-50 lg:z-30 h-screen bg-sidebar text-sidebar-foreground border-s border-sidebar-border flex flex-col shadow-[1px_0_0_0_oklch(0_0_0/0.05)]",
          "transition-[width,transform] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
          sidebarCollapsed ? "lg:w-[74px]" : "lg:w-64",
          "w-[280px] max-w-[85vw]",
          mobileSidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        )}
      >
        {/* لوگو */}
        <div className={cn("flex items-center gap-3 h-16 border-b border-sidebar-border shrink-0", sidebarCollapsed ? "justify-center px-2" : "px-5")}>
          <LogoMark />
          {!sidebarCollapsed && (
            <div className="min-w-0 flex-1">
              <p className="text-[13.5px] font-extrabold text-sidebar-foreground leading-5 truncate">سامانه مدیریت قراردادها</p>
              <p className="text-[10px] text-sidebar-foreground/60">تأمین تجهیزات و پروژه‌های صنعتی</p>
            </div>
          )}
          <button
            className="lg:hidden grid place-items-center w-8 h-8 rounded-lg text-sidebar-foreground/70 hover:bg-sidebar-accent"
            onClick={() => setMobileSidebar(false)}
            aria-label="بستن منو"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* منو */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-3 px-2.5 space-y-0.5">
          {MENU.map((m) =>
            m.children ? (
              <GroupItem
                key={m.key}
                item={m}
                collapsed={sidebarCollapsed}
                defaultOpen={openGroups.has(m.key)}
                segs={segs}
                query={query}
                onNavigate={go}
                counts={counts}
              />
            ) : (
              <SingleItem key={m.key} item={m} collapsed={sidebarCollapsed} active={isItemActive(m)} onNavigate={go} />
            )
          )}
        </nav>

        {/* دکمه جمع‌کردن */}
        <div className="border-t border-sidebar-border p-2.5 shrink-0 hidden lg:block">
          <button
            onClick={toggleSidebar}
            className={cn(
              "w-full flex items-center gap-2.5 rounded-lg px-3 h-9 text-[12.5px] text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors",
              sidebarCollapsed && "justify-center px-0"
            )}
          >
            {sidebarCollapsed ? <ChevronsLeft className="w-4 h-4 rotate-180" /> : <ChevronsRight className="w-4 h-4 rotate-180" />}
            {!sidebarCollapsed && <span>جمع‌کردن منو</span>}
          </button>
        </div>
      </aside>
    </>
  );
}

function SingleItem({
  item,
  collapsed,
  active,
  onNavigate,
}: {
  item: MenuItem;
  collapsed: boolean;
  active: boolean;
  onNavigate: (r: string) => void;
}) {
  return (
    <button
      onClick={() => item.route && onNavigate(item.route)}
      title={collapsed ? item.label : undefined}
      className={cn(
        "w-full flex items-center gap-3 rounded-lg px-3 h-10 text-[13px] font-medium transition-all group relative",
        collapsed && "lg:justify-center lg:px-0",
        active
          ? "bg-sidebar-primary/15 text-sidebar-primary"
          : "text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      )}
    >
      {active && <span className="absolute end-0 top-2 bottom-2 w-[3px] rounded-full bg-sidebar-primary" />}
      <span className={cn("shrink-0", active && "drop-shadow-[0_0_6px_oklch(0.7_0.11_185/0.6)]")}>{item.icon}</span>
      <span className={cn("truncate", collapsed && "lg:hidden")}>{item.label}</span>
    </button>
  );
}

function GroupItem({
  item,
  collapsed,
  defaultOpen,
  segs,
  query,
  onNavigate,
  counts,
}: {
  item: MenuItem;
  collapsed: boolean;
  defaultOpen: boolean;
  segs: string[];
  query: URLSearchParams;
  onNavigate: (r: string) => void;
  counts: { contracts: number; active: number; nearEnd: number; terminated: number };
}) {
  const [open, setOpen] = useDefaultOpen(defaultOpen);
  const activeChild = item.children?.find((ch) => {
    const [base, qs] = ch.route.split("?");
    const s = base.split("/").filter(Boolean);
    if (segs[0] !== s[0]) return false;
    const q = new URLSearchParams(qs || "");
    if (!q.get("status")) return true;
    return q.get("status") === query.get("status");
  });

  const badgeFor = (route: string): number | undefined => {
    if (route === "/contracts?status=active") return counts.active;
    if (route === "/contracts?status=near-end") return counts.nearEnd;
    if (route === "/contracts?status=terminated") return counts.terminated;
    if (route === "/contracts") return counts.contracts;
    return undefined;
  };

  return (
    <div>
      <button
        onClick={() => (collapsed ? setOpen(!open) : setOpen(!open))}
        title={collapsed ? item.label : undefined}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 h-10 text-[13px] font-medium transition-all",
          collapsed && "lg:justify-center lg:px-0",
          activeChild ? "text-sidebar-primary" : "text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <span className="shrink-0">{item.icon}</span>
        <span className={cn("truncate flex-1 text-start", collapsed && "lg:hidden")}>{item.label}</span>
        <ChevronDown
          className={cn("w-4 h-4 shrink-0 transition-transform duration-200 opacity-60", open && "rotate-180", collapsed && "lg:hidden")}
        />
      </button>
      {open && (
        <div className={cn("mt-0.5 space-y-0.5", collapsed && "lg:hidden")}>
          {item.children?.map((ch) => {
            const [base, qs] = ch.route.split("?");
            const s = base.split("/").filter(Boolean);
            const q = new URLSearchParams(qs || "");
            const active =
              segs[0] === s[0] && (!q.get("status") ? !query.get("status") : q.get("status") === query.get("status"));
            const badge = badgeFor(ch.route);
            return (
              <button
                key={ch.route}
                onClick={() => onNavigate(ch.route)}
                className={cn(
                  "w-full flex items-center gap-2.5 rounded-lg px-3 h-9 text-[12.5px] transition-all me-3",
                  active
                    ? "bg-sidebar-primary/15 text-sidebar-primary font-semibold"
                    : "text-sidebar-foreground/65 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}
                style={{ marginRight: 22, width: "calc(100% - 22px)" }}
              >
                <CircleDot className={cn("w-3 h-3 shrink-0", active ? "text-sidebar-primary" : "opacity-40")} />
                <span className="truncate flex-1 text-start">{ch.label}</span>
                {badge !== undefined && (
                  <span className="nums text-[10px] rounded-full bg-sidebar-accent px-1.5 py-0.5 text-sidebar-foreground/80">
                    {toFaDigits(badge)}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
function useDefaultOpen(defaultOpen: boolean) {
  const [open, setOpen] = useState(defaultOpen);
  // اگر گروهی در مسیر فعلی قرار گرفت، به‌صورت خودکار باز شود
  const [prevDefault, setPrevDefault] = useState(defaultOpen);
  if (defaultOpen && defaultOpen !== prevDefault) {
    setPrevDefault(true);
    setOpen(true);
  }
  return [open, setOpen] as const;
}

/* ═══════ نشان لوگو — چرخ‌دنده و سند ═══════ */

export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <span
      className="relative grid place-items-center shrink-0 rounded-xl bg-gradient-to-br from-[oklch(0.72_0.105_185)] to-[oklch(0.5_0.09_205)] text-white e2"
      style={{ width: size, height: size, boxShadow: "inset 0 1px 1px oklch(1 0 0/0.4), 0 3px 8px -1px oklch(0.45 0.09 200/0.55)" }}
    >
      <svg width={size * 0.58} height={size * 0.58} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" />
        <circle cx="12" cy="12" r="4.2" />
        <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
      </svg>
    </span>
  );
}
