"use client";

import { ThemeProvider } from "next-themes";
import { Toaster } from "sonner";
import { RouterProvider } from "@/lib/router";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { useUIStore } from "@/store/ui";
import { cn } from "@/lib/utils";

/* ═══════ فراهم‌کنندگان سراسری ═══════ */

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <RouterProvider>
        {children}
        <Toaster
          position="bottom-left"
          dir="rtl"
          toastOptions={{
            classNames: {
              toast:
                "!rounded-xl !border !border-border !bg-popover !text-popover-foreground !shadow-lg !font-sans",
              title: "!text-[13px] !font-bold",
              description: "!text-[12px] !text-muted-foreground",
            },
          }}
        />
      </RouterProvider>
    </ThemeProvider>
  );
}

/* ═══════ پوسته اصلی برنامه: سایدبار + هدر + محتوا ═══════ */

export function AppShell({ children }: { children: React.ReactNode }) {
  const { sidebarCollapsed } = useUIStore();
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div
        className={cn(
          "flex-1 flex flex-col min-w-0 min-h-screen",
          sidebarCollapsed ? "" : ""
        )}
      >
        <Header />
        <main className="flex-1 px-4 lg:px-6 py-5 w-full max-w-[1600px] mx-auto" id="main-content">
          {children}
        </main>
        <footer className="border-t border-border py-3 px-6 mt-auto">
          <p className="text-[11px] text-muted-foreground text-center">
            سامانه جامع مدیریت قراردادها و تأمین تجهیزات — نسخه ۱٫۰٫۰ © ۱۴۰۵
          </p>
        </footer>
      </div>
    </div>
  );
}
