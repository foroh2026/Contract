"use client";

import { useState, useMemo, useRef } from "react";
import { Menu, Bell, Search, Sun, Moon, Monitor, LogOut, Settings, UserRound, CheckCheck, AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useRouter } from "@/lib/router";
import { useUIStore } from "@/store/ui";
import { useTheme } from "next-themes";
import { useAsync } from "@/hooks/useAsync";
import { notificationService, contractService, employerService } from "@/services";
import { timeAgo, toFaDigits } from "@/lib/jalali";
import { LogoMark } from "./sidebar";
import { Dropdown, DropdownItem } from "@/components/kit/overlay";
import { CURRENT_USER } from "@/mock/pools";
import { formatRialCompact } from "@/lib/format";
import { ContractStatusBadge } from "@/components/kit/badge";
import { useMounted } from "@/hooks/useAsync";

/* ═══════ هدر سراسری ═══════ */

export function Header() {
  const { navigate } = useRouter();
  const { setMobileSidebar } = useUIStore();
  const [q, setQ] = useState("");
  const [focused, setFocused] = useState(false);

  const { data: notifications } = useAsync(() => notificationService.list(), []);
  const { data: contracts } = useAsync(() => contractService.list(), []);
  const { data: employers } = useAsync(() => employerService.list(), []);

  const unread = (notifications || []).filter((n) => !n.read).length;

  const results = useMemo(() => {
    const query = q.trim();
    if (query.length < 2) return null;
    const lc = query.toLowerCase();
    const cs = (contracts || []).filter((c) => c.code.toLowerCase().includes(lc) || c.title.includes(query)).slice(0, 5);
    const es = (employers || []).filter((e) => e.name.includes(query) || e.shortName.includes(query)).slice(0, 3);
    return { contracts: cs, employers: es };
  }, [q, contracts, employers]);

  return (
    <header className="sticky top-0 z-40 h-16 border-b border-border glass">
      <div className="flex items-center gap-3 h-full px-4 lg:px-6">
        {/* دکمه منو موبایل */}
        <button
          className="lg:hidden grid place-items-center w-9 h-9 rounded-lg hover:bg-secondary transition-colors"
          onClick={() => setMobileSidebar(true)}
          aria-label="باز کردن منو"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* جستجوی سریع */}
        <div className="relative flex-1 max-w-xl">
          <div className="relative">
            <Search className="absolute end-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setTimeout(() => setFocused(false), 180)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && results?.contracts.length) {
                  navigate(`/contracts/${results.contracts[0].id}`);
                  setQ("");
                }
              }}
              placeholder="جستجو در قراردادها، کارفرمایان..."
              className="h-10 w-full rounded-xl border border-input bg-background/60 ps-3 pe-10 text-[13px] transition-shadow focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/15"
              aria-label="جستجوی سریع"
            />
          </div>
          {focused && results && (
            <div className="absolute top-[calc(100%+8px)] inset-x-0 rounded-xl border border-border bg-popover e3 p-2 anim-scale-in origin-top z-50">
              {results.contracts.length === 0 && results.employers.length === 0 ? (
                <p className="text-[13px] text-muted-foreground text-center py-4">نتیجه‌ای یافت نشد</p>
              ) : (
                <>
                  {results.contracts.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        navigate(`/contracts/${c.id}`);
                        setQ("");
                      }}
                      className="w-full flex items-center justify-between gap-3 rounded-lg px-3 py-2 hover:bg-secondary transition-colors text-start"
                    >
                      <div className="min-w-0">
                        <p className="text-[13px] font-medium truncate">{c.title}</p>
                        <p className="nums text-[11px] text-muted-foreground">{toFaDigits(c.code)} • {formatRialCompact(c.amountRial)}</p>
                      </div>
                      <ContractStatusBadge status={c.status} />
                    </button>
                  ))}
                  {results.employers.map((e) => (
                    <button
                      key={e.id}
                      onClick={() => {
                        navigate("/employers");
                        setQ("");
                      }}
                      className="w-full flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-secondary transition-colors text-start"
                    >
                      <span className="grid place-items-center w-8 h-8 rounded-lg bg-primary/10 text-primary shrink-0">
                        <UserRound className="w-4 h-4" />
                      </span>
                      <div className="min-w-0">
                        <p className="text-[13px] font-medium truncate">{e.name}</p>
                        <p className="text-[11px] text-muted-foreground">{e.type}</p>
                      </div>
                    </button>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        <div className="flex-1" />

        {/* اعلان‌ها */}
        <Dropdown
          align="end"
          trigger={
            <button className="relative grid place-items-center w-9 h-9 rounded-lg hover:bg-secondary transition-colors" aria-label="اعلان‌ها">
              <Bell className="w-[18px] h-[18px]" />
              {unread > 0 && (
                <span className="absolute -top-0.5 -end-0.5 grid place-items-center min-w-[17px] h-[17px] rounded-full bg-destructive text-white text-[9.5px] font-bold px-1 nums e1">
                  {toFaDigits(unread)}
                </span>
              )}
            </button>
          }
          className="w-[360px] max-w-[92vw]"
        >
          <div className="flex items-center justify-between px-2.5 py-1.5">
            <p className="text-[13px] font-bold">اعلان‌ها</p>
            <button
              onClick={() => notificationService.markAllRead()}
              className="text-[11px] text-primary hover:underline flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              علامت‌گذاری همه
            </button>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {(notifications || []).slice(0, 8).map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  notificationService.markRead(n.id);
                  if (n.link) navigate("/" + n.link);
                }}
                className="w-full flex items-start gap-2.5 rounded-lg px-2.5 py-2.5 hover:bg-secondary transition-colors text-start"
              >
                <NotifIcon kind={n.kind} />
                <div className="min-w-0 flex-1">
                  <p className={cn("text-[12.5px] leading-5", n.read ? "text-foreground/80" : "font-bold")}>{n.title}</p>
                  <p className="text-[11px] text-muted-foreground leading-5 line-clamp-2">{n.description}</p>
                  <p className="text-[10px] text-muted-foreground/70 mt-0.5">{timeAgo(n.date)}</p>
                </div>
                {!n.read && <span className="w-2 h-2 rounded-full bg-primary shrink-0 mt-1.5" />}
              </button>
            ))}
          </div>
          <button
            onClick={() => navigate("/notifications")}
            className="w-full text-center text-[12px] font-medium text-primary py-2 hover:bg-secondary rounded-lg transition-colors"
          >
            مشاهده همه اعلان‌ها
          </button>
        </Dropdown>

        {/* تغییر تم */}
        <ThemeSwitcher />

        {/* کاربر */}
        <Dropdown
          align="end"
          trigger={
            <button className="flex items-center gap-2.5 rounded-xl hover:bg-secondary py-1.5 ps-1.5 pe-2.5 transition-colors">
              <span className="grid place-items-center w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-[oklch(0.45_0.08_210)] text-primary-foreground text-[13px] font-bold e1">
                ر.ک
              </span>
              <span className="hidden md:block text-start">
                <span className="block text-[12.5px] font-bold leading-4">{CURRENT_USER.fullName}</span>
                <span className="block text-[10.5px] text-muted-foreground">{CURRENT_USER.role}</span>
              </span>
            </button>
          }
        >
          <div className="px-3 py-2 border-b border-border mb-1">
            <p className="text-[13px] font-bold">{CURRENT_USER.fullName}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{CURRENT_USER.role} — دسترسی کامل</p>
          </div>
          <DropdownItem icon={<UserRound className="w-4 h-4" />}>پروفایل کاربری</DropdownItem>
          <DropdownItem icon={<Settings className="w-4 h-4" />} onClick={() => navigate("/settings")}>
            تنظیمات سامانه
          </DropdownItem>
          <div className="h-px bg-border my-1" />
          <DropdownItem icon={<LogOut className="w-4 h-4" />} danger>خروج از حساب</DropdownItem>
        </Dropdown>
      </div>
    </header>
  );
}

function NotifIcon({ kind }: { kind: string }) {
  const map: Record<string, React.ReactNode> = {
    warning: <span className="grid place-items-center w-8 h-8 rounded-lg bg-amber-500/12 text-amber-500 shrink-0"><AlertTriangle className="w-4 h-4" /></span>,
    danger: <span className="grid place-items-center w-8 h-8 rounded-lg bg-red-500/12 text-red-500 shrink-0"><XCircle className="w-4 h-4" /></span>,
    success: <span className="grid place-items-center w-8 h-8 rounded-lg bg-emerald-500/12 text-emerald-500 shrink-0"><CheckCircle2 className="w-4 h-4" /></span>,
    info: <span className="grid place-items-center w-8 h-8 rounded-lg bg-sky-500/12 text-sky-500 shrink-0"><Info className="w-4 h-4" /></span>,
  };
  return map[kind] ?? map.info;
}

/* ═══════ سوییچر تم: روز / شب / سیستم ═══════ */

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();
  const mounted = useMounted();
  if (!mounted) return <div className="w-[76px]" />;

  const options = [
    { key: "light", icon: <Sun className="w-4 h-4" />, label: "حالت روز" },
    { key: "dark", icon: <Moon className="w-4 h-4" />, label: "حالت شب" },
    { key: "system", icon: <Monitor className="w-4 h-4" />, label: "حالت سیستم" },
  ];

  return (
    <div className="flex items-center rounded-xl border border-border bg-secondary/50 p-0.5" role="radiogroup" aria-label="انتخاب تم">
      {options.map((o) => (
        <button
          key={o.key}
          onClick={() => setTheme(o.key)}
          title={o.label}
          aria-label={o.label}
          aria-checked={theme === o.key}
          role="radio"
          className={cn(
            "grid place-items-center w-8 h-8 rounded-lg transition-all",
            theme === o.key
              ? "bg-card text-primary e1 shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          {o.icon}
        </button>
      ))}
    </div>
  );
}
