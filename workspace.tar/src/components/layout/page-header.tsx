"use client";

import { ChevronLeft, Home } from "lucide-react";
import { useRouter } from "@/lib/router";
import { cn } from "@/lib/utils";

/* ═══════ سربرگ صفحه: مسیر (Breadcrumb) + عنوان + عملیات ═══════ */

export function PageHeader({
  title,
  subtitle,
  breadcrumb,
  actions,
  className,
}: {
  title: string;
  subtitle?: string;
  breadcrumb?: { label: string; route?: string }[];
  actions?: React.ReactNode;
  className?: string;
}) {
  const { navigate } = useRouter();
  return (
    <div className={cn("mb-5", className)}>
      {breadcrumb && breadcrumb.length > 0 && (
        <nav aria-label="مسیر" className="flex items-center gap-1 text-[11.5px] text-muted-foreground mb-2 flex-wrap">
          <button onClick={() => navigate("/dashboard")} className="flex items-center gap-1 hover:text-primary transition-colors">
            <Home className="w-3.5 h-3.5" />
            خانه
          </button>
          {breadcrumb.map((b, i) => (
            <span key={i} className="flex items-center gap-1">
              <ChevronLeft className="w-3.5 h-3.5 opacity-50" />
              {b.route ? (
                <button onClick={() => navigate(b.route!)} className="hover:text-primary transition-colors">
                  {b.label}
                </button>
              ) : (
                <span className="text-foreground/80 font-medium">{b.label}</span>
              )}
            </span>
          ))}
        </nav>
      )}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight">{title}</h1>
          {subtitle && <p className="text-[13px] text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
      </div>
    </div>
  );
}
