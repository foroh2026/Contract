import type {
  Activity, Amendment, Contract, DocumentFile, Employer, ItemStatus,
  Notification, Payment, ProgressLog, Purchase, Statement, TechnicalAppendix,
  TechnicalItem, User,
} from "@/types";
import * as db from "@/mock/data";
import { todayISO, addDays, toISO, toJalali } from "@/lib/jalali";
import { computeHealthScore } from "@/lib/health";
import { contractProgressSummary } from "@/lib/progress";

/* ═══════════════════════════════════════════════════════════
   Service Layer — لایه سرویس
   تمام داده‌ها از این لایه و به صورت async خوانده/نوشته می‌شوند.
   برای اتصال به Backend واقعی کافی است بدنه توابع با fetch جایگزین شود.
   ═══════════════════════════════════════════════════════════ */

const LATENCY = 220;
const delay = (ms = LATENCY) => new Promise((r) => setTimeout(r, ms));

/* ─────────── قراردادها ─────────── */

export const contractService = {
  async list(): Promise<Contract[]> {
    await delay();
    return [...db.contracts];
  },

  async get(id: string): Promise<Contract | undefined> {
    await delay(120);
    return db.contracts.find((c) => c.id === id);
  },

  async create(input: Partial<Contract>): Promise<Contract> {
    await delay(400);
    const year = 1405;
    const n = db.contracts.length + 1;
    const contract: Contract = {
      id: `c-${String(n).padStart(2, "0")}`,
      code: input.code || `CTR-${year}-${String(n).padStart(3, "0")}`,
      title: input.title || "قرارداد بدون عنوان",
      subject: input.subject || "",
      employerId: input.employerId || db.employers[0].id,
      creditSource: input.creditSource || "منابع داخلی شرکت",
      startDate: input.startDate || todayISO(),
      endDate: input.endDate || toISO(addDays(new Date(), 365)),
      amountRial: input.amountRial || 0,
      amountForeign: input.amountForeign,
      currency: input.currency,
      exchangeRate: input.exchangeRate,
      prepaymentPercent: input.prepaymentPercent ?? 20,
      status: input.status || "active",
      lastStatusDate: todayISO(),
      description: input.description,
      createdAt: todayISO(),
    };
    db.contracts.unshift(contract);
    activityService.push({
      contractId: contract.id,
      kind: "contract",
      title: `قرارداد ${contract.code} ایجاد شد`,
      description: contract.title,
      date: todayISO(),
      user: "رضا کریمی",
    });
    return contract;
  },

  async update(id: string, patch: Partial<Contract>): Promise<Contract | undefined> {
    await delay(300);
    const c = db.contracts.find((x) => x.id === id);
    if (c) Object.assign(c, patch);
    return c;
  },

  async remove(id: string): Promise<void> {
    await delay(300);
    const idx = db.contracts.findIndex((x) => x.id === id);
    if (idx >= 0) db.contracts.splice(idx, 1);
  },
};

/* ─────────── کارفرمایان ─────────── */

export const employerService = {
  async list(): Promise<Employer[]> {
    await delay();
    return [...db.employers];
  },
  async get(id: string): Promise<Employer | undefined> {
    await delay(100);
    return db.employers.find((e) => e.id === id);
  },
};

/* ─────────── پیوست فنی ─────────── */

export const appendixService = {
  async getByContract(contractId: string): Promise<TechnicalAppendix | undefined> {
    await delay(150);
    return db.appendices.find((a) => a.contractId === contractId);
  },

  /** ثبت پیشرفت جدید برای یک قلم */
  async updateItemProgress(
    itemId: string,
    progress: number,
    description: string
  ): Promise<TechnicalItem | undefined> {
    await delay(350);
    for (const appendix of db.appendices) {
      const item = appendix.items.find((i) => i.id === itemId);
      if (item) {
        const previous = item.progress;
        item.progress = Math.max(0, Math.min(100, progress));
        item.planPercent = Math.max(item.planPercent, item.progress);
        item.status =
          item.progress >= 100 ? "تکمیل‌شده" : item.progress > 0 ? ("در حال اجرا" as ItemStatus) : "شروع‌نشده";
        db.logs.unshift({
          id: `pl-${Date.now()}`,
          itemId,
          contractId: appendix.contractId,
          date: todayISO(),
          previous,
          current: item.progress,
          description: description || "ثبت پیشرفت از طریق سامانه",
          user: "رضا کریمی",
        });
        activityService.push({
          contractId: appendix.contractId,
          kind: "progress",
          title: `پیشرفت قلم ${item.code} بروزرسانی شد`,
          description: `${item.title}: ${previous}٪ ← ${item.progress}٪`,
          date: todayISO(),
          user: "رضا کریمی",
        });
        return item;
      }
    }
    return undefined;
  },

  /** سابقه پیشرفت یک قلم */
  async itemLogs(itemId: string): Promise<ProgressLog[]> {
    await delay(80);
    return db.logs.filter((l) => l.itemId === itemId).sort((a, b) => (a.date < b.date ? 1 : -1));
  },

  async allLogs(contractId: string): Promise<ProgressLog[]> {
    await delay(80);
    return db.logs.filter((l) => l.contractId === contractId).sort((a, b) => (a.date < b.date ? 1 : -1));
  },
};

/* ─────────── خرید و ساخت ─────────── */

export const purchaseService = {
  async list(): Promise<Purchase[]> {
    await delay();
    return [...db.purchases];
  },
  async byContract(contractId: string): Promise<Purchase[]> {
    await delay(120);
    return db.purchases.filter((p) => p.contractId === contractId);
  },
  async create(input: Partial<Purchase>): Promise<Purchase> {
    await delay(350);
    const n = db.purchases.length + 1;
    const p: Purchase = {
      id: `prc-${Date.now()}`,
      code: `PRC-1405-${String(n).padStart(3, "0")}`,
      contractId: input.contractId || "",
      itemId: input.itemId,
      type: input.type || "خرید",
      description: input.description || "",
      supplier: input.supplier || "",
      date: input.date || todayISO(),
      unitPrice: input.unitPrice || 0,
      quantity: input.quantity || 0,
      unit: input.unit || "عدد",
      status: input.status || "ثبت‌شده",
    };
    db.purchases.unshift(p);
    activityService.push({
      contractId: p.contractId,
      kind: "purchase",
      title: `${p.type} ${p.code} ثبت شد`,
      description: p.description,
      date: p.date,
      user: "حسین قنبری",
    });
    return p;
  },
};

/* ─────────── صورت‌وضعیت‌ها ─────────── */

export const statementService = {
  async list(): Promise<Statement[]> {
    await delay();
    return [...db.statements];
  },
  async byContract(contractId: string): Promise<Statement[]> {
    await delay(120);
    return db.statements.filter((s) => s.contractId === contractId);
  },
  async create(input: Partial<Statement>): Promise<Statement> {
    await delay(350);
    const n = db.statements.length + 1;
    const gross = input.grossAmount || 0;
    const s: Statement = {
      id: `sv-${Date.now()}`,
      code: `SV-${String(n).padStart(3, "0")}`,
      contractId: input.contractId || "",
      number: input.number || n,
      date: input.date || todayISO(),
      description: input.description || "",
      grossAmount: gross,
      vatPercent: input.vatPercent ?? 10,
      finalAmount: Math.round(gross * (1 + (input.vatPercent ?? 10) / 100)),
      status: input.status || "پیش‌نویس",
    };
    db.statements.unshift(s);
    activityService.push({
      contractId: s.contractId,
      kind: "statement",
      title: `صورت‌وضعیت ${s.code} ثبت شد`,
      description: s.description,
      date: s.date,
      user: "زهرا موسوی",
    });
    return s;
  },
};

/* ─────────── دریافتی‌ها ─────────── */

export const paymentService = {
  async list(): Promise<Payment[]> {
    await delay();
    return [...db.payments];
  },
  async byContract(contractId: string): Promise<Payment[]> {
    await delay(100);
    return db.payments.filter((p) => p.contractId === contractId);
  },
  async byStatement(statementId: string): Promise<Payment[]> {
    await delay(80);
    return db.payments.filter((p) => p.statementId === statementId);
  },
  async create(input: Partial<Payment>): Promise<Payment> {
    await delay(350);
    const n = db.payments.length + 1;
    const p: Payment = {
      id: `pay-${Date.now()}`,
      code: `PAY-1405-${String(n).padStart(3, "0")}`,
      contractId: input.contractId || "",
      statementId: input.statementId,
      amount: input.amount || 0,
      date: input.date || todayISO(),
      method: input.method || "حواله بانکی",
      reference: input.reference || `HV-${Date.now() % 1000000}`,
      description: input.description,
    };
    db.payments.unshift(p);
    if (p.statementId) {
      const st = db.statements.find((s) => s.id === p.statementId);
      const paid = db.payments.filter((x) => x.statementId === p.statementId).reduce((a, x) => a + x.amount, 0);
      if (st) {
        st.status = paid >= st.finalAmount ? "پرداخت شده" : "تأیید شده";
      }
    }
    activityService.push({
      contractId: p.contractId,
      kind: "payment",
      title: `دریافت ${p.code} ثبت شد`,
      description: p.description || "دریافت وجه از کارفرما",
      date: p.date,
      user: "زهرا موسوی",
    });
    return p;
  },
};

/* ─────────── الحاقیه‌ها ─────────── */

export const amendmentService = {
  async list(): Promise<Amendment[]> {
    await delay();
    return [...db.amendments];
  },
  async byContract(contractId: string): Promise<Amendment[]> {
    await delay(100);
    return db.amendments.filter((a) => a.contractId === contractId);
  },
};

/* ─────────── اسناد ─────────── */

export const documentService = {
  async list(): Promise<DocumentFile[]> {
    await delay();
    return [...db.documents];
  },
  async byContract(contractId: string): Promise<DocumentFile[]> {
    await delay(100);
    return db.documents.filter((d) => d.contractId === contractId);
  },
};

/* ─────────── اعلان‌ها ─────────── */

export const notificationService = {
  async list(): Promise<Notification[]> {
    await delay(120);
    return [...db.notifications];
  },
  async markRead(id: string): Promise<void> {
    const n = db.notifications.find((x) => x.id === id);
    if (n) n.read = true;
  },
  async markAllRead(): Promise<void> {
    db.notifications.forEach((n) => (n.read = true));
  },
};

/* ─────────── کاربران ─────────── */

export const userService = {
  async list(): Promise<User[]> {
    await delay(100);
    return [...db.users];
  },
};

/* ─────────── فعالیت‌ها ─────────── */

export const activityService = {
  async list(): Promise<Activity[]> {
    await delay(120);
    return [...db.activities];
  },
  async byContract(contractId: string): Promise<Activity[]> {
    await delay(80);
    return db.activities.filter((a) => a.contractId === contractId);
  },
  push(a: Activity) {
    db.activities.unshift({ id: `act-${Date.now()}`, ...a });
  },
};

/* ─────────── داشبورد و گزارش‌ها ─────────── */

export interface DashboardStats {
  totalContracts: number;
  activeContracts: number;
  nearEndContracts: number;
  delayedContracts: number;
  totalValue: number;
  statementsTotal: number;
  receivedTotal: number;
  receivablesTotal: number;
  monthSeries: { label: string; value: number }[];
  statusSeries: { label: string; value: number; key: string }[];
  progressComparison: { label: string; plan: number; actual: number }[];
  healthTop: { contractId: string; code: string; title: string; score: number; level: string }[];
}

export const dashboardService = {
  async stats(): Promise<DashboardStats> {
    await delay(260);
    const cs = db.contracts;
    const active = cs.filter((c) => c.status === "active");
    const nearEnd = cs.filter((c) => c.status === "near-end");
    const delayed = cs.filter((c) => c.status === "delayed");
    const totalValue = cs.reduce((a, c) => a + c.amountRial, 0);
    const statementsTotal = db.statements.reduce((a, s) => a + s.finalAmount, 0);
    const receivedTotal = db.payments.reduce((a, p) => a + p.amount, 0);

    // سری ماهانه ارزش قراردادها (۱۲ ماه اخیر) — بر اساس تاریخ شروع جلالی
    const J_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
    const monthSeries: { label: string; value: number }[] = [];
    const nowJ = toJalali(new Date());
    for (let i = 11; i >= 0; i--) {
      let m = nowJ.jm - i;
      let y = nowJ.jy;
      while (m <= 0) { m += 12; y -= 1; }
      const total = cs
        .filter((c) => {
          const j = toJalali(new Date(c.startDate));
          return j.jy === y && j.jm === m;
        })
        .reduce((a, c) => a + c.amountRial, 0);
      monthSeries.push({ label: J_MONTHS[m - 1], value: total });
    }

    const statusSeries = [
      { key: "active", label: "فعال", value: active.length },
      { key: "near-end", label: "نزدیک پایان", value: nearEnd.length },
      { key: "delayed", label: "دارای تأخیر", value: delayed.length },
      { key: "suspended", label: "متوقف", value: cs.filter((c) => c.status === "suspended").length },
      { key: "completed", label: "تکمیل‌شده", value: cs.filter((c) => c.status === "completed").length },
      { key: "terminated", label: "خاتمه‌یافته", value: cs.filter((c) => c.status === "terminated").length },
    ].filter((s) => s.value > 0);

    const withAppendix = cs.filter((c) => db.appendices.some((a) => a.contractId === c.id));
    const progressComparison = withAppendix.slice(0, 8).map((c) => {
      const appendix = db.appendices.find((a) => a.contractId === c.id)!;
      const summary = contractProgressSummary(c, appendix);
      return { label: c.code, plan: Math.round(summary.planned), actual: Math.round(summary.actual) };
    });

    const healthTop = withAppendix.slice(0, 6).map((c) => {
      const appendix = db.appendices.find((a) => a.contractId === c.id)!;
      const sum = contractProgressSummary(c, appendix);
      const h = computeHealthScore({
        contract: c,
        actual: sum.actual,
        planned: sum.planned,
        statements: db.statements.filter((s) => s.contractId === c.id),
        payments: db.payments.filter((p) => p.contractId === c.id),
        purchases: db.purchases.filter((p) => p.contractId === c.id),
      });
      return { contractId: c.id, code: c.code, title: c.title, score: h.score, level: h.level };
    });

    return {
      totalContracts: cs.length,
      activeContracts: active.length,
      nearEndContracts: nearEnd.length,
      delayedContracts: delayed.length,
      totalValue,
      statementsTotal,
      receivedTotal,
      receivablesTotal: Math.max(0, statementsTotal - receivedTotal),
      monthSeries,
      statusSeries,
      progressComparison,
      healthTop,
    };
  },
};
